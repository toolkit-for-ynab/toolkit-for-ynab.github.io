/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 146);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(4);
var core = __webpack_require__(26);
var hide = __webpack_require__(17);
var redefine = __webpack_require__(18);
var ctx = __webpack_require__(23);
var PROTOTYPE = 'prototype';

var $export = function (type, name, source) {
  var IS_FORCED = type & $export.F;
  var IS_GLOBAL = type & $export.G;
  var IS_STATIC = type & $export.S;
  var IS_PROTO = type & $export.P;
  var IS_BIND = type & $export.B;
  var target = IS_GLOBAL ? global : IS_STATIC ? global[name] || (global[name] = {}) : (global[name] || {})[PROTOTYPE];
  var exports = IS_GLOBAL ? core : core[name] || (core[name] = {});
  var expProto = exports[PROTOTYPE] || (exports[PROTOTYPE] = {});
  var key, own, out, exp;
  if (IS_GLOBAL) source = name;
  for (key in source) {
    // contains in native
    own = !IS_FORCED && target && target[key] !== undefined;
    // export native or passed
    out = (own ? target : source)[key];
    // bind timers to global for call from export context
    exp = IS_BIND && own ? ctx(out, global) : IS_PROTO && typeof out == 'function' ? ctx(Function.call, out) : out;
    // extend global
    if (target) redefine(target, key, out, type & $export.U);
    // export
    if (exports[key] != out) hide(exports, key, exp);
    if (IS_PROTO && expProto[key] != out) expProto[key] = out;
  }
};
global.core = core;
// type bitmap
$export.F = 1;   // forced
$export.G = 2;   // global
$export.S = 4;   // static
$export.P = 8;   // proto
$export.B = 16;  // bind
$export.W = 32;  // wrap
$export.U = 64;  // safe
$export.R = 128; // real proto method for `library`
module.exports = $export;


/***/ }),
/* 1 */
/***/ (function(module, exports) {

/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/
// css base code, injected by the css-loader
module.exports = function(useSourceMap) {
	var list = [];

	// return the list of modules as css string
	list.toString = function toString() {
		return this.map(function (item) {
			var content = cssWithMappingToString(item, useSourceMap);
			if(item[2]) {
				return "@media " + item[2] + "{" + content + "}";
			} else {
				return content;
			}
		}).join("");
	};

	// import a list of modules into the list
	list.i = function(modules, mediaQuery) {
		if(typeof modules === "string")
			modules = [[null, modules, ""]];
		var alreadyImportedModules = {};
		for(var i = 0; i < this.length; i++) {
			var id = this[i][0];
			if(typeof id === "number")
				alreadyImportedModules[id] = true;
		}
		for(i = 0; i < modules.length; i++) {
			var item = modules[i];
			// skip already imported module
			// this implementation is not 100% perfect for weird media query combinations
			//  when a module is imported multiple times with different media queries.
			//  I hope this will never occur (Hey this way we have smaller bundles)
			if(typeof item[0] !== "number" || !alreadyImportedModules[item[0]]) {
				if(mediaQuery && !item[2]) {
					item[2] = mediaQuery;
				} else if(mediaQuery) {
					item[2] = "(" + item[2] + ") and (" + mediaQuery + ")";
				}
				list.push(item);
			}
		}
	};
	return list;
};

function cssWithMappingToString(item, useSourceMap) {
	var content = item[1] || '';
	var cssMapping = item[3];
	if (!cssMapping) {
		return content;
	}

	if (useSourceMap && typeof btoa === 'function') {
		var sourceMapping = toComment(cssMapping);
		var sourceURLs = cssMapping.sources.map(function (source) {
			return '/*# sourceURL=' + cssMapping.sourceRoot + source + ' */'
		});

		return [content].concat(sourceURLs).concat([sourceMapping]).join('\n');
	}

	return [content].join('\n');
}

// Adapted from convert-source-map (MIT)
function toComment(sourceMap) {
	// eslint-disable-next-line no-undef
	var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap))));
	var data = 'sourceMappingURL=data:application/json;charset=utf-8;base64,' + base64;

	return '/*# ' + data + ' */';
}


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Feature = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _listeners = __webpack_require__(352);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Feature = exports.Feature = function () {
  function Feature() {
    _classCallCheck(this, Feature);

    this.settings = {
      enabled: ynabToolKit.options[this.constructor.name]
    };
  }

  _createClass(Feature, [{
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      // Default to no action. Unless you're implementing a CSS only feature,
      // you MUST override this to specify when your invoke() function should run!
      return false;
    }
  }, {
    key: 'willInvoke',
    value: function willInvoke() {
      /* stubbed optional hook for logic that must happen for a feature
      to work but doesn't need to happen on every invoke */
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      throw Error('Feature: ' + this.constructor.name + ' does not implement required invoke() method.');
    }
  }, {
    key: 'injectCSS',
    value: function injectCSS() {/* stubbed, default to no injected CSS */}
  }, {
    key: 'observe',
    value: function observe() {/* stubbed listener function */}
  }, {
    key: 'onRouteChanged',
    value: function onRouteChanged() {/* stubbed listener function */}
  }, {
    key: 'onBudgetChanged',
    value: function onBudgetChanged() {/* stubbed listener function */}
  }, {
    key: 'applyListeners',
    value: function applyListeners() {
      var observeListener = new _listeners.ObserveListener();
      observeListener.addFeature(this);

      var routeChangeListener = new _listeners.RouteChangeListener();
      routeChangeListener.addFeature(this);
    }
  }]);

  return Feature;
}();

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(7);
module.exports = function (it) {
  if (!isObject(it)) throw TypeError(it + ' is not an object!');
  return it;
};


/***/ }),
/* 4 */
/***/ (function(module, exports) {

// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
var global = module.exports = typeof window != 'undefined' && window.Math == Math
  ? window : typeof self != 'undefined' && self.Math == Math ? self
  // eslint-disable-next-line no-new-func
  : Function('return this')();
if (typeof __g == 'number') __g = global; // eslint-disable-line no-undef


/***/ }),
/* 5 */
/***/ (function(module, exports) {

module.exports = function (exec) {
  try {
    return !!exec();
  } catch (e) {
    return true;
  }
};


/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.transitionTo = transitionTo;
exports.getEntityManager = getEntityManager;
exports.getCurrentBudgetDate = getCurrentBudgetDate;
exports.getCurrentRouteName = getCurrentRouteName;
exports.getCategoriesViewModel = getCategoriesViewModel;
exports.getAllBudgetMonthsViewModel = getAllBudgetMonthsViewModel;
exports.getAllBudgetMonthsViewModelResult = getAllBudgetMonthsViewModelResult;
exports.isYNABReady = isYNABReady;

var _ember = __webpack_require__(13);

function transitionTo() {
  var router = (0, _ember.containerLookup)('router:main');
  router.transitionTo.apply(router, arguments);
}

function getEntityManager() {
  return ynab.YNABSharedLib.defaultInstance.entityManager;
}

function getCurrentBudgetDate() {
  var applicationController = (0, _ember.controllerLookup)('application');
  var date = applicationController.get('monthString');
  return { year: date.slice(0, 4), month: date.slice(4, 6) };
}

function getCurrentRouteName() {
  var applicationController = (0, _ember.controllerLookup)('application');
  return applicationController.get('currentRouteName');
}

function getCategoriesViewModel() {
  return ynab.YNABSharedLib.getBudgetViewModel_CategoriesViewModel();
}

function getAllBudgetMonthsViewModel() {
  return ynab.YNABSharedLib.getBudgetViewModel_AllBudgetMonthsViewModel();
}

function getAllBudgetMonthsViewModelResult() {
  return getAllBudgetMonthsViewModel()._result;
}

function isYNABReady() {
  return typeof Em !== 'undefined' && typeof Ember !== 'undefined' && typeof $ !== 'undefined' && $('.ember-view.layout').length && typeof ynabToolKit !== 'undefined';
}

/***/ }),
/* 7 */
/***/ (function(module, exports) {

module.exports = function (it) {
  return typeof it === 'object' ? it !== null : typeof it === 'function';
};


/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

var store = __webpack_require__(56)('wks');
var uid = __webpack_require__(38);
var Symbol = __webpack_require__(4).Symbol;
var USE_SYMBOL = typeof Symbol == 'function';

var $exports = module.exports = function (name) {
  return store[name] || (store[name] =
    USE_SYMBOL && Symbol[name] || (USE_SYMBOL ? Symbol : uid)('Symbol.' + name));
};

$exports.store = store;


/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

// Thank's IE8 for his funny defineProperty
module.exports = !__webpack_require__(5)(function () {
  return Object.defineProperty({}, 'a', { get: function () { return 7; } }).a != 7;
});


/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

var anObject = __webpack_require__(3);
var IE8_DOM_DEFINE = __webpack_require__(102);
var toPrimitive = __webpack_require__(27);
var dP = Object.defineProperty;

exports.f = __webpack_require__(9) ? Object.defineProperty : function defineProperty(O, P, Attributes) {
  anObject(O);
  P = toPrimitive(P, true);
  anObject(Attributes);
  if (IE8_DOM_DEFINE) try {
    return dP(O, P, Attributes);
  } catch (e) { /* empty */ }
  if ('get' in Attributes || 'set' in Attributes) throw TypeError('Accessors not supported!');
  if ('value' in Attributes) O[P] = Attributes.value;
  return O;
};


/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

// 7.1.15 ToLength
var toInteger = __webpack_require__(29);
var min = Math.min;
module.exports = function (it) {
  return it > 0 ? min(toInteger(it), 0x1fffffffffffff) : 0; // pow(2, 53) - 1 == 9007199254740991
};


/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

// 7.1.13 ToObject(argument)
var defined = __webpack_require__(28);
module.exports = function (it) {
  return Object(defined(it));
};


/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getEmberView = getEmberView;
exports.getRouter = getRouter;
exports.controllerLookup = controllerLookup;
exports.componentLookup = componentLookup;
function getEmberView(viewId) {
  return getViewRegistry()[viewId];
}

function getRouter() {
  return containerLookup('router:main');
}

function controllerLookup(controllerName) {
  return containerLookup('controller:' + controllerName);
}

function componentLookup(componentName) {
  return containerLookup('component:' + componentName);
}

/* Private Functions */
function getViewRegistry() {
  return Ember.Component.create().get('_viewRegistry');
}

function containerLookup(containerName) {
  var viewRegistry = getViewRegistry();
  var viewId = Ember.keys(viewRegistry)[0];
  var view = viewRegistry[viewId];

  var container = void 0;
  try {
    container = view.container.lookup(containerName);
  } catch (e) {
    container = view.container.factoryCache[containerName];
  }

  return container;
}

/***/ }),
/* 14 */
/***/ (function(module, exports) {

module.exports = function (it) {
  if (typeof it != 'function') throw TypeError(it + ' is not a function!');
  return it;
};


/***/ }),
/* 15 */,
/* 16 */
/***/ (function(module, exports) {

var hasOwnProperty = {}.hasOwnProperty;
module.exports = function (it, key) {
  return hasOwnProperty.call(it, key);
};


/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

var dP = __webpack_require__(10);
var createDesc = __webpack_require__(37);
module.exports = __webpack_require__(9) ? function (object, key, value) {
  return dP.f(object, key, createDesc(1, value));
} : function (object, key, value) {
  object[key] = value;
  return object;
};


/***/ }),
/* 18 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(4);
var hide = __webpack_require__(17);
var has = __webpack_require__(16);
var SRC = __webpack_require__(38)('src');
var TO_STRING = 'toString';
var $toString = Function[TO_STRING];
var TPL = ('' + $toString).split(TO_STRING);

__webpack_require__(26).inspectSource = function (it) {
  return $toString.call(it);
};

(module.exports = function (O, key, val, safe) {
  var isFunction = typeof val == 'function';
  if (isFunction) has(val, 'name') || hide(val, 'name', key);
  if (O[key] === val) return;
  if (isFunction) has(val, SRC) || hide(val, SRC, O[key] ? '' + O[key] : TPL.join(String(key)));
  if (O === global) {
    O[key] = val;
  } else if (!safe) {
    delete O[key];
    hide(O, key, val);
  } else if (O[key]) {
    O[key] = val;
  } else {
    hide(O, key, val);
  }
// add fake Function#toString for correct work wrapped methods / constructors with methods like LoDash isNative
})(Function.prototype, TO_STRING, function toString() {
  return typeof this == 'function' && this[SRC] || $toString.call(this);
});


/***/ }),
/* 19 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var fails = __webpack_require__(5);
var defined = __webpack_require__(28);
var quot = /"/g;
// B.2.3.2.1 CreateHTML(string, tag, attribute, value)
var createHTML = function (string, tag, attribute, value) {
  var S = String(defined(string));
  var p1 = '<' + tag;
  if (attribute !== '') p1 += ' ' + attribute + '="' + String(value).replace(quot, '&quot;') + '"';
  return p1 + '>' + S + '</' + tag + '>';
};
module.exports = function (NAME, exec) {
  var O = {};
  O[NAME] = exec(createHTML);
  $export($export.P + $export.F * fails(function () {
    var test = ''[NAME]('"');
    return test !== test.toLowerCase() || test.split('"').length > 3;
  }), 'String', O);
};


/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

// to indexed object, toObject with fallback for non-array-like ES3 strings
var IObject = __webpack_require__(53);
var defined = __webpack_require__(28);
module.exports = function (it) {
  return IObject(defined(it));
};


/***/ }),
/* 21 */
/***/ (function(module, exports, __webpack_require__) {

var pIE = __webpack_require__(54);
var createDesc = __webpack_require__(37);
var toIObject = __webpack_require__(20);
var toPrimitive = __webpack_require__(27);
var has = __webpack_require__(16);
var IE8_DOM_DEFINE = __webpack_require__(102);
var gOPD = Object.getOwnPropertyDescriptor;

exports.f = __webpack_require__(9) ? gOPD : function getOwnPropertyDescriptor(O, P) {
  O = toIObject(O);
  P = toPrimitive(P, true);
  if (IE8_DOM_DEFINE) try {
    return gOPD(O, P);
  } catch (e) { /* empty */ }
  if (has(O, P)) return createDesc(!pIE.f.call(O, P), O[P]);
};


/***/ }),
/* 22 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.9 / 15.2.3.2 Object.getPrototypeOf(O)
var has = __webpack_require__(16);
var toObject = __webpack_require__(12);
var IE_PROTO = __webpack_require__(76)('IE_PROTO');
var ObjectProto = Object.prototype;

module.exports = Object.getPrototypeOf || function (O) {
  O = toObject(O);
  if (has(O, IE_PROTO)) return O[IE_PROTO];
  if (typeof O.constructor == 'function' && O instanceof O.constructor) {
    return O.constructor.prototype;
  } return O instanceof Object ? ObjectProto : null;
};


/***/ }),
/* 23 */
/***/ (function(module, exports, __webpack_require__) {

// optional / simple context binding
var aFunction = __webpack_require__(14);
module.exports = function (fn, that, length) {
  aFunction(fn);
  if (that === undefined) return fn;
  switch (length) {
    case 1: return function (a) {
      return fn.call(that, a);
    };
    case 2: return function (a, b) {
      return fn.call(that, a, b);
    };
    case 3: return function (a, b, c) {
      return fn.call(that, a, b, c);
    };
  }
  return function (/* ...args */) {
    return fn.apply(that, arguments);
  };
};


/***/ }),
/* 24 */
/***/ (function(module, exports) {

var toString = {}.toString;

module.exports = function (it) {
  return toString.call(it).slice(8, -1);
};


/***/ }),
/* 25 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var fails = __webpack_require__(5);

module.exports = function (method, arg) {
  return !!method && fails(function () {
    // eslint-disable-next-line no-useless-call
    arg ? method.call(null, function () { /* empty */ }, 1) : method.call(null);
  });
};


/***/ }),
/* 26 */
/***/ (function(module, exports) {

var core = module.exports = { version: '2.5.1' };
if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef


/***/ }),
/* 27 */
/***/ (function(module, exports, __webpack_require__) {

// 7.1.1 ToPrimitive(input [, PreferredType])
var isObject = __webpack_require__(7);
// instead of the ES6 spec version, we didn't implement @@toPrimitive case
// and the second argument - flag - preferred type is a string
module.exports = function (it, S) {
  if (!isObject(it)) return it;
  var fn, val;
  if (S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
  if (typeof (fn = it.valueOf) == 'function' && !isObject(val = fn.call(it))) return val;
  if (!S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
  throw TypeError("Can't convert object to primitive value");
};


/***/ }),
/* 28 */
/***/ (function(module, exports) {

// 7.2.1 RequireObjectCoercible(argument)
module.exports = function (it) {
  if (it == undefined) throw TypeError("Can't call method on  " + it);
  return it;
};


/***/ }),
/* 29 */
/***/ (function(module, exports) {

// 7.1.4 ToInteger
var ceil = Math.ceil;
var floor = Math.floor;
module.exports = function (it) {
  return isNaN(it = +it) ? 0 : (it > 0 ? floor : ceil)(it);
};


/***/ }),
/* 30 */
/***/ (function(module, exports, __webpack_require__) {

// most Object methods by ES6 should accept primitives
var $export = __webpack_require__(0);
var core = __webpack_require__(26);
var fails = __webpack_require__(5);
module.exports = function (KEY, exec) {
  var fn = (core.Object || {})[KEY] || Object[KEY];
  var exp = {};
  exp[KEY] = exec(fn);
  $export($export.S + $export.F * fails(function () { fn(1); }), 'Object', exp);
};


/***/ }),
/* 31 */
/***/ (function(module, exports, __webpack_require__) {

// 0 -> Array#forEach
// 1 -> Array#map
// 2 -> Array#filter
// 3 -> Array#some
// 4 -> Array#every
// 5 -> Array#find
// 6 -> Array#findIndex
var ctx = __webpack_require__(23);
var IObject = __webpack_require__(53);
var toObject = __webpack_require__(12);
var toLength = __webpack_require__(11);
var asc = __webpack_require__(93);
module.exports = function (TYPE, $create) {
  var IS_MAP = TYPE == 1;
  var IS_FILTER = TYPE == 2;
  var IS_SOME = TYPE == 3;
  var IS_EVERY = TYPE == 4;
  var IS_FIND_INDEX = TYPE == 6;
  var NO_HOLES = TYPE == 5 || IS_FIND_INDEX;
  var create = $create || asc;
  return function ($this, callbackfn, that) {
    var O = toObject($this);
    var self = IObject(O);
    var f = ctx(callbackfn, that, 3);
    var length = toLength(self.length);
    var index = 0;
    var result = IS_MAP ? create($this, length) : IS_FILTER ? create($this, 0) : undefined;
    var val, res;
    for (;length > index; index++) if (NO_HOLES || index in self) {
      val = self[index];
      res = f(val, index, O);
      if (TYPE) {
        if (IS_MAP) result[index] = res;   // map
        else if (res) switch (TYPE) {
          case 3: return true;             // some
          case 5: return val;              // find
          case 6: return index;            // findIndex
          case 2: result.push(val);        // filter
        } else if (IS_EVERY) return false; // every
      }
    }
    return IS_FIND_INDEX ? -1 : IS_SOME || IS_EVERY ? IS_EVERY : result;
  };
};


/***/ }),
/* 32 */,
/* 33 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

if (__webpack_require__(9)) {
  var LIBRARY = __webpack_require__(39);
  var global = __webpack_require__(4);
  var fails = __webpack_require__(5);
  var $export = __webpack_require__(0);
  var $typed = __webpack_require__(66);
  var $buffer = __webpack_require__(99);
  var ctx = __webpack_require__(23);
  var anInstance = __webpack_require__(45);
  var propertyDesc = __webpack_require__(37);
  var hide = __webpack_require__(17);
  var redefineAll = __webpack_require__(47);
  var toInteger = __webpack_require__(29);
  var toLength = __webpack_require__(11);
  var toIndex = __webpack_require__(128);
  var toAbsoluteIndex = __webpack_require__(41);
  var toPrimitive = __webpack_require__(27);
  var has = __webpack_require__(16);
  var classof = __webpack_require__(55);
  var isObject = __webpack_require__(7);
  var toObject = __webpack_require__(12);
  var isArrayIter = __webpack_require__(90);
  var create = __webpack_require__(42);
  var getPrototypeOf = __webpack_require__(22);
  var gOPN = __webpack_require__(43).f;
  var getIterFn = __webpack_require__(92);
  var uid = __webpack_require__(38);
  var wks = __webpack_require__(8);
  var createArrayMethod = __webpack_require__(31);
  var createArrayIncludes = __webpack_require__(57);
  var speciesConstructor = __webpack_require__(64);
  var ArrayIterators = __webpack_require__(95);
  var Iterators = __webpack_require__(51);
  var $iterDetect = __webpack_require__(61);
  var setSpecies = __webpack_require__(44);
  var arrayFill = __webpack_require__(94);
  var arrayCopyWithin = __webpack_require__(118);
  var $DP = __webpack_require__(10);
  var $GOPD = __webpack_require__(21);
  var dP = $DP.f;
  var gOPD = $GOPD.f;
  var RangeError = global.RangeError;
  var TypeError = global.TypeError;
  var Uint8Array = global.Uint8Array;
  var ARRAY_BUFFER = 'ArrayBuffer';
  var SHARED_BUFFER = 'Shared' + ARRAY_BUFFER;
  var BYTES_PER_ELEMENT = 'BYTES_PER_ELEMENT';
  var PROTOTYPE = 'prototype';
  var ArrayProto = Array[PROTOTYPE];
  var $ArrayBuffer = $buffer.ArrayBuffer;
  var $DataView = $buffer.DataView;
  var arrayForEach = createArrayMethod(0);
  var arrayFilter = createArrayMethod(2);
  var arraySome = createArrayMethod(3);
  var arrayEvery = createArrayMethod(4);
  var arrayFind = createArrayMethod(5);
  var arrayFindIndex = createArrayMethod(6);
  var arrayIncludes = createArrayIncludes(true);
  var arrayIndexOf = createArrayIncludes(false);
  var arrayValues = ArrayIterators.values;
  var arrayKeys = ArrayIterators.keys;
  var arrayEntries = ArrayIterators.entries;
  var arrayLastIndexOf = ArrayProto.lastIndexOf;
  var arrayReduce = ArrayProto.reduce;
  var arrayReduceRight = ArrayProto.reduceRight;
  var arrayJoin = ArrayProto.join;
  var arraySort = ArrayProto.sort;
  var arraySlice = ArrayProto.slice;
  var arrayToString = ArrayProto.toString;
  var arrayToLocaleString = ArrayProto.toLocaleString;
  var ITERATOR = wks('iterator');
  var TAG = wks('toStringTag');
  var TYPED_CONSTRUCTOR = uid('typed_constructor');
  var DEF_CONSTRUCTOR = uid('def_constructor');
  var ALL_CONSTRUCTORS = $typed.CONSTR;
  var TYPED_ARRAY = $typed.TYPED;
  var VIEW = $typed.VIEW;
  var WRONG_LENGTH = 'Wrong length!';

  var $map = createArrayMethod(1, function (O, length) {
    return allocate(speciesConstructor(O, O[DEF_CONSTRUCTOR]), length);
  });

  var LITTLE_ENDIAN = fails(function () {
    // eslint-disable-next-line no-undef
    return new Uint8Array(new Uint16Array([1]).buffer)[0] === 1;
  });

  var FORCED_SET = !!Uint8Array && !!Uint8Array[PROTOTYPE].set && fails(function () {
    new Uint8Array(1).set({});
  });

  var toOffset = function (it, BYTES) {
    var offset = toInteger(it);
    if (offset < 0 || offset % BYTES) throw RangeError('Wrong offset!');
    return offset;
  };

  var validate = function (it) {
    if (isObject(it) && TYPED_ARRAY in it) return it;
    throw TypeError(it + ' is not a typed array!');
  };

  var allocate = function (C, length) {
    if (!(isObject(C) && TYPED_CONSTRUCTOR in C)) {
      throw TypeError('It is not a typed array constructor!');
    } return new C(length);
  };

  var speciesFromList = function (O, list) {
    return fromList(speciesConstructor(O, O[DEF_CONSTRUCTOR]), list);
  };

  var fromList = function (C, list) {
    var index = 0;
    var length = list.length;
    var result = allocate(C, length);
    while (length > index) result[index] = list[index++];
    return result;
  };

  var addGetter = function (it, key, internal) {
    dP(it, key, { get: function () { return this._d[internal]; } });
  };

  var $from = function from(source /* , mapfn, thisArg */) {
    var O = toObject(source);
    var aLen = arguments.length;
    var mapfn = aLen > 1 ? arguments[1] : undefined;
    var mapping = mapfn !== undefined;
    var iterFn = getIterFn(O);
    var i, length, values, result, step, iterator;
    if (iterFn != undefined && !isArrayIter(iterFn)) {
      for (iterator = iterFn.call(O), values = [], i = 0; !(step = iterator.next()).done; i++) {
        values.push(step.value);
      } O = values;
    }
    if (mapping && aLen > 2) mapfn = ctx(mapfn, arguments[2], 2);
    for (i = 0, length = toLength(O.length), result = allocate(this, length); length > i; i++) {
      result[i] = mapping ? mapfn(O[i], i) : O[i];
    }
    return result;
  };

  var $of = function of(/* ...items */) {
    var index = 0;
    var length = arguments.length;
    var result = allocate(this, length);
    while (length > index) result[index] = arguments[index++];
    return result;
  };

  // iOS Safari 6.x fails here
  var TO_LOCALE_BUG = !!Uint8Array && fails(function () { arrayToLocaleString.call(new Uint8Array(1)); });

  var $toLocaleString = function toLocaleString() {
    return arrayToLocaleString.apply(TO_LOCALE_BUG ? arraySlice.call(validate(this)) : validate(this), arguments);
  };

  var proto = {
    copyWithin: function copyWithin(target, start /* , end */) {
      return arrayCopyWithin.call(validate(this), target, start, arguments.length > 2 ? arguments[2] : undefined);
    },
    every: function every(callbackfn /* , thisArg */) {
      return arrayEvery(validate(this), callbackfn, arguments.length > 1 ? arguments[1] : undefined);
    },
    fill: function fill(value /* , start, end */) { // eslint-disable-line no-unused-vars
      return arrayFill.apply(validate(this), arguments);
    },
    filter: function filter(callbackfn /* , thisArg */) {
      return speciesFromList(this, arrayFilter(validate(this), callbackfn,
        arguments.length > 1 ? arguments[1] : undefined));
    },
    find: function find(predicate /* , thisArg */) {
      return arrayFind(validate(this), predicate, arguments.length > 1 ? arguments[1] : undefined);
    },
    findIndex: function findIndex(predicate /* , thisArg */) {
      return arrayFindIndex(validate(this), predicate, arguments.length > 1 ? arguments[1] : undefined);
    },
    forEach: function forEach(callbackfn /* , thisArg */) {
      arrayForEach(validate(this), callbackfn, arguments.length > 1 ? arguments[1] : undefined);
    },
    indexOf: function indexOf(searchElement /* , fromIndex */) {
      return arrayIndexOf(validate(this), searchElement, arguments.length > 1 ? arguments[1] : undefined);
    },
    includes: function includes(searchElement /* , fromIndex */) {
      return arrayIncludes(validate(this), searchElement, arguments.length > 1 ? arguments[1] : undefined);
    },
    join: function join(separator) { // eslint-disable-line no-unused-vars
      return arrayJoin.apply(validate(this), arguments);
    },
    lastIndexOf: function lastIndexOf(searchElement /* , fromIndex */) { // eslint-disable-line no-unused-vars
      return arrayLastIndexOf.apply(validate(this), arguments);
    },
    map: function map(mapfn /* , thisArg */) {
      return $map(validate(this), mapfn, arguments.length > 1 ? arguments[1] : undefined);
    },
    reduce: function reduce(callbackfn /* , initialValue */) { // eslint-disable-line no-unused-vars
      return arrayReduce.apply(validate(this), arguments);
    },
    reduceRight: function reduceRight(callbackfn /* , initialValue */) { // eslint-disable-line no-unused-vars
      return arrayReduceRight.apply(validate(this), arguments);
    },
    reverse: function reverse() {
      var that = this;
      var length = validate(that).length;
      var middle = Math.floor(length / 2);
      var index = 0;
      var value;
      while (index < middle) {
        value = that[index];
        that[index++] = that[--length];
        that[length] = value;
      } return that;
    },
    some: function some(callbackfn /* , thisArg */) {
      return arraySome(validate(this), callbackfn, arguments.length > 1 ? arguments[1] : undefined);
    },
    sort: function sort(comparefn) {
      return arraySort.call(validate(this), comparefn);
    },
    subarray: function subarray(begin, end) {
      var O = validate(this);
      var length = O.length;
      var $begin = toAbsoluteIndex(begin, length);
      return new (speciesConstructor(O, O[DEF_CONSTRUCTOR]))(
        O.buffer,
        O.byteOffset + $begin * O.BYTES_PER_ELEMENT,
        toLength((end === undefined ? length : toAbsoluteIndex(end, length)) - $begin)
      );
    }
  };

  var $slice = function slice(start, end) {
    return speciesFromList(this, arraySlice.call(validate(this), start, end));
  };

  var $set = function set(arrayLike /* , offset */) {
    validate(this);
    var offset = toOffset(arguments[1], 1);
    var length = this.length;
    var src = toObject(arrayLike);
    var len = toLength(src.length);
    var index = 0;
    if (len + offset > length) throw RangeError(WRONG_LENGTH);
    while (index < len) this[offset + index] = src[index++];
  };

  var $iterators = {
    entries: function entries() {
      return arrayEntries.call(validate(this));
    },
    keys: function keys() {
      return arrayKeys.call(validate(this));
    },
    values: function values() {
      return arrayValues.call(validate(this));
    }
  };

  var isTAIndex = function (target, key) {
    return isObject(target)
      && target[TYPED_ARRAY]
      && typeof key != 'symbol'
      && key in target
      && String(+key) == String(key);
  };
  var $getDesc = function getOwnPropertyDescriptor(target, key) {
    return isTAIndex(target, key = toPrimitive(key, true))
      ? propertyDesc(2, target[key])
      : gOPD(target, key);
  };
  var $setDesc = function defineProperty(target, key, desc) {
    if (isTAIndex(target, key = toPrimitive(key, true))
      && isObject(desc)
      && has(desc, 'value')
      && !has(desc, 'get')
      && !has(desc, 'set')
      // TODO: add validation descriptor w/o calling accessors
      && !desc.configurable
      && (!has(desc, 'writable') || desc.writable)
      && (!has(desc, 'enumerable') || desc.enumerable)
    ) {
      target[key] = desc.value;
      return target;
    } return dP(target, key, desc);
  };

  if (!ALL_CONSTRUCTORS) {
    $GOPD.f = $getDesc;
    $DP.f = $setDesc;
  }

  $export($export.S + $export.F * !ALL_CONSTRUCTORS, 'Object', {
    getOwnPropertyDescriptor: $getDesc,
    defineProperty: $setDesc
  });

  if (fails(function () { arrayToString.call({}); })) {
    arrayToString = arrayToLocaleString = function toString() {
      return arrayJoin.call(this);
    };
  }

  var $TypedArrayPrototype$ = redefineAll({}, proto);
  redefineAll($TypedArrayPrototype$, $iterators);
  hide($TypedArrayPrototype$, ITERATOR, $iterators.values);
  redefineAll($TypedArrayPrototype$, {
    slice: $slice,
    set: $set,
    constructor: function () { /* noop */ },
    toString: arrayToString,
    toLocaleString: $toLocaleString
  });
  addGetter($TypedArrayPrototype$, 'buffer', 'b');
  addGetter($TypedArrayPrototype$, 'byteOffset', 'o');
  addGetter($TypedArrayPrototype$, 'byteLength', 'l');
  addGetter($TypedArrayPrototype$, 'length', 'e');
  dP($TypedArrayPrototype$, TAG, {
    get: function () { return this[TYPED_ARRAY]; }
  });

  // eslint-disable-next-line max-statements
  module.exports = function (KEY, BYTES, wrapper, CLAMPED) {
    CLAMPED = !!CLAMPED;
    var NAME = KEY + (CLAMPED ? 'Clamped' : '') + 'Array';
    var GETTER = 'get' + KEY;
    var SETTER = 'set' + KEY;
    var TypedArray = global[NAME];
    var Base = TypedArray || {};
    var TAC = TypedArray && getPrototypeOf(TypedArray);
    var FORCED = !TypedArray || !$typed.ABV;
    var O = {};
    var TypedArrayPrototype = TypedArray && TypedArray[PROTOTYPE];
    var getter = function (that, index) {
      var data = that._d;
      return data.v[GETTER](index * BYTES + data.o, LITTLE_ENDIAN);
    };
    var setter = function (that, index, value) {
      var data = that._d;
      if (CLAMPED) value = (value = Math.round(value)) < 0 ? 0 : value > 0xff ? 0xff : value & 0xff;
      data.v[SETTER](index * BYTES + data.o, value, LITTLE_ENDIAN);
    };
    var addElement = function (that, index) {
      dP(that, index, {
        get: function () {
          return getter(this, index);
        },
        set: function (value) {
          return setter(this, index, value);
        },
        enumerable: true
      });
    };
    if (FORCED) {
      TypedArray = wrapper(function (that, data, $offset, $length) {
        anInstance(that, TypedArray, NAME, '_d');
        var index = 0;
        var offset = 0;
        var buffer, byteLength, length, klass;
        if (!isObject(data)) {
          length = toIndex(data);
          byteLength = length * BYTES;
          buffer = new $ArrayBuffer(byteLength);
        } else if (data instanceof $ArrayBuffer || (klass = classof(data)) == ARRAY_BUFFER || klass == SHARED_BUFFER) {
          buffer = data;
          offset = toOffset($offset, BYTES);
          var $len = data.byteLength;
          if ($length === undefined) {
            if ($len % BYTES) throw RangeError(WRONG_LENGTH);
            byteLength = $len - offset;
            if (byteLength < 0) throw RangeError(WRONG_LENGTH);
          } else {
            byteLength = toLength($length) * BYTES;
            if (byteLength + offset > $len) throw RangeError(WRONG_LENGTH);
          }
          length = byteLength / BYTES;
        } else if (TYPED_ARRAY in data) {
          return fromList(TypedArray, data);
        } else {
          return $from.call(TypedArray, data);
        }
        hide(that, '_d', {
          b: buffer,
          o: offset,
          l: byteLength,
          e: length,
          v: new $DataView(buffer)
        });
        while (index < length) addElement(that, index++);
      });
      TypedArrayPrototype = TypedArray[PROTOTYPE] = create($TypedArrayPrototype$);
      hide(TypedArrayPrototype, 'constructor', TypedArray);
    } else if (!fails(function () {
      TypedArray(1);
    }) || !fails(function () {
      new TypedArray(-1); // eslint-disable-line no-new
    }) || !$iterDetect(function (iter) {
      new TypedArray(); // eslint-disable-line no-new
      new TypedArray(null); // eslint-disable-line no-new
      new TypedArray(1.5); // eslint-disable-line no-new
      new TypedArray(iter); // eslint-disable-line no-new
    }, true)) {
      TypedArray = wrapper(function (that, data, $offset, $length) {
        anInstance(that, TypedArray, NAME);
        var klass;
        // `ws` module bug, temporarily remove validation length for Uint8Array
        // https://github.com/websockets/ws/pull/645
        if (!isObject(data)) return new Base(toIndex(data));
        if (data instanceof $ArrayBuffer || (klass = classof(data)) == ARRAY_BUFFER || klass == SHARED_BUFFER) {
          return $length !== undefined
            ? new Base(data, toOffset($offset, BYTES), $length)
            : $offset !== undefined
              ? new Base(data, toOffset($offset, BYTES))
              : new Base(data);
        }
        if (TYPED_ARRAY in data) return fromList(TypedArray, data);
        return $from.call(TypedArray, data);
      });
      arrayForEach(TAC !== Function.prototype ? gOPN(Base).concat(gOPN(TAC)) : gOPN(Base), function (key) {
        if (!(key in TypedArray)) hide(TypedArray, key, Base[key]);
      });
      TypedArray[PROTOTYPE] = TypedArrayPrototype;
      if (!LIBRARY) TypedArrayPrototype.constructor = TypedArray;
    }
    var $nativeIterator = TypedArrayPrototype[ITERATOR];
    var CORRECT_ITER_NAME = !!$nativeIterator
      && ($nativeIterator.name == 'values' || $nativeIterator.name == undefined);
    var $iterator = $iterators.values;
    hide(TypedArray, TYPED_CONSTRUCTOR, true);
    hide(TypedArrayPrototype, TYPED_ARRAY, NAME);
    hide(TypedArrayPrototype, VIEW, true);
    hide(TypedArrayPrototype, DEF_CONSTRUCTOR, TypedArray);

    if (CLAMPED ? new TypedArray(1)[TAG] != NAME : !(TAG in TypedArrayPrototype)) {
      dP(TypedArrayPrototype, TAG, {
        get: function () { return NAME; }
      });
    }

    O[NAME] = TypedArray;

    $export($export.G + $export.W + $export.F * (TypedArray != Base), O);

    $export($export.S, NAME, {
      BYTES_PER_ELEMENT: BYTES
    });

    $export($export.S + $export.F * fails(function () { Base.of.call(TypedArray, 1); }), NAME, {
      from: $from,
      of: $of
    });

    if (!(BYTES_PER_ELEMENT in TypedArrayPrototype)) hide(TypedArrayPrototype, BYTES_PER_ELEMENT, BYTES);

    $export($export.P, NAME, proto);

    setSpecies(NAME);

    $export($export.P + $export.F * FORCED_SET, NAME, { set: $set });

    $export($export.P + $export.F * !CORRECT_ITER_NAME, NAME, $iterators);

    if (!LIBRARY && TypedArrayPrototype.toString != arrayToString) TypedArrayPrototype.toString = arrayToString;

    $export($export.P + $export.F * fails(function () {
      new TypedArray(1).slice();
    }), NAME, { slice: $slice });

    $export($export.P + $export.F * (fails(function () {
      return [1, 2].toLocaleString() != new TypedArray([1, 2]).toLocaleString();
    }) || !fails(function () {
      TypedArrayPrototype.toLocaleString.call([1, 2]);
    })), NAME, { toLocaleString: $toLocaleString });

    Iterators[NAME] = CORRECT_ITER_NAME ? $nativeIterator : $iterator;
    if (!LIBRARY && !CORRECT_ITER_NAME) hide(TypedArrayPrototype, ITERATOR, $iterator);
  };
} else module.exports = function () { /* empty */ };


/***/ }),
/* 34 */
/***/ (function(module, exports, __webpack_require__) {

var Map = __webpack_require__(123);
var $export = __webpack_require__(0);
var shared = __webpack_require__(56)('metadata');
var store = shared.store || (shared.store = new (__webpack_require__(126))());

var getOrCreateMetadataMap = function (target, targetKey, create) {
  var targetMetadata = store.get(target);
  if (!targetMetadata) {
    if (!create) return undefined;
    store.set(target, targetMetadata = new Map());
  }
  var keyMetadata = targetMetadata.get(targetKey);
  if (!keyMetadata) {
    if (!create) return undefined;
    targetMetadata.set(targetKey, keyMetadata = new Map());
  } return keyMetadata;
};
var ordinaryHasOwnMetadata = function (MetadataKey, O, P) {
  var metadataMap = getOrCreateMetadataMap(O, P, false);
  return metadataMap === undefined ? false : metadataMap.has(MetadataKey);
};
var ordinaryGetOwnMetadata = function (MetadataKey, O, P) {
  var metadataMap = getOrCreateMetadataMap(O, P, false);
  return metadataMap === undefined ? undefined : metadataMap.get(MetadataKey);
};
var ordinaryDefineOwnMetadata = function (MetadataKey, MetadataValue, O, P) {
  getOrCreateMetadataMap(O, P, true).set(MetadataKey, MetadataValue);
};
var ordinaryOwnMetadataKeys = function (target, targetKey) {
  var metadataMap = getOrCreateMetadataMap(target, targetKey, false);
  var keys = [];
  if (metadataMap) metadataMap.forEach(function (_, key) { keys.push(key); });
  return keys;
};
var toMetaKey = function (it) {
  return it === undefined || typeof it == 'symbol' ? it : String(it);
};
var exp = function (O) {
  $export($export.S, 'Reflect', O);
};

module.exports = {
  store: store,
  map: getOrCreateMetadataMap,
  has: ordinaryHasOwnMetadata,
  get: ordinaryGetOwnMetadata,
  set: ordinaryDefineOwnMetadata,
  keys: ordinaryOwnMetadataKeys,
  key: toMetaKey,
  exp: exp
};


/***/ }),
/* 35 */
/***/ (function(module, exports, __webpack_require__) {

var META = __webpack_require__(38)('meta');
var isObject = __webpack_require__(7);
var has = __webpack_require__(16);
var setDesc = __webpack_require__(10).f;
var id = 0;
var isExtensible = Object.isExtensible || function () {
  return true;
};
var FREEZE = !__webpack_require__(5)(function () {
  return isExtensible(Object.preventExtensions({}));
});
var setMeta = function (it) {
  setDesc(it, META, { value: {
    i: 'O' + ++id, // object ID
    w: {}          // weak collections IDs
  } });
};
var fastKey = function (it, create) {
  // return primitive with prefix
  if (!isObject(it)) return typeof it == 'symbol' ? it : (typeof it == 'string' ? 'S' : 'P') + it;
  if (!has(it, META)) {
    // can't set metadata to uncaught frozen object
    if (!isExtensible(it)) return 'F';
    // not necessary to add metadata
    if (!create) return 'E';
    // add missing metadata
    setMeta(it);
  // return object ID
  } return it[META].i;
};
var getWeak = function (it, create) {
  if (!has(it, META)) {
    // can't set metadata to uncaught frozen object
    if (!isExtensible(it)) return true;
    // not necessary to add metadata
    if (!create) return false;
    // add missing metadata
    setMeta(it);
  // return hash weak collections IDs
  } return it[META].w;
};
// add metadata on freeze-family methods calling
var onFreeze = function (it) {
  if (FREEZE && meta.NEED && isExtensible(it) && !has(it, META)) setMeta(it);
  return it;
};
var meta = module.exports = {
  KEY: META,
  NEED: false,
  fastKey: fastKey,
  getWeak: getWeak,
  onFreeze: onFreeze
};


/***/ }),
/* 36 */
/***/ (function(module, exports, __webpack_require__) {

// 22.1.3.31 Array.prototype[@@unscopables]
var UNSCOPABLES = __webpack_require__(8)('unscopables');
var ArrayProto = Array.prototype;
if (ArrayProto[UNSCOPABLES] == undefined) __webpack_require__(17)(ArrayProto, UNSCOPABLES, {});
module.exports = function (key) {
  ArrayProto[UNSCOPABLES][key] = true;
};


/***/ }),
/* 37 */
/***/ (function(module, exports) {

module.exports = function (bitmap, value) {
  return {
    enumerable: !(bitmap & 1),
    configurable: !(bitmap & 2),
    writable: !(bitmap & 4),
    value: value
  };
};


/***/ }),
/* 38 */
/***/ (function(module, exports) {

var id = 0;
var px = Math.random();
module.exports = function (key) {
  return 'Symbol('.concat(key === undefined ? '' : key, ')_', (++id + px).toString(36));
};


/***/ }),
/* 39 */
/***/ (function(module, exports) {

module.exports = false;


/***/ }),
/* 40 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.14 / 15.2.3.14 Object.keys(O)
var $keys = __webpack_require__(104);
var enumBugKeys = __webpack_require__(77);

module.exports = Object.keys || function keys(O) {
  return $keys(O, enumBugKeys);
};


/***/ }),
/* 41 */
/***/ (function(module, exports, __webpack_require__) {

var toInteger = __webpack_require__(29);
var max = Math.max;
var min = Math.min;
module.exports = function (index, length) {
  index = toInteger(index);
  return index < 0 ? max(index + length, 0) : min(index, length);
};


/***/ }),
/* 42 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
var anObject = __webpack_require__(3);
var dPs = __webpack_require__(105);
var enumBugKeys = __webpack_require__(77);
var IE_PROTO = __webpack_require__(76)('IE_PROTO');
var Empty = function () { /* empty */ };
var PROTOTYPE = 'prototype';

// Create object with fake `null` prototype: use iframe Object with cleared prototype
var createDict = function () {
  // Thrash, waste and sodomy: IE GC bug
  var iframe = __webpack_require__(74)('iframe');
  var i = enumBugKeys.length;
  var lt = '<';
  var gt = '>';
  var iframeDocument;
  iframe.style.display = 'none';
  __webpack_require__(78).appendChild(iframe);
  iframe.src = 'javascript:'; // eslint-disable-line no-script-url
  // createDict = iframe.contentWindow.Object;
  // html.removeChild(iframe);
  iframeDocument = iframe.contentWindow.document;
  iframeDocument.open();
  iframeDocument.write(lt + 'script' + gt + 'document.F=Object' + lt + '/script' + gt);
  iframeDocument.close();
  createDict = iframeDocument.F;
  while (i--) delete createDict[PROTOTYPE][enumBugKeys[i]];
  return createDict();
};

module.exports = Object.create || function create(O, Properties) {
  var result;
  if (O !== null) {
    Empty[PROTOTYPE] = anObject(O);
    result = new Empty();
    Empty[PROTOTYPE] = null;
    // add "__proto__" for Object.getPrototypeOf polyfill
    result[IE_PROTO] = O;
  } else result = createDict();
  return Properties === undefined ? result : dPs(result, Properties);
};


/***/ }),
/* 43 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.7 / 15.2.3.4 Object.getOwnPropertyNames(O)
var $keys = __webpack_require__(104);
var hiddenKeys = __webpack_require__(77).concat('length', 'prototype');

exports.f = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
  return $keys(O, hiddenKeys);
};


/***/ }),
/* 44 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var global = __webpack_require__(4);
var dP = __webpack_require__(10);
var DESCRIPTORS = __webpack_require__(9);
var SPECIES = __webpack_require__(8)('species');

module.exports = function (KEY) {
  var C = global[KEY];
  if (DESCRIPTORS && C && !C[SPECIES]) dP.f(C, SPECIES, {
    configurable: true,
    get: function () { return this; }
  });
};


/***/ }),
/* 45 */
/***/ (function(module, exports) {

module.exports = function (it, Constructor, name, forbiddenField) {
  if (!(it instanceof Constructor) || (forbiddenField !== undefined && forbiddenField in it)) {
    throw TypeError(name + ': incorrect invocation!');
  } return it;
};


/***/ }),
/* 46 */
/***/ (function(module, exports, __webpack_require__) {

var ctx = __webpack_require__(23);
var call = __webpack_require__(116);
var isArrayIter = __webpack_require__(90);
var anObject = __webpack_require__(3);
var toLength = __webpack_require__(11);
var getIterFn = __webpack_require__(92);
var BREAK = {};
var RETURN = {};
var exports = module.exports = function (iterable, entries, fn, that, ITERATOR) {
  var iterFn = ITERATOR ? function () { return iterable; } : getIterFn(iterable);
  var f = ctx(fn, that, entries ? 2 : 1);
  var index = 0;
  var length, step, iterator, result;
  if (typeof iterFn != 'function') throw TypeError(iterable + ' is not iterable!');
  // fast case for arrays with default iterator
  if (isArrayIter(iterFn)) for (length = toLength(iterable.length); length > index; index++) {
    result = entries ? f(anObject(step = iterable[index])[0], step[1]) : f(iterable[index]);
    if (result === BREAK || result === RETURN) return result;
  } else for (iterator = iterFn.call(iterable); !(step = iterator.next()).done;) {
    result = call(iterator, f, step.value, entries);
    if (result === BREAK || result === RETURN) return result;
  }
};
exports.BREAK = BREAK;
exports.RETURN = RETURN;


/***/ }),
/* 47 */
/***/ (function(module, exports, __webpack_require__) {

var redefine = __webpack_require__(18);
module.exports = function (target, src, safe) {
  for (var key in src) redefine(target, key, src[key], safe);
  return target;
};


/***/ }),
/* 48 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getToolkitStorageKey = getToolkitStorageKey;
exports.setToolkitStorageKey = setToolkitStorageKey;
exports.removeToolkitStorageKey = removeToolkitStorageKey;
exports.i10n = i10n;
var STORAGE_KEY_PREFIX = 'ynab-toolkit-';

function getToolkitStorageKey(key, type) {
  var value = localStorage.getItem(STORAGE_KEY_PREFIX + key);

  switch (type) {
    case 'boolean':
      return value === 'true';
    case 'number':
      return Number(value);
    default:
      return value;
  }
}

function setToolkitStorageKey(key, value) {
  return localStorage.setItem(STORAGE_KEY_PREFIX + key, value);
}

function removeToolkitStorageKey(key) {
  return localStorage.removeItem(STORAGE_KEY_PREFIX + key);
}

function i10n(key, defaultValue) {
  return ynabToolKit.l10nData && ynabToolKit.l10nData[key] || defaultValue;
}

/***/ }),
/* 49 */
/***/ (function(module, exports, __webpack_require__) {

var def = __webpack_require__(10).f;
var has = __webpack_require__(16);
var TAG = __webpack_require__(8)('toStringTag');

module.exports = function (it, tag, stat) {
  if (it && !has(it = stat ? it : it.prototype, TAG)) def(it, TAG, { configurable: true, value: tag });
};


/***/ }),
/* 50 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var defined = __webpack_require__(28);
var fails = __webpack_require__(5);
var spaces = __webpack_require__(80);
var space = '[' + spaces + ']';
var non = '\u200b\u0085';
var ltrim = RegExp('^' + space + space + '*');
var rtrim = RegExp(space + space + '*$');

var exporter = function (KEY, exec, ALIAS) {
  var exp = {};
  var FORCE = fails(function () {
    return !!spaces[KEY]() || non[KEY]() != non;
  });
  var fn = exp[KEY] = FORCE ? exec(trim) : spaces[KEY];
  if (ALIAS) exp[ALIAS] = fn;
  $export($export.P + $export.F * FORCE, 'String', exp);
};

// 1 -> String#trimLeft
// 2 -> String#trimRight
// 3 -> String#trim
var trim = exporter.trim = function (string, TYPE) {
  string = String(defined(string));
  if (TYPE & 1) string = string.replace(ltrim, '');
  if (TYPE & 2) string = string.replace(rtrim, '');
  return string;
};

module.exports = exporter;


/***/ }),
/* 51 */
/***/ (function(module, exports) {

module.exports = {};


/***/ }),
/* 52 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(7);
module.exports = function (it, TYPE) {
  if (!isObject(it) || it._t !== TYPE) throw TypeError('Incompatible receiver, ' + TYPE + ' required!');
  return it;
};


/***/ }),
/* 53 */
/***/ (function(module, exports, __webpack_require__) {

// fallback for non-array-like ES3 and non-enumerable old V8 strings
var cof = __webpack_require__(24);
// eslint-disable-next-line no-prototype-builtins
module.exports = Object('z').propertyIsEnumerable(0) ? Object : function (it) {
  return cof(it) == 'String' ? it.split('') : Object(it);
};


/***/ }),
/* 54 */
/***/ (function(module, exports) {

exports.f = {}.propertyIsEnumerable;


/***/ }),
/* 55 */
/***/ (function(module, exports, __webpack_require__) {

// getting tag from 19.1.3.6 Object.prototype.toString()
var cof = __webpack_require__(24);
var TAG = __webpack_require__(8)('toStringTag');
// ES3 wrong here
var ARG = cof(function () { return arguments; }()) == 'Arguments';

// fallback for IE11 Script Access Denied error
var tryGet = function (it, key) {
  try {
    return it[key];
  } catch (e) { /* empty */ }
};

module.exports = function (it) {
  var O, T, B;
  return it === undefined ? 'Undefined' : it === null ? 'Null'
    // @@toStringTag case
    : typeof (T = tryGet(O = Object(it), TAG)) == 'string' ? T
    // builtinTag case
    : ARG ? cof(O)
    // ES3 arguments fallback
    : (B = cof(O)) == 'Object' && typeof O.callee == 'function' ? 'Arguments' : B;
};


/***/ }),
/* 56 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(4);
var SHARED = '__core-js_shared__';
var store = global[SHARED] || (global[SHARED] = {});
module.exports = function (key) {
  return store[key] || (store[key] = {});
};


/***/ }),
/* 57 */
/***/ (function(module, exports, __webpack_require__) {

// false -> Array#indexOf
// true  -> Array#includes
var toIObject = __webpack_require__(20);
var toLength = __webpack_require__(11);
var toAbsoluteIndex = __webpack_require__(41);
module.exports = function (IS_INCLUDES) {
  return function ($this, el, fromIndex) {
    var O = toIObject($this);
    var length = toLength(O.length);
    var index = toAbsoluteIndex(fromIndex, length);
    var value;
    // Array#includes uses SameValueZero equality algorithm
    // eslint-disable-next-line no-self-compare
    if (IS_INCLUDES && el != el) while (length > index) {
      value = O[index++];
      // eslint-disable-next-line no-self-compare
      if (value != value) return true;
    // Array#indexOf ignores holes, Array#includes - not
    } else for (;length > index; index++) if (IS_INCLUDES || index in O) {
      if (O[index] === el) return IS_INCLUDES || index || 0;
    } return !IS_INCLUDES && -1;
  };
};


/***/ }),
/* 58 */
/***/ (function(module, exports) {

exports.f = Object.getOwnPropertySymbols;


/***/ }),
/* 59 */
/***/ (function(module, exports, __webpack_require__) {

// 7.2.2 IsArray(argument)
var cof = __webpack_require__(24);
module.exports = Array.isArray || function isArray(arg) {
  return cof(arg) == 'Array';
};


/***/ }),
/* 60 */
/***/ (function(module, exports, __webpack_require__) {

// 7.2.8 IsRegExp(argument)
var isObject = __webpack_require__(7);
var cof = __webpack_require__(24);
var MATCH = __webpack_require__(8)('match');
module.exports = function (it) {
  var isRegExp;
  return isObject(it) && ((isRegExp = it[MATCH]) !== undefined ? !!isRegExp : cof(it) == 'RegExp');
};


/***/ }),
/* 61 */
/***/ (function(module, exports, __webpack_require__) {

var ITERATOR = __webpack_require__(8)('iterator');
var SAFE_CLOSING = false;

try {
  var riter = [7][ITERATOR]();
  riter['return'] = function () { SAFE_CLOSING = true; };
  // eslint-disable-next-line no-throw-literal
  Array.from(riter, function () { throw 2; });
} catch (e) { /* empty */ }

module.exports = function (exec, skipClosing) {
  if (!skipClosing && !SAFE_CLOSING) return false;
  var safe = false;
  try {
    var arr = [7];
    var iter = arr[ITERATOR]();
    iter.next = function () { return { done: safe = true }; };
    arr[ITERATOR] = function () { return iter; };
    exec(arr);
  } catch (e) { /* empty */ }
  return safe;
};


/***/ }),
/* 62 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 21.2.5.3 get RegExp.prototype.flags
var anObject = __webpack_require__(3);
module.exports = function () {
  var that = anObject(this);
  var result = '';
  if (that.global) result += 'g';
  if (that.ignoreCase) result += 'i';
  if (that.multiline) result += 'm';
  if (that.unicode) result += 'u';
  if (that.sticky) result += 'y';
  return result;
};


/***/ }),
/* 63 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var hide = __webpack_require__(17);
var redefine = __webpack_require__(18);
var fails = __webpack_require__(5);
var defined = __webpack_require__(28);
var wks = __webpack_require__(8);

module.exports = function (KEY, length, exec) {
  var SYMBOL = wks(KEY);
  var fns = exec(defined, SYMBOL, ''[KEY]);
  var strfn = fns[0];
  var rxfn = fns[1];
  if (fails(function () {
    var O = {};
    O[SYMBOL] = function () { return 7; };
    return ''[KEY](O) != 7;
  })) {
    redefine(String.prototype, KEY, strfn);
    hide(RegExp.prototype, SYMBOL, length == 2
      // 21.2.5.8 RegExp.prototype[@@replace](string, replaceValue)
      // 21.2.5.11 RegExp.prototype[@@split](string, limit)
      ? function (string, arg) { return rxfn.call(string, this, arg); }
      // 21.2.5.6 RegExp.prototype[@@match](string)
      // 21.2.5.9 RegExp.prototype[@@search](string)
      : function (string) { return rxfn.call(string, this); }
    );
  }
};


/***/ }),
/* 64 */
/***/ (function(module, exports, __webpack_require__) {

// 7.3.20 SpeciesConstructor(O, defaultConstructor)
var anObject = __webpack_require__(3);
var aFunction = __webpack_require__(14);
var SPECIES = __webpack_require__(8)('species');
module.exports = function (O, D) {
  var C = anObject(O).constructor;
  var S;
  return C === undefined || (S = anObject(C)[SPECIES]) == undefined ? D : aFunction(S);
};


/***/ }),
/* 65 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var global = __webpack_require__(4);
var $export = __webpack_require__(0);
var redefine = __webpack_require__(18);
var redefineAll = __webpack_require__(47);
var meta = __webpack_require__(35);
var forOf = __webpack_require__(46);
var anInstance = __webpack_require__(45);
var isObject = __webpack_require__(7);
var fails = __webpack_require__(5);
var $iterDetect = __webpack_require__(61);
var setToStringTag = __webpack_require__(49);
var inheritIfRequired = __webpack_require__(81);

module.exports = function (NAME, wrapper, methods, common, IS_MAP, IS_WEAK) {
  var Base = global[NAME];
  var C = Base;
  var ADDER = IS_MAP ? 'set' : 'add';
  var proto = C && C.prototype;
  var O = {};
  var fixMethod = function (KEY) {
    var fn = proto[KEY];
    redefine(proto, KEY,
      KEY == 'delete' ? function (a) {
        return IS_WEAK && !isObject(a) ? false : fn.call(this, a === 0 ? 0 : a);
      } : KEY == 'has' ? function has(a) {
        return IS_WEAK && !isObject(a) ? false : fn.call(this, a === 0 ? 0 : a);
      } : KEY == 'get' ? function get(a) {
        return IS_WEAK && !isObject(a) ? undefined : fn.call(this, a === 0 ? 0 : a);
      } : KEY == 'add' ? function add(a) { fn.call(this, a === 0 ? 0 : a); return this; }
        : function set(a, b) { fn.call(this, a === 0 ? 0 : a, b); return this; }
    );
  };
  if (typeof C != 'function' || !(IS_WEAK || proto.forEach && !fails(function () {
    new C().entries().next();
  }))) {
    // create collection constructor
    C = common.getConstructor(wrapper, NAME, IS_MAP, ADDER);
    redefineAll(C.prototype, methods);
    meta.NEED = true;
  } else {
    var instance = new C();
    // early implementations not supports chaining
    var HASNT_CHAINING = instance[ADDER](IS_WEAK ? {} : -0, 1) != instance;
    // V8 ~  Chromium 40- weak-collections throws on primitives, but should return false
    var THROWS_ON_PRIMITIVES = fails(function () { instance.has(1); });
    // most early implementations doesn't supports iterables, most modern - not close it correctly
    var ACCEPT_ITERABLES = $iterDetect(function (iter) { new C(iter); }); // eslint-disable-line no-new
    // for early implementations -0 and +0 not the same
    var BUGGY_ZERO = !IS_WEAK && fails(function () {
      // V8 ~ Chromium 42- fails only with 5+ elements
      var $instance = new C();
      var index = 5;
      while (index--) $instance[ADDER](index, index);
      return !$instance.has(-0);
    });
    if (!ACCEPT_ITERABLES) {
      C = wrapper(function (target, iterable) {
        anInstance(target, C, NAME);
        var that = inheritIfRequired(new Base(), target, C);
        if (iterable != undefined) forOf(iterable, IS_MAP, that[ADDER], that);
        return that;
      });
      C.prototype = proto;
      proto.constructor = C;
    }
    if (THROWS_ON_PRIMITIVES || BUGGY_ZERO) {
      fixMethod('delete');
      fixMethod('has');
      IS_MAP && fixMethod('get');
    }
    if (BUGGY_ZERO || HASNT_CHAINING) fixMethod(ADDER);
    // weak collections should not contains .clear method
    if (IS_WEAK && proto.clear) delete proto.clear;
  }

  setToStringTag(C, NAME);

  O[NAME] = C;
  $export($export.G + $export.W + $export.F * (C != Base), O);

  if (!IS_WEAK) common.setStrong(C, NAME, IS_MAP);

  return C;
};


/***/ }),
/* 66 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(4);
var hide = __webpack_require__(17);
var uid = __webpack_require__(38);
var TYPED = uid('typed_array');
var VIEW = uid('view');
var ABV = !!(global.ArrayBuffer && global.DataView);
var CONSTR = ABV;
var i = 0;
var l = 9;
var Typed;

var TypedArrayConstructors = (
  'Int8Array,Uint8Array,Uint8ClampedArray,Int16Array,Uint16Array,Int32Array,Uint32Array,Float32Array,Float64Array'
).split(',');

while (i < l) {
  if (Typed = global[TypedArrayConstructors[i++]]) {
    hide(Typed.prototype, TYPED, true);
    hide(Typed.prototype, VIEW, true);
  } else CONSTR = false;
}

module.exports = {
  ABV: ABV,
  CONSTR: CONSTR,
  TYPED: TYPED,
  VIEW: VIEW
};


/***/ }),
/* 67 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// Forced replacement prototype accessors methods
module.exports = __webpack_require__(39) || !__webpack_require__(5)(function () {
  var K = Math.random();
  // In FF throws only define methods
  // eslint-disable-next-line no-undef, no-useless-call
  __defineSetter__.call(null, K, function () { /* empty */ });
  delete __webpack_require__(4)[K];
});


/***/ }),
/* 68 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://tc39.github.io/proposal-setmap-offrom/
var $export = __webpack_require__(0);

module.exports = function (COLLECTION) {
  $export($export.S, COLLECTION, { of: function of() {
    var length = arguments.length;
    var A = Array(length);
    while (length--) A[length] = arguments[length];
    return new this(A);
  } });
};


/***/ }),
/* 69 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://tc39.github.io/proposal-setmap-offrom/
var $export = __webpack_require__(0);
var aFunction = __webpack_require__(14);
var ctx = __webpack_require__(23);
var forOf = __webpack_require__(46);

module.exports = function (COLLECTION) {
  $export($export.S, COLLECTION, { from: function from(source /* , mapFn, thisArg */) {
    var mapFn = arguments[1];
    var mapping, A, n, cb;
    aFunction(this);
    mapping = mapFn !== undefined;
    if (mapping) aFunction(mapFn);
    if (source == undefined) return new this();
    A = [];
    if (mapping) {
      n = 0;
      cb = ctx(mapFn, arguments[2], 2);
      forOf(source, false, function (nextItem) {
        A.push(cb(nextItem, n++));
      });
    } else {
      forOf(source, false, A.push, A);
    }
    return new this(A);
  } });
};


/***/ }),
/* 70 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var TransactionGridFeature = exports.TransactionGridFeature = function () {
  function TransactionGridFeature() {
    _classCallCheck(this, TransactionGridFeature);
  }

  _createClass(TransactionGridFeature, [{
    key: 'injectCSS',

    // Injects css into the DOM if needed for the feature
    value: function injectCSS() {
      return '';
    }

    // Inserts the header for your additional column

  }, {
    key: 'insertHeader',
    value: function insertHeader() {}

    // Should remove all additional column related elements from the page

  }, {
    key: 'cleanup',
    value: function cleanup() {}

    // Can return a promise, will get called during the normal willInvoke cycle
    // of a feature.

  }, {
    key: 'willInvoke',
    value: function willInvoke() {}

    // Should return a boolean that informs AdditionalColumns feature that it
    // is on a page that should receive the new column.

  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {}

    // Called during the lifecycle event `didUpdate` in Ember for an Ember Component.

  }, {
    key: 'didUpdate',
    value: function didUpdate() {}

    // Called when one of the grid rows is getting inserted into the dom but
    // before it actually makes it into the dom. This should be doing the grunt
    // of the work.

  }, {
    key: 'willInsertColumn',
    value: function willInsertColumn() {}

    // Called for all the rows that don't need the column data.

  }, {
    key: 'willInsertDeadColumn',
    value: function willInsertDeadColumn() {}

    // this is really hacky but I'm not sure what else to do, most of these components
    // double render so the `willInsertElement` works for those but the add rows
    // and footer are weird. add-rows doesn't double render and will work every time
    // after the component has been cached but footer is _always_ a new component WutFace

  }, {
    key: 'handleSingleRenderColumn',
    value: function handleSingleRenderColumn() {}
  }]);

  return TransactionGridFeature;
}();

/***/ }),
/* 71 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".budget-table-row.is-sub-category > .budget-table-cell-available .positive,\n.budget-table-row.is-sub-category > .budget-table-cell-available .negative,\n.budget-table-row.is-sub-category > .budget-table-cell-available .cautious,\n.budget-table-row.is-sub-category > .budget-table-cell-available .zero {\n    font-size: .9285em;\n}\n\n.budget-table-header .budget-table-cell-button, .budget-table-row .budget-table-cell-button {\n    font-size: .9285em;\n}\n", ""]);

// exports


/***/ }),
/* 72 */,
/* 73 */,
/* 74 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(7);
var document = __webpack_require__(4).document;
// typeof document.createElement is 'object' in old IE
var is = isObject(document) && isObject(document.createElement);
module.exports = function (it) {
  return is ? document.createElement(it) : {};
};


/***/ }),
/* 75 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(4);
var core = __webpack_require__(26);
var LIBRARY = __webpack_require__(39);
var wksExt = __webpack_require__(103);
var defineProperty = __webpack_require__(10).f;
module.exports = function (name) {
  var $Symbol = core.Symbol || (core.Symbol = LIBRARY ? {} : global.Symbol || {});
  if (name.charAt(0) != '_' && !(name in $Symbol)) defineProperty($Symbol, name, { value: wksExt.f(name) });
};


/***/ }),
/* 76 */
/***/ (function(module, exports, __webpack_require__) {

var shared = __webpack_require__(56)('keys');
var uid = __webpack_require__(38);
module.exports = function (key) {
  return shared[key] || (shared[key] = uid(key));
};


/***/ }),
/* 77 */
/***/ (function(module, exports) {

// IE 8- don't enum bug keys
module.exports = (
  'constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf'
).split(',');


/***/ }),
/* 78 */
/***/ (function(module, exports, __webpack_require__) {

var document = __webpack_require__(4).document;
module.exports = document && document.documentElement;


/***/ }),
/* 79 */
/***/ (function(module, exports, __webpack_require__) {

// Works with __proto__ only. Old v8 can't work with null proto objects.
/* eslint-disable no-proto */
var isObject = __webpack_require__(7);
var anObject = __webpack_require__(3);
var check = function (O, proto) {
  anObject(O);
  if (!isObject(proto) && proto !== null) throw TypeError(proto + ": can't set as prototype!");
};
module.exports = {
  set: Object.setPrototypeOf || ('__proto__' in {} ? // eslint-disable-line
    function (test, buggy, set) {
      try {
        set = __webpack_require__(23)(Function.call, __webpack_require__(21).f(Object.prototype, '__proto__').set, 2);
        set(test, []);
        buggy = !(test instanceof Array);
      } catch (e) { buggy = true; }
      return function setPrototypeOf(O, proto) {
        check(O, proto);
        if (buggy) O.__proto__ = proto;
        else set(O, proto);
        return O;
      };
    }({}, false) : undefined),
  check: check
};


/***/ }),
/* 80 */
/***/ (function(module, exports) {

module.exports = '\x09\x0A\x0B\x0C\x0D\x20\xA0\u1680\u180E\u2000\u2001\u2002\u2003' +
  '\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028\u2029\uFEFF';


/***/ }),
/* 81 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(7);
var setPrototypeOf = __webpack_require__(79).set;
module.exports = function (that, target, C) {
  var S = target.constructor;
  var P;
  if (S !== C && typeof S == 'function' && (P = S.prototype) !== C.prototype && isObject(P) && setPrototypeOf) {
    setPrototypeOf(that, P);
  } return that;
};


/***/ }),
/* 82 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var toInteger = __webpack_require__(29);
var defined = __webpack_require__(28);

module.exports = function repeat(count) {
  var str = String(defined(this));
  var res = '';
  var n = toInteger(count);
  if (n < 0 || n == Infinity) throw RangeError("Count can't be negative");
  for (;n > 0; (n >>>= 1) && (str += str)) if (n & 1) res += str;
  return res;
};


/***/ }),
/* 83 */
/***/ (function(module, exports) {

// 20.2.2.28 Math.sign(x)
module.exports = Math.sign || function sign(x) {
  // eslint-disable-next-line no-self-compare
  return (x = +x) == 0 || x != x ? x : x < 0 ? -1 : 1;
};


/***/ }),
/* 84 */
/***/ (function(module, exports) {

// 20.2.2.14 Math.expm1(x)
var $expm1 = Math.expm1;
module.exports = (!$expm1
  // Old FF bug
  || $expm1(10) > 22025.465794806719 || $expm1(10) < 22025.4657948067165168
  // Tor Browser bug
  || $expm1(-2e-17) != -2e-17
) ? function expm1(x) {
  return (x = +x) == 0 ? x : x > -1e-6 && x < 1e-6 ? x + x * x / 2 : Math.exp(x) - 1;
} : $expm1;


/***/ }),
/* 85 */
/***/ (function(module, exports, __webpack_require__) {

var toInteger = __webpack_require__(29);
var defined = __webpack_require__(28);
// true  -> String#at
// false -> String#codePointAt
module.exports = function (TO_STRING) {
  return function (that, pos) {
    var s = String(defined(that));
    var i = toInteger(pos);
    var l = s.length;
    var a, b;
    if (i < 0 || i >= l) return TO_STRING ? '' : undefined;
    a = s.charCodeAt(i);
    return a < 0xd800 || a > 0xdbff || i + 1 === l || (b = s.charCodeAt(i + 1)) < 0xdc00 || b > 0xdfff
      ? TO_STRING ? s.charAt(i) : a
      : TO_STRING ? s.slice(i, i + 2) : (a - 0xd800 << 10) + (b - 0xdc00) + 0x10000;
  };
};


/***/ }),
/* 86 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var LIBRARY = __webpack_require__(39);
var $export = __webpack_require__(0);
var redefine = __webpack_require__(18);
var hide = __webpack_require__(17);
var has = __webpack_require__(16);
var Iterators = __webpack_require__(51);
var $iterCreate = __webpack_require__(87);
var setToStringTag = __webpack_require__(49);
var getPrototypeOf = __webpack_require__(22);
var ITERATOR = __webpack_require__(8)('iterator');
var BUGGY = !([].keys && 'next' in [].keys()); // Safari has buggy iterators w/o `next`
var FF_ITERATOR = '@@iterator';
var KEYS = 'keys';
var VALUES = 'values';

var returnThis = function () { return this; };

module.exports = function (Base, NAME, Constructor, next, DEFAULT, IS_SET, FORCED) {
  $iterCreate(Constructor, NAME, next);
  var getMethod = function (kind) {
    if (!BUGGY && kind in proto) return proto[kind];
    switch (kind) {
      case KEYS: return function keys() { return new Constructor(this, kind); };
      case VALUES: return function values() { return new Constructor(this, kind); };
    } return function entries() { return new Constructor(this, kind); };
  };
  var TAG = NAME + ' Iterator';
  var DEF_VALUES = DEFAULT == VALUES;
  var VALUES_BUG = false;
  var proto = Base.prototype;
  var $native = proto[ITERATOR] || proto[FF_ITERATOR] || DEFAULT && proto[DEFAULT];
  var $default = $native || getMethod(DEFAULT);
  var $entries = DEFAULT ? !DEF_VALUES ? $default : getMethod('entries') : undefined;
  var $anyNative = NAME == 'Array' ? proto.entries || $native : $native;
  var methods, key, IteratorPrototype;
  // Fix native
  if ($anyNative) {
    IteratorPrototype = getPrototypeOf($anyNative.call(new Base()));
    if (IteratorPrototype !== Object.prototype && IteratorPrototype.next) {
      // Set @@toStringTag to native iterators
      setToStringTag(IteratorPrototype, TAG, true);
      // fix for some old engines
      if (!LIBRARY && !has(IteratorPrototype, ITERATOR)) hide(IteratorPrototype, ITERATOR, returnThis);
    }
  }
  // fix Array#{values, @@iterator}.name in V8 / FF
  if (DEF_VALUES && $native && $native.name !== VALUES) {
    VALUES_BUG = true;
    $default = function values() { return $native.call(this); };
  }
  // Define iterator
  if ((!LIBRARY || FORCED) && (BUGGY || VALUES_BUG || !proto[ITERATOR])) {
    hide(proto, ITERATOR, $default);
  }
  // Plug for library
  Iterators[NAME] = $default;
  Iterators[TAG] = returnThis;
  if (DEFAULT) {
    methods = {
      values: DEF_VALUES ? $default : getMethod(VALUES),
      keys: IS_SET ? $default : getMethod(KEYS),
      entries: $entries
    };
    if (FORCED) for (key in methods) {
      if (!(key in proto)) redefine(proto, key, methods[key]);
    } else $export($export.P + $export.F * (BUGGY || VALUES_BUG), NAME, methods);
  }
  return methods;
};


/***/ }),
/* 87 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var create = __webpack_require__(42);
var descriptor = __webpack_require__(37);
var setToStringTag = __webpack_require__(49);
var IteratorPrototype = {};

// 25.1.2.1.1 %IteratorPrototype%[@@iterator]()
__webpack_require__(17)(IteratorPrototype, __webpack_require__(8)('iterator'), function () { return this; });

module.exports = function (Constructor, NAME, next) {
  Constructor.prototype = create(IteratorPrototype, { next: descriptor(1, next) });
  setToStringTag(Constructor, NAME + ' Iterator');
};


/***/ }),
/* 88 */
/***/ (function(module, exports, __webpack_require__) {

// helper for String#{startsWith, endsWith, includes}
var isRegExp = __webpack_require__(60);
var defined = __webpack_require__(28);

module.exports = function (that, searchString, NAME) {
  if (isRegExp(searchString)) throw TypeError('String#' + NAME + " doesn't accept regex!");
  return String(defined(that));
};


/***/ }),
/* 89 */
/***/ (function(module, exports, __webpack_require__) {

var MATCH = __webpack_require__(8)('match');
module.exports = function (KEY) {
  var re = /./;
  try {
    '/./'[KEY](re);
  } catch (e) {
    try {
      re[MATCH] = false;
      return !'/./'[KEY](re);
    } catch (f) { /* empty */ }
  } return true;
};


/***/ }),
/* 90 */
/***/ (function(module, exports, __webpack_require__) {

// check on default Array iterator
var Iterators = __webpack_require__(51);
var ITERATOR = __webpack_require__(8)('iterator');
var ArrayProto = Array.prototype;

module.exports = function (it) {
  return it !== undefined && (Iterators.Array === it || ArrayProto[ITERATOR] === it);
};


/***/ }),
/* 91 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $defineProperty = __webpack_require__(10);
var createDesc = __webpack_require__(37);

module.exports = function (object, index, value) {
  if (index in object) $defineProperty.f(object, index, createDesc(0, value));
  else object[index] = value;
};


/***/ }),
/* 92 */
/***/ (function(module, exports, __webpack_require__) {

var classof = __webpack_require__(55);
var ITERATOR = __webpack_require__(8)('iterator');
var Iterators = __webpack_require__(51);
module.exports = __webpack_require__(26).getIteratorMethod = function (it) {
  if (it != undefined) return it[ITERATOR]
    || it['@@iterator']
    || Iterators[classof(it)];
};


/***/ }),
/* 93 */
/***/ (function(module, exports, __webpack_require__) {

// 9.4.2.3 ArraySpeciesCreate(originalArray, length)
var speciesConstructor = __webpack_require__(240);

module.exports = function (original, length) {
  return new (speciesConstructor(original))(length);
};


/***/ }),
/* 94 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// 22.1.3.6 Array.prototype.fill(value, start = 0, end = this.length)

var toObject = __webpack_require__(12);
var toAbsoluteIndex = __webpack_require__(41);
var toLength = __webpack_require__(11);
module.exports = function fill(value /* , start = 0, end = @length */) {
  var O = toObject(this);
  var length = toLength(O.length);
  var aLen = arguments.length;
  var index = toAbsoluteIndex(aLen > 1 ? arguments[1] : undefined, length);
  var end = aLen > 2 ? arguments[2] : undefined;
  var endPos = end === undefined ? length : toAbsoluteIndex(end, length);
  while (endPos > index) O[index++] = value;
  return O;
};


/***/ }),
/* 95 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var addToUnscopables = __webpack_require__(36);
var step = __webpack_require__(119);
var Iterators = __webpack_require__(51);
var toIObject = __webpack_require__(20);

// 22.1.3.4 Array.prototype.entries()
// 22.1.3.13 Array.prototype.keys()
// 22.1.3.29 Array.prototype.values()
// 22.1.3.30 Array.prototype[@@iterator]()
module.exports = __webpack_require__(86)(Array, 'Array', function (iterated, kind) {
  this._t = toIObject(iterated); // target
  this._i = 0;                   // next index
  this._k = kind;                // kind
// 22.1.5.2.1 %ArrayIteratorPrototype%.next()
}, function () {
  var O = this._t;
  var kind = this._k;
  var index = this._i++;
  if (!O || index >= O.length) {
    this._t = undefined;
    return step(1);
  }
  if (kind == 'keys') return step(0, index);
  if (kind == 'values') return step(0, O[index]);
  return step(0, [index, O[index]]);
}, 'values');

// argumentsList[@@iterator] is %ArrayProto_values% (9.4.4.6, 9.4.4.7)
Iterators.Arguments = Iterators.Array;

addToUnscopables('keys');
addToUnscopables('values');
addToUnscopables('entries');


/***/ }),
/* 96 */
/***/ (function(module, exports, __webpack_require__) {

var ctx = __webpack_require__(23);
var invoke = __webpack_require__(109);
var html = __webpack_require__(78);
var cel = __webpack_require__(74);
var global = __webpack_require__(4);
var process = global.process;
var setTask = global.setImmediate;
var clearTask = global.clearImmediate;
var MessageChannel = global.MessageChannel;
var Dispatch = global.Dispatch;
var counter = 0;
var queue = {};
var ONREADYSTATECHANGE = 'onreadystatechange';
var defer, channel, port;
var run = function () {
  var id = +this;
  // eslint-disable-next-line no-prototype-builtins
  if (queue.hasOwnProperty(id)) {
    var fn = queue[id];
    delete queue[id];
    fn();
  }
};
var listener = function (event) {
  run.call(event.data);
};
// Node.js 0.9+ & IE10+ has setImmediate, otherwise:
if (!setTask || !clearTask) {
  setTask = function setImmediate(fn) {
    var args = [];
    var i = 1;
    while (arguments.length > i) args.push(arguments[i++]);
    queue[++counter] = function () {
      // eslint-disable-next-line no-new-func
      invoke(typeof fn == 'function' ? fn : Function(fn), args);
    };
    defer(counter);
    return counter;
  };
  clearTask = function clearImmediate(id) {
    delete queue[id];
  };
  // Node.js 0.8-
  if (__webpack_require__(24)(process) == 'process') {
    defer = function (id) {
      process.nextTick(ctx(run, id, 1));
    };
  // Sphere (JS game engine) Dispatch API
  } else if (Dispatch && Dispatch.now) {
    defer = function (id) {
      Dispatch.now(ctx(run, id, 1));
    };
  // Browsers with MessageChannel, includes WebWorkers
  } else if (MessageChannel) {
    channel = new MessageChannel();
    port = channel.port2;
    channel.port1.onmessage = listener;
    defer = ctx(port.postMessage, port, 1);
  // Browsers with postMessage, skip WebWorkers
  // IE8 has postMessage, but it's sync & typeof its postMessage is 'object'
  } else if (global.addEventListener && typeof postMessage == 'function' && !global.importScripts) {
    defer = function (id) {
      global.postMessage(id + '', '*');
    };
    global.addEventListener('message', listener, false);
  // IE8-
  } else if (ONREADYSTATECHANGE in cel('script')) {
    defer = function (id) {
      html.appendChild(cel('script'))[ONREADYSTATECHANGE] = function () {
        html.removeChild(this);
        run.call(id);
      };
    };
  // Rest old browsers
  } else {
    defer = function (id) {
      setTimeout(ctx(run, id, 1), 0);
    };
  }
}
module.exports = {
  set: setTask,
  clear: clearTask
};


/***/ }),
/* 97 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(4);
var macrotask = __webpack_require__(96).set;
var Observer = global.MutationObserver || global.WebKitMutationObserver;
var process = global.process;
var Promise = global.Promise;
var isNode = __webpack_require__(24)(process) == 'process';

module.exports = function () {
  var head, last, notify;

  var flush = function () {
    var parent, fn;
    if (isNode && (parent = process.domain)) parent.exit();
    while (head) {
      fn = head.fn;
      head = head.next;
      try {
        fn();
      } catch (e) {
        if (head) notify();
        else last = undefined;
        throw e;
      }
    } last = undefined;
    if (parent) parent.enter();
  };

  // Node.js
  if (isNode) {
    notify = function () {
      process.nextTick(flush);
    };
  // browsers with MutationObserver
  } else if (Observer) {
    var toggle = true;
    var node = document.createTextNode('');
    new Observer(flush).observe(node, { characterData: true }); // eslint-disable-line no-new
    notify = function () {
      node.data = toggle = !toggle;
    };
  // environments with maybe non-completely correct, but existent Promise
  } else if (Promise && Promise.resolve) {
    var promise = Promise.resolve();
    notify = function () {
      promise.then(flush);
    };
  // for other environments - macrotask based on:
  // - setImmediate
  // - MessageChannel
  // - window.postMessag
  // - onreadystatechange
  // - setTimeout
  } else {
    notify = function () {
      // strange IE + webpack dev server bug - use .call(global)
      macrotask.call(global, flush);
    };
  }

  return function (fn) {
    var task = { fn: fn, next: undefined };
    if (last) last.next = task;
    if (!head) {
      head = task;
      notify();
    } last = task;
  };
};


/***/ }),
/* 98 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 25.4.1.5 NewPromiseCapability(C)
var aFunction = __webpack_require__(14);

function PromiseCapability(C) {
  var resolve, reject;
  this.promise = new C(function ($$resolve, $$reject) {
    if (resolve !== undefined || reject !== undefined) throw TypeError('Bad Promise constructor');
    resolve = $$resolve;
    reject = $$reject;
  });
  this.resolve = aFunction(resolve);
  this.reject = aFunction(reject);
}

module.exports.f = function (C) {
  return new PromiseCapability(C);
};


/***/ }),
/* 99 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var global = __webpack_require__(4);
var DESCRIPTORS = __webpack_require__(9);
var LIBRARY = __webpack_require__(39);
var $typed = __webpack_require__(66);
var hide = __webpack_require__(17);
var redefineAll = __webpack_require__(47);
var fails = __webpack_require__(5);
var anInstance = __webpack_require__(45);
var toInteger = __webpack_require__(29);
var toLength = __webpack_require__(11);
var toIndex = __webpack_require__(128);
var gOPN = __webpack_require__(43).f;
var dP = __webpack_require__(10).f;
var arrayFill = __webpack_require__(94);
var setToStringTag = __webpack_require__(49);
var ARRAY_BUFFER = 'ArrayBuffer';
var DATA_VIEW = 'DataView';
var PROTOTYPE = 'prototype';
var WRONG_LENGTH = 'Wrong length!';
var WRONG_INDEX = 'Wrong index!';
var $ArrayBuffer = global[ARRAY_BUFFER];
var $DataView = global[DATA_VIEW];
var Math = global.Math;
var RangeError = global.RangeError;
// eslint-disable-next-line no-shadow-restricted-names
var Infinity = global.Infinity;
var BaseBuffer = $ArrayBuffer;
var abs = Math.abs;
var pow = Math.pow;
var floor = Math.floor;
var log = Math.log;
var LN2 = Math.LN2;
var BUFFER = 'buffer';
var BYTE_LENGTH = 'byteLength';
var BYTE_OFFSET = 'byteOffset';
var $BUFFER = DESCRIPTORS ? '_b' : BUFFER;
var $LENGTH = DESCRIPTORS ? '_l' : BYTE_LENGTH;
var $OFFSET = DESCRIPTORS ? '_o' : BYTE_OFFSET;

// IEEE754 conversions based on https://github.com/feross/ieee754
function packIEEE754(value, mLen, nBytes) {
  var buffer = Array(nBytes);
  var eLen = nBytes * 8 - mLen - 1;
  var eMax = (1 << eLen) - 1;
  var eBias = eMax >> 1;
  var rt = mLen === 23 ? pow(2, -24) - pow(2, -77) : 0;
  var i = 0;
  var s = value < 0 || value === 0 && 1 / value < 0 ? 1 : 0;
  var e, m, c;
  value = abs(value);
  // eslint-disable-next-line no-self-compare
  if (value != value || value === Infinity) {
    // eslint-disable-next-line no-self-compare
    m = value != value ? 1 : 0;
    e = eMax;
  } else {
    e = floor(log(value) / LN2);
    if (value * (c = pow(2, -e)) < 1) {
      e--;
      c *= 2;
    }
    if (e + eBias >= 1) {
      value += rt / c;
    } else {
      value += rt * pow(2, 1 - eBias);
    }
    if (value * c >= 2) {
      e++;
      c /= 2;
    }
    if (e + eBias >= eMax) {
      m = 0;
      e = eMax;
    } else if (e + eBias >= 1) {
      m = (value * c - 1) * pow(2, mLen);
      e = e + eBias;
    } else {
      m = value * pow(2, eBias - 1) * pow(2, mLen);
      e = 0;
    }
  }
  for (; mLen >= 8; buffer[i++] = m & 255, m /= 256, mLen -= 8);
  e = e << mLen | m;
  eLen += mLen;
  for (; eLen > 0; buffer[i++] = e & 255, e /= 256, eLen -= 8);
  buffer[--i] |= s * 128;
  return buffer;
}
function unpackIEEE754(buffer, mLen, nBytes) {
  var eLen = nBytes * 8 - mLen - 1;
  var eMax = (1 << eLen) - 1;
  var eBias = eMax >> 1;
  var nBits = eLen - 7;
  var i = nBytes - 1;
  var s = buffer[i--];
  var e = s & 127;
  var m;
  s >>= 7;
  for (; nBits > 0; e = e * 256 + buffer[i], i--, nBits -= 8);
  m = e & (1 << -nBits) - 1;
  e >>= -nBits;
  nBits += mLen;
  for (; nBits > 0; m = m * 256 + buffer[i], i--, nBits -= 8);
  if (e === 0) {
    e = 1 - eBias;
  } else if (e === eMax) {
    return m ? NaN : s ? -Infinity : Infinity;
  } else {
    m = m + pow(2, mLen);
    e = e - eBias;
  } return (s ? -1 : 1) * m * pow(2, e - mLen);
}

function unpackI32(bytes) {
  return bytes[3] << 24 | bytes[2] << 16 | bytes[1] << 8 | bytes[0];
}
function packI8(it) {
  return [it & 0xff];
}
function packI16(it) {
  return [it & 0xff, it >> 8 & 0xff];
}
function packI32(it) {
  return [it & 0xff, it >> 8 & 0xff, it >> 16 & 0xff, it >> 24 & 0xff];
}
function packF64(it) {
  return packIEEE754(it, 52, 8);
}
function packF32(it) {
  return packIEEE754(it, 23, 4);
}

function addGetter(C, key, internal) {
  dP(C[PROTOTYPE], key, { get: function () { return this[internal]; } });
}

function get(view, bytes, index, isLittleEndian) {
  var numIndex = +index;
  var intIndex = toIndex(numIndex);
  if (intIndex + bytes > view[$LENGTH]) throw RangeError(WRONG_INDEX);
  var store = view[$BUFFER]._b;
  var start = intIndex + view[$OFFSET];
  var pack = store.slice(start, start + bytes);
  return isLittleEndian ? pack : pack.reverse();
}
function set(view, bytes, index, conversion, value, isLittleEndian) {
  var numIndex = +index;
  var intIndex = toIndex(numIndex);
  if (intIndex + bytes > view[$LENGTH]) throw RangeError(WRONG_INDEX);
  var store = view[$BUFFER]._b;
  var start = intIndex + view[$OFFSET];
  var pack = conversion(+value);
  for (var i = 0; i < bytes; i++) store[start + i] = pack[isLittleEndian ? i : bytes - i - 1];
}

if (!$typed.ABV) {
  $ArrayBuffer = function ArrayBuffer(length) {
    anInstance(this, $ArrayBuffer, ARRAY_BUFFER);
    var byteLength = toIndex(length);
    this._b = arrayFill.call(Array(byteLength), 0);
    this[$LENGTH] = byteLength;
  };

  $DataView = function DataView(buffer, byteOffset, byteLength) {
    anInstance(this, $DataView, DATA_VIEW);
    anInstance(buffer, $ArrayBuffer, DATA_VIEW);
    var bufferLength = buffer[$LENGTH];
    var offset = toInteger(byteOffset);
    if (offset < 0 || offset > bufferLength) throw RangeError('Wrong offset!');
    byteLength = byteLength === undefined ? bufferLength - offset : toLength(byteLength);
    if (offset + byteLength > bufferLength) throw RangeError(WRONG_LENGTH);
    this[$BUFFER] = buffer;
    this[$OFFSET] = offset;
    this[$LENGTH] = byteLength;
  };

  if (DESCRIPTORS) {
    addGetter($ArrayBuffer, BYTE_LENGTH, '_l');
    addGetter($DataView, BUFFER, '_b');
    addGetter($DataView, BYTE_LENGTH, '_l');
    addGetter($DataView, BYTE_OFFSET, '_o');
  }

  redefineAll($DataView[PROTOTYPE], {
    getInt8: function getInt8(byteOffset) {
      return get(this, 1, byteOffset)[0] << 24 >> 24;
    },
    getUint8: function getUint8(byteOffset) {
      return get(this, 1, byteOffset)[0];
    },
    getInt16: function getInt16(byteOffset /* , littleEndian */) {
      var bytes = get(this, 2, byteOffset, arguments[1]);
      return (bytes[1] << 8 | bytes[0]) << 16 >> 16;
    },
    getUint16: function getUint16(byteOffset /* , littleEndian */) {
      var bytes = get(this, 2, byteOffset, arguments[1]);
      return bytes[1] << 8 | bytes[0];
    },
    getInt32: function getInt32(byteOffset /* , littleEndian */) {
      return unpackI32(get(this, 4, byteOffset, arguments[1]));
    },
    getUint32: function getUint32(byteOffset /* , littleEndian */) {
      return unpackI32(get(this, 4, byteOffset, arguments[1])) >>> 0;
    },
    getFloat32: function getFloat32(byteOffset /* , littleEndian */) {
      return unpackIEEE754(get(this, 4, byteOffset, arguments[1]), 23, 4);
    },
    getFloat64: function getFloat64(byteOffset /* , littleEndian */) {
      return unpackIEEE754(get(this, 8, byteOffset, arguments[1]), 52, 8);
    },
    setInt8: function setInt8(byteOffset, value) {
      set(this, 1, byteOffset, packI8, value);
    },
    setUint8: function setUint8(byteOffset, value) {
      set(this, 1, byteOffset, packI8, value);
    },
    setInt16: function setInt16(byteOffset, value /* , littleEndian */) {
      set(this, 2, byteOffset, packI16, value, arguments[2]);
    },
    setUint16: function setUint16(byteOffset, value /* , littleEndian */) {
      set(this, 2, byteOffset, packI16, value, arguments[2]);
    },
    setInt32: function setInt32(byteOffset, value /* , littleEndian */) {
      set(this, 4, byteOffset, packI32, value, arguments[2]);
    },
    setUint32: function setUint32(byteOffset, value /* , littleEndian */) {
      set(this, 4, byteOffset, packI32, value, arguments[2]);
    },
    setFloat32: function setFloat32(byteOffset, value /* , littleEndian */) {
      set(this, 4, byteOffset, packF32, value, arguments[2]);
    },
    setFloat64: function setFloat64(byteOffset, value /* , littleEndian */) {
      set(this, 8, byteOffset, packF64, value, arguments[2]);
    }
  });
} else {
  if (!fails(function () {
    $ArrayBuffer(1);
  }) || !fails(function () {
    new $ArrayBuffer(-1); // eslint-disable-line no-new
  }) || fails(function () {
    new $ArrayBuffer(); // eslint-disable-line no-new
    new $ArrayBuffer(1.5); // eslint-disable-line no-new
    new $ArrayBuffer(NaN); // eslint-disable-line no-new
    return $ArrayBuffer.name != ARRAY_BUFFER;
  })) {
    $ArrayBuffer = function ArrayBuffer(length) {
      anInstance(this, $ArrayBuffer);
      return new BaseBuffer(toIndex(length));
    };
    var ArrayBufferProto = $ArrayBuffer[PROTOTYPE] = BaseBuffer[PROTOTYPE];
    for (var keys = gOPN(BaseBuffer), j = 0, key; keys.length > j;) {
      if (!((key = keys[j++]) in $ArrayBuffer)) hide($ArrayBuffer, key, BaseBuffer[key]);
    }
    if (!LIBRARY) ArrayBufferProto.constructor = $ArrayBuffer;
  }
  // iOS Safari 7.x bug
  var view = new $DataView(new $ArrayBuffer(2));
  var $setInt8 = $DataView[PROTOTYPE].setInt8;
  view.setInt8(0, 2147483648);
  view.setInt8(1, 2147483649);
  if (view.getInt8(0) || !view.getInt8(1)) redefineAll($DataView[PROTOTYPE], {
    setInt8: function setInt8(byteOffset, value) {
      $setInt8.call(this, byteOffset, value << 24 >> 24);
    },
    setUint8: function setUint8(byteOffset, value) {
      $setInt8.call(this, byteOffset, value << 24 >> 24);
    }
  }, true);
}
setToStringTag($ArrayBuffer, ARRAY_BUFFER);
setToStringTag($DataView, DATA_VIEW);
hide($DataView[PROTOTYPE], $typed.VIEW, true);
exports[ARRAY_BUFFER] = $ArrayBuffer;
exports[DATA_VIEW] = $DataView;


/***/ }),
/* 100 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

exports.withToolkitError = withToolkitError;
exports.logToolkitError = logToolkitError;
function withToolkitError(wrappedFunction, feature) {
  if (typeof wrappedFunction !== 'function') {
    throw new Error('The first argument to withToolkitError must be a Function');
  }

  var featureName = feature;
  if ((typeof feature === 'undefined' ? 'undefined' : _typeof(feature)) === 'object') {
    featureName = feature.constructor.name;
  }

  var featureSetting = ynabToolKit.options[featureName];
  if (typeof featureSetting === 'undefined') {
    console.warn("Second argument to withToolkitError should either be Feature Class or Feature Name as found in the feature's settings.js file");
  }

  return function () {
    try {
      return wrappedFunction();
    } catch (exception) {
      logToolkitError(exception, featureName, wrappedFunction.name, featureSetting);
    }
  };
}

function logToolkitError(exception, featureName, location, featureSetting) {
  var message = 'Toolkit Error:\n    - Feature: ' + featureName + '\n    - Location: ' + (location || 'anonymous') + '\n    - User Setting: ' + featureSetting + '\n    - Message: ' + (exception.message ? exception.message : 'none');

  console.error(message, exception.stack ? exception.stack : '');
}

/***/ }),
/* 101 */
/***/ (function(module, exports) {

var g;

// This works in non-strict mode
g = (function() {
	return this;
})();

try {
	// This works if eval is allowed (see CSP)
	g = g || Function("return this")() || (1,eval)("this");
} catch(e) {
	// This works if the window reference is available
	if(typeof window === "object")
		g = window;
}

// g can still be undefined, but nothing to do about it...
// We return undefined, instead of nothing here, so it's
// easier to handle this case. if(!global) { ...}

module.exports = g;


/***/ }),
/* 102 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = !__webpack_require__(9) && !__webpack_require__(5)(function () {
  return Object.defineProperty(__webpack_require__(74)('div'), 'a', { get: function () { return 7; } }).a != 7;
});


/***/ }),
/* 103 */
/***/ (function(module, exports, __webpack_require__) {

exports.f = __webpack_require__(8);


/***/ }),
/* 104 */
/***/ (function(module, exports, __webpack_require__) {

var has = __webpack_require__(16);
var toIObject = __webpack_require__(20);
var arrayIndexOf = __webpack_require__(57)(false);
var IE_PROTO = __webpack_require__(76)('IE_PROTO');

module.exports = function (object, names) {
  var O = toIObject(object);
  var i = 0;
  var result = [];
  var key;
  for (key in O) if (key != IE_PROTO) has(O, key) && result.push(key);
  // Don't enum bug & hidden keys
  while (names.length > i) if (has(O, key = names[i++])) {
    ~arrayIndexOf(result, key) || result.push(key);
  }
  return result;
};


/***/ }),
/* 105 */
/***/ (function(module, exports, __webpack_require__) {

var dP = __webpack_require__(10);
var anObject = __webpack_require__(3);
var getKeys = __webpack_require__(40);

module.exports = __webpack_require__(9) ? Object.defineProperties : function defineProperties(O, Properties) {
  anObject(O);
  var keys = getKeys(Properties);
  var length = keys.length;
  var i = 0;
  var P;
  while (length > i) dP.f(O, P = keys[i++], Properties[P]);
  return O;
};


/***/ }),
/* 106 */
/***/ (function(module, exports, __webpack_require__) {

// fallback for IE11 buggy Object.getOwnPropertyNames with iframe and window
var toIObject = __webpack_require__(20);
var gOPN = __webpack_require__(43).f;
var toString = {}.toString;

var windowNames = typeof window == 'object' && window && Object.getOwnPropertyNames
  ? Object.getOwnPropertyNames(window) : [];

var getWindowNames = function (it) {
  try {
    return gOPN(it);
  } catch (e) {
    return windowNames.slice();
  }
};

module.exports.f = function getOwnPropertyNames(it) {
  return windowNames && toString.call(it) == '[object Window]' ? getWindowNames(it) : gOPN(toIObject(it));
};


/***/ }),
/* 107 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 19.1.2.1 Object.assign(target, source, ...)
var getKeys = __webpack_require__(40);
var gOPS = __webpack_require__(58);
var pIE = __webpack_require__(54);
var toObject = __webpack_require__(12);
var IObject = __webpack_require__(53);
var $assign = Object.assign;

// should work with symbols and should have deterministic property order (V8 bug)
module.exports = !$assign || __webpack_require__(5)(function () {
  var A = {};
  var B = {};
  // eslint-disable-next-line no-undef
  var S = Symbol();
  var K = 'abcdefghijklmnopqrst';
  A[S] = 7;
  K.split('').forEach(function (k) { B[k] = k; });
  return $assign({}, A)[S] != 7 || Object.keys($assign({}, B)).join('') != K;
}) ? function assign(target, source) { // eslint-disable-line no-unused-vars
  var T = toObject(target);
  var aLen = arguments.length;
  var index = 1;
  var getSymbols = gOPS.f;
  var isEnum = pIE.f;
  while (aLen > index) {
    var S = IObject(arguments[index++]);
    var keys = getSymbols ? getKeys(S).concat(getSymbols(S)) : getKeys(S);
    var length = keys.length;
    var j = 0;
    var key;
    while (length > j) if (isEnum.call(S, key = keys[j++])) T[key] = S[key];
  } return T;
} : $assign;


/***/ }),
/* 108 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var aFunction = __webpack_require__(14);
var isObject = __webpack_require__(7);
var invoke = __webpack_require__(109);
var arraySlice = [].slice;
var factories = {};

var construct = function (F, len, args) {
  if (!(len in factories)) {
    for (var n = [], i = 0; i < len; i++) n[i] = 'a[' + i + ']';
    // eslint-disable-next-line no-new-func
    factories[len] = Function('F,a', 'return new F(' + n.join(',') + ')');
  } return factories[len](F, args);
};

module.exports = Function.bind || function bind(that /* , ...args */) {
  var fn = aFunction(this);
  var partArgs = arraySlice.call(arguments, 1);
  var bound = function (/* args... */) {
    var args = partArgs.concat(arraySlice.call(arguments));
    return this instanceof bound ? construct(fn, args.length, args) : invoke(fn, args, that);
  };
  if (isObject(fn.prototype)) bound.prototype = fn.prototype;
  return bound;
};


/***/ }),
/* 109 */
/***/ (function(module, exports) {

// fast apply, http://jsperf.lnkit.com/fast-apply/5
module.exports = function (fn, args, that) {
  var un = that === undefined;
  switch (args.length) {
    case 0: return un ? fn()
                      : fn.call(that);
    case 1: return un ? fn(args[0])
                      : fn.call(that, args[0]);
    case 2: return un ? fn(args[0], args[1])
                      : fn.call(that, args[0], args[1]);
    case 3: return un ? fn(args[0], args[1], args[2])
                      : fn.call(that, args[0], args[1], args[2]);
    case 4: return un ? fn(args[0], args[1], args[2], args[3])
                      : fn.call(that, args[0], args[1], args[2], args[3]);
  } return fn.apply(that, args);
};


/***/ }),
/* 110 */
/***/ (function(module, exports, __webpack_require__) {

var $parseInt = __webpack_require__(4).parseInt;
var $trim = __webpack_require__(50).trim;
var ws = __webpack_require__(80);
var hex = /^[-+]?0[xX]/;

module.exports = $parseInt(ws + '08') !== 8 || $parseInt(ws + '0x16') !== 22 ? function parseInt(str, radix) {
  var string = $trim(String(str), 3);
  return $parseInt(string, (radix >>> 0) || (hex.test(string) ? 16 : 10));
} : $parseInt;


/***/ }),
/* 111 */
/***/ (function(module, exports, __webpack_require__) {

var $parseFloat = __webpack_require__(4).parseFloat;
var $trim = __webpack_require__(50).trim;

module.exports = 1 / $parseFloat(__webpack_require__(80) + '-0') !== -Infinity ? function parseFloat(str) {
  var string = $trim(String(str), 3);
  var result = $parseFloat(string);
  return result === 0 && string.charAt(0) == '-' ? -0 : result;
} : $parseFloat;


/***/ }),
/* 112 */
/***/ (function(module, exports, __webpack_require__) {

var cof = __webpack_require__(24);
module.exports = function (it, msg) {
  if (typeof it != 'number' && cof(it) != 'Number') throw TypeError(msg);
  return +it;
};


/***/ }),
/* 113 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.3 Number.isInteger(number)
var isObject = __webpack_require__(7);
var floor = Math.floor;
module.exports = function isInteger(it) {
  return !isObject(it) && isFinite(it) && floor(it) === it;
};


/***/ }),
/* 114 */
/***/ (function(module, exports) {

// 20.2.2.20 Math.log1p(x)
module.exports = Math.log1p || function log1p(x) {
  return (x = +x) > -1e-8 && x < 1e-8 ? x - x * x / 2 : Math.log(1 + x);
};


/***/ }),
/* 115 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.16 Math.fround(x)
var sign = __webpack_require__(83);
var pow = Math.pow;
var EPSILON = pow(2, -52);
var EPSILON32 = pow(2, -23);
var MAX32 = pow(2, 127) * (2 - EPSILON32);
var MIN32 = pow(2, -126);

var roundTiesToEven = function (n) {
  return n + 1 / EPSILON - 1 / EPSILON;
};

module.exports = Math.fround || function fround(x) {
  var $abs = Math.abs(x);
  var $sign = sign(x);
  var a, result;
  if ($abs < MIN32) return $sign * roundTiesToEven($abs / MIN32 / EPSILON32) * MIN32 * EPSILON32;
  a = (1 + EPSILON32 / EPSILON) * $abs;
  result = a - (a - $abs);
  // eslint-disable-next-line no-self-compare
  if (result > MAX32 || result != result) return $sign * Infinity;
  return $sign * result;
};


/***/ }),
/* 116 */
/***/ (function(module, exports, __webpack_require__) {

// call something on iterator step with safe closing on error
var anObject = __webpack_require__(3);
module.exports = function (iterator, fn, value, entries) {
  try {
    return entries ? fn(anObject(value)[0], value[1]) : fn(value);
  // 7.4.6 IteratorClose(iterator, completion)
  } catch (e) {
    var ret = iterator['return'];
    if (ret !== undefined) anObject(ret.call(iterator));
    throw e;
  }
};


/***/ }),
/* 117 */
/***/ (function(module, exports, __webpack_require__) {

var aFunction = __webpack_require__(14);
var toObject = __webpack_require__(12);
var IObject = __webpack_require__(53);
var toLength = __webpack_require__(11);

module.exports = function (that, callbackfn, aLen, memo, isRight) {
  aFunction(callbackfn);
  var O = toObject(that);
  var self = IObject(O);
  var length = toLength(O.length);
  var index = isRight ? length - 1 : 0;
  var i = isRight ? -1 : 1;
  if (aLen < 2) for (;;) {
    if (index in self) {
      memo = self[index];
      index += i;
      break;
    }
    index += i;
    if (isRight ? index < 0 : length <= index) {
      throw TypeError('Reduce of empty array with no initial value');
    }
  }
  for (;isRight ? index >= 0 : length > index; index += i) if (index in self) {
    memo = callbackfn(memo, self[index], index, O);
  }
  return memo;
};


/***/ }),
/* 118 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// 22.1.3.3 Array.prototype.copyWithin(target, start, end = this.length)

var toObject = __webpack_require__(12);
var toAbsoluteIndex = __webpack_require__(41);
var toLength = __webpack_require__(11);

module.exports = [].copyWithin || function copyWithin(target /* = 0 */, start /* = 0, end = @length */) {
  var O = toObject(this);
  var len = toLength(O.length);
  var to = toAbsoluteIndex(target, len);
  var from = toAbsoluteIndex(start, len);
  var end = arguments.length > 2 ? arguments[2] : undefined;
  var count = Math.min((end === undefined ? len : toAbsoluteIndex(end, len)) - from, len - to);
  var inc = 1;
  if (from < to && to < from + count) {
    inc = -1;
    from += count - 1;
    to += count - 1;
  }
  while (count-- > 0) {
    if (from in O) O[to] = O[from];
    else delete O[to];
    to += inc;
    from += inc;
  } return O;
};


/***/ }),
/* 119 */
/***/ (function(module, exports) {

module.exports = function (done, value) {
  return { value: value, done: !!done };
};


/***/ }),
/* 120 */
/***/ (function(module, exports, __webpack_require__) {

// 21.2.5.3 get RegExp.prototype.flags()
if (__webpack_require__(9) && /./g.flags != 'g') __webpack_require__(10).f(RegExp.prototype, 'flags', {
  configurable: true,
  get: __webpack_require__(62)
});


/***/ }),
/* 121 */
/***/ (function(module, exports) {

module.exports = function (exec) {
  try {
    return { e: false, v: exec() };
  } catch (e) {
    return { e: true, v: e };
  }
};


/***/ }),
/* 122 */
/***/ (function(module, exports, __webpack_require__) {

var anObject = __webpack_require__(3);
var isObject = __webpack_require__(7);
var newPromiseCapability = __webpack_require__(98);

module.exports = function (C, x) {
  anObject(C);
  if (isObject(x) && x.constructor === C) return x;
  var promiseCapability = newPromiseCapability.f(C);
  var resolve = promiseCapability.resolve;
  resolve(x);
  return promiseCapability.promise;
};


/***/ }),
/* 123 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var strong = __webpack_require__(124);
var validate = __webpack_require__(52);
var MAP = 'Map';

// 23.1 Map Objects
module.exports = __webpack_require__(65)(MAP, function (get) {
  return function Map() { return get(this, arguments.length > 0 ? arguments[0] : undefined); };
}, {
  // 23.1.3.6 Map.prototype.get(key)
  get: function get(key) {
    var entry = strong.getEntry(validate(this, MAP), key);
    return entry && entry.v;
  },
  // 23.1.3.9 Map.prototype.set(key, value)
  set: function set(key, value) {
    return strong.def(validate(this, MAP), key === 0 ? 0 : key, value);
  }
}, strong, true);


/***/ }),
/* 124 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var dP = __webpack_require__(10).f;
var create = __webpack_require__(42);
var redefineAll = __webpack_require__(47);
var ctx = __webpack_require__(23);
var anInstance = __webpack_require__(45);
var forOf = __webpack_require__(46);
var $iterDefine = __webpack_require__(86);
var step = __webpack_require__(119);
var setSpecies = __webpack_require__(44);
var DESCRIPTORS = __webpack_require__(9);
var fastKey = __webpack_require__(35).fastKey;
var validate = __webpack_require__(52);
var SIZE = DESCRIPTORS ? '_s' : 'size';

var getEntry = function (that, key) {
  // fast case
  var index = fastKey(key);
  var entry;
  if (index !== 'F') return that._i[index];
  // frozen object case
  for (entry = that._f; entry; entry = entry.n) {
    if (entry.k == key) return entry;
  }
};

module.exports = {
  getConstructor: function (wrapper, NAME, IS_MAP, ADDER) {
    var C = wrapper(function (that, iterable) {
      anInstance(that, C, NAME, '_i');
      that._t = NAME;         // collection type
      that._i = create(null); // index
      that._f = undefined;    // first entry
      that._l = undefined;    // last entry
      that[SIZE] = 0;         // size
      if (iterable != undefined) forOf(iterable, IS_MAP, that[ADDER], that);
    });
    redefineAll(C.prototype, {
      // 23.1.3.1 Map.prototype.clear()
      // 23.2.3.2 Set.prototype.clear()
      clear: function clear() {
        for (var that = validate(this, NAME), data = that._i, entry = that._f; entry; entry = entry.n) {
          entry.r = true;
          if (entry.p) entry.p = entry.p.n = undefined;
          delete data[entry.i];
        }
        that._f = that._l = undefined;
        that[SIZE] = 0;
      },
      // 23.1.3.3 Map.prototype.delete(key)
      // 23.2.3.4 Set.prototype.delete(value)
      'delete': function (key) {
        var that = validate(this, NAME);
        var entry = getEntry(that, key);
        if (entry) {
          var next = entry.n;
          var prev = entry.p;
          delete that._i[entry.i];
          entry.r = true;
          if (prev) prev.n = next;
          if (next) next.p = prev;
          if (that._f == entry) that._f = next;
          if (that._l == entry) that._l = prev;
          that[SIZE]--;
        } return !!entry;
      },
      // 23.2.3.6 Set.prototype.forEach(callbackfn, thisArg = undefined)
      // 23.1.3.5 Map.prototype.forEach(callbackfn, thisArg = undefined)
      forEach: function forEach(callbackfn /* , that = undefined */) {
        validate(this, NAME);
        var f = ctx(callbackfn, arguments.length > 1 ? arguments[1] : undefined, 3);
        var entry;
        while (entry = entry ? entry.n : this._f) {
          f(entry.v, entry.k, this);
          // revert to the last existing entry
          while (entry && entry.r) entry = entry.p;
        }
      },
      // 23.1.3.7 Map.prototype.has(key)
      // 23.2.3.7 Set.prototype.has(value)
      has: function has(key) {
        return !!getEntry(validate(this, NAME), key);
      }
    });
    if (DESCRIPTORS) dP(C.prototype, 'size', {
      get: function () {
        return validate(this, NAME)[SIZE];
      }
    });
    return C;
  },
  def: function (that, key, value) {
    var entry = getEntry(that, key);
    var prev, index;
    // change existing entry
    if (entry) {
      entry.v = value;
    // create new entry
    } else {
      that._l = entry = {
        i: index = fastKey(key, true), // <- index
        k: key,                        // <- key
        v: value,                      // <- value
        p: prev = that._l,             // <- previous entry
        n: undefined,                  // <- next entry
        r: false                       // <- removed
      };
      if (!that._f) that._f = entry;
      if (prev) prev.n = entry;
      that[SIZE]++;
      // add to index
      if (index !== 'F') that._i[index] = entry;
    } return that;
  },
  getEntry: getEntry,
  setStrong: function (C, NAME, IS_MAP) {
    // add .keys, .values, .entries, [@@iterator]
    // 23.1.3.4, 23.1.3.8, 23.1.3.11, 23.1.3.12, 23.2.3.5, 23.2.3.8, 23.2.3.10, 23.2.3.11
    $iterDefine(C, NAME, function (iterated, kind) {
      this._t = validate(iterated, NAME); // target
      this._k = kind;                     // kind
      this._l = undefined;                // previous
    }, function () {
      var that = this;
      var kind = that._k;
      var entry = that._l;
      // revert to the last existing entry
      while (entry && entry.r) entry = entry.p;
      // get next entry
      if (!that._t || !(that._l = entry = entry ? entry.n : that._t._f)) {
        // or finish the iteration
        that._t = undefined;
        return step(1);
      }
      // return step by kind
      if (kind == 'keys') return step(0, entry.k);
      if (kind == 'values') return step(0, entry.v);
      return step(0, [entry.k, entry.v]);
    }, IS_MAP ? 'entries' : 'values', !IS_MAP, true);

    // add [@@species], 23.1.2.2, 23.2.2.2
    setSpecies(NAME);
  }
};


/***/ }),
/* 125 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var strong = __webpack_require__(124);
var validate = __webpack_require__(52);
var SET = 'Set';

// 23.2 Set Objects
module.exports = __webpack_require__(65)(SET, function (get) {
  return function Set() { return get(this, arguments.length > 0 ? arguments[0] : undefined); };
}, {
  // 23.2.3.1 Set.prototype.add(value)
  add: function add(value) {
    return strong.def(validate(this, SET), value = value === 0 ? 0 : value, value);
  }
}, strong);


/***/ }),
/* 126 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var each = __webpack_require__(31)(0);
var redefine = __webpack_require__(18);
var meta = __webpack_require__(35);
var assign = __webpack_require__(107);
var weak = __webpack_require__(127);
var isObject = __webpack_require__(7);
var fails = __webpack_require__(5);
var validate = __webpack_require__(52);
var WEAK_MAP = 'WeakMap';
var getWeak = meta.getWeak;
var isExtensible = Object.isExtensible;
var uncaughtFrozenStore = weak.ufstore;
var tmp = {};
var InternalMap;

var wrapper = function (get) {
  return function WeakMap() {
    return get(this, arguments.length > 0 ? arguments[0] : undefined);
  };
};

var methods = {
  // 23.3.3.3 WeakMap.prototype.get(key)
  get: function get(key) {
    if (isObject(key)) {
      var data = getWeak(key);
      if (data === true) return uncaughtFrozenStore(validate(this, WEAK_MAP)).get(key);
      return data ? data[this._i] : undefined;
    }
  },
  // 23.3.3.5 WeakMap.prototype.set(key, value)
  set: function set(key, value) {
    return weak.def(validate(this, WEAK_MAP), key, value);
  }
};

// 23.3 WeakMap Objects
var $WeakMap = module.exports = __webpack_require__(65)(WEAK_MAP, wrapper, methods, weak, true, true);

// IE11 WeakMap frozen keys fix
if (fails(function () { return new $WeakMap().set((Object.freeze || Object)(tmp), 7).get(tmp) != 7; })) {
  InternalMap = weak.getConstructor(wrapper, WEAK_MAP);
  assign(InternalMap.prototype, methods);
  meta.NEED = true;
  each(['delete', 'has', 'get', 'set'], function (key) {
    var proto = $WeakMap.prototype;
    var method = proto[key];
    redefine(proto, key, function (a, b) {
      // store frozen objects on internal weakmap shim
      if (isObject(a) && !isExtensible(a)) {
        if (!this._f) this._f = new InternalMap();
        var result = this._f[key](a, b);
        return key == 'set' ? this : result;
      // store all the rest on native weakmap
      } return method.call(this, a, b);
    });
  });
}


/***/ }),
/* 127 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var redefineAll = __webpack_require__(47);
var getWeak = __webpack_require__(35).getWeak;
var anObject = __webpack_require__(3);
var isObject = __webpack_require__(7);
var anInstance = __webpack_require__(45);
var forOf = __webpack_require__(46);
var createArrayMethod = __webpack_require__(31);
var $has = __webpack_require__(16);
var validate = __webpack_require__(52);
var arrayFind = createArrayMethod(5);
var arrayFindIndex = createArrayMethod(6);
var id = 0;

// fallback for uncaught frozen keys
var uncaughtFrozenStore = function (that) {
  return that._l || (that._l = new UncaughtFrozenStore());
};
var UncaughtFrozenStore = function () {
  this.a = [];
};
var findUncaughtFrozen = function (store, key) {
  return arrayFind(store.a, function (it) {
    return it[0] === key;
  });
};
UncaughtFrozenStore.prototype = {
  get: function (key) {
    var entry = findUncaughtFrozen(this, key);
    if (entry) return entry[1];
  },
  has: function (key) {
    return !!findUncaughtFrozen(this, key);
  },
  set: function (key, value) {
    var entry = findUncaughtFrozen(this, key);
    if (entry) entry[1] = value;
    else this.a.push([key, value]);
  },
  'delete': function (key) {
    var index = arrayFindIndex(this.a, function (it) {
      return it[0] === key;
    });
    if (~index) this.a.splice(index, 1);
    return !!~index;
  }
};

module.exports = {
  getConstructor: function (wrapper, NAME, IS_MAP, ADDER) {
    var C = wrapper(function (that, iterable) {
      anInstance(that, C, NAME, '_i');
      that._t = NAME;      // collection type
      that._i = id++;      // collection id
      that._l = undefined; // leak store for uncaught frozen objects
      if (iterable != undefined) forOf(iterable, IS_MAP, that[ADDER], that);
    });
    redefineAll(C.prototype, {
      // 23.3.3.2 WeakMap.prototype.delete(key)
      // 23.4.3.3 WeakSet.prototype.delete(value)
      'delete': function (key) {
        if (!isObject(key)) return false;
        var data = getWeak(key);
        if (data === true) return uncaughtFrozenStore(validate(this, NAME))['delete'](key);
        return data && $has(data, this._i) && delete data[this._i];
      },
      // 23.3.3.4 WeakMap.prototype.has(key)
      // 23.4.3.4 WeakSet.prototype.has(value)
      has: function has(key) {
        if (!isObject(key)) return false;
        var data = getWeak(key);
        if (data === true) return uncaughtFrozenStore(validate(this, NAME)).has(key);
        return data && $has(data, this._i);
      }
    });
    return C;
  },
  def: function (that, key, value) {
    var data = getWeak(anObject(key), true);
    if (data === true) uncaughtFrozenStore(that).set(key, value);
    else data[that._i] = value;
    return that;
  },
  ufstore: uncaughtFrozenStore
};


/***/ }),
/* 128 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/ecma262/#sec-toindex
var toInteger = __webpack_require__(29);
var toLength = __webpack_require__(11);
module.exports = function (it) {
  if (it === undefined) return 0;
  var number = toInteger(it);
  var length = toLength(number);
  if (number !== length) throw RangeError('Wrong length!');
  return length;
};


/***/ }),
/* 129 */
/***/ (function(module, exports, __webpack_require__) {

// all object keys, includes non-enumerable and symbols
var gOPN = __webpack_require__(43);
var gOPS = __webpack_require__(58);
var anObject = __webpack_require__(3);
var Reflect = __webpack_require__(4).Reflect;
module.exports = Reflect && Reflect.ownKeys || function ownKeys(it) {
  var keys = gOPN.f(anObject(it));
  var getSymbols = gOPS.f;
  return getSymbols ? keys.concat(getSymbols(it)) : keys;
};


/***/ }),
/* 130 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://tc39.github.io/proposal-flatMap/#sec-FlattenIntoArray
var isArray = __webpack_require__(59);
var isObject = __webpack_require__(7);
var toLength = __webpack_require__(11);
var ctx = __webpack_require__(23);
var IS_CONCAT_SPREADABLE = __webpack_require__(8)('isConcatSpreadable');

function flattenIntoArray(target, original, source, sourceLen, start, depth, mapper, thisArg) {
  var targetIndex = start;
  var sourceIndex = 0;
  var mapFn = mapper ? ctx(mapper, thisArg, 3) : false;
  var element, spreadable;

  while (sourceIndex < sourceLen) {
    if (sourceIndex in source) {
      element = mapFn ? mapFn(source[sourceIndex], sourceIndex, original) : source[sourceIndex];

      spreadable = false;
      if (isObject(element)) {
        spreadable = element[IS_CONCAT_SPREADABLE];
        spreadable = spreadable !== undefined ? !!spreadable : isArray(element);
      }

      if (spreadable && depth > 0) {
        targetIndex = flattenIntoArray(target, original, element, toLength(element.length), targetIndex, depth - 1) - 1;
      } else {
        if (targetIndex >= 0x1fffffffffffff) throw TypeError();
        target[targetIndex] = element;
      }

      targetIndex++;
    }
    sourceIndex++;
  }
  return targetIndex;
}

module.exports = flattenIntoArray;


/***/ }),
/* 131 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/tc39/proposal-string-pad-start-end
var toLength = __webpack_require__(11);
var repeat = __webpack_require__(82);
var defined = __webpack_require__(28);

module.exports = function (that, maxLength, fillString, left) {
  var S = String(defined(that));
  var stringLength = S.length;
  var fillStr = fillString === undefined ? ' ' : String(fillString);
  var intMaxLength = toLength(maxLength);
  if (intMaxLength <= stringLength || fillStr == '') return S;
  var fillLen = intMaxLength - stringLength;
  var stringFiller = repeat.call(fillStr, Math.ceil(fillLen / fillStr.length));
  if (stringFiller.length > fillLen) stringFiller = stringFiller.slice(0, fillLen);
  return left ? stringFiller + S : S + stringFiller;
};


/***/ }),
/* 132 */
/***/ (function(module, exports, __webpack_require__) {

var getKeys = __webpack_require__(40);
var toIObject = __webpack_require__(20);
var isEnum = __webpack_require__(54).f;
module.exports = function (isEntries) {
  return function (it) {
    var O = toIObject(it);
    var keys = getKeys(O);
    var length = keys.length;
    var i = 0;
    var result = [];
    var key;
    while (length > i) if (isEnum.call(O, key = keys[i++])) {
      result.push(isEntries ? [key, O[key]] : O[key]);
    } return result;
  };
};


/***/ }),
/* 133 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/DavidBruant/Map-Set.prototype.toJSON
var classof = __webpack_require__(55);
var from = __webpack_require__(134);
module.exports = function (NAME) {
  return function toJSON() {
    if (classof(this) != NAME) throw TypeError(NAME + "#toJSON isn't generic");
    return from(this);
  };
};


/***/ }),
/* 134 */
/***/ (function(module, exports, __webpack_require__) {

var forOf = __webpack_require__(46);

module.exports = function (iter, ITERATOR) {
  var result = [];
  forOf(iter, false, result.push, result, ITERATOR);
  return result;
};


/***/ }),
/* 135 */
/***/ (function(module, exports) {

// https://rwaldron.github.io/proposal-math-extensions/
module.exports = Math.scale || function scale(x, inLow, inHigh, outLow, outHigh) {
  if (
    arguments.length === 0
      // eslint-disable-next-line no-self-compare
      || x != x
      // eslint-disable-next-line no-self-compare
      || inLow != inLow
      // eslint-disable-next-line no-self-compare
      || inHigh != inHigh
      // eslint-disable-next-line no-self-compare
      || outLow != outLow
      // eslint-disable-next-line no-self-compare
      || outHigh != outHigh
  ) return NaN;
  if (x === Infinity || x === -Infinity) return x;
  return (x - inLow) * (outHigh - outLow) / (inHigh - inLow) + outLow;
};


/***/ }),
/* 136 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.formatCurrency = formatCurrency;
function formatCurrency(value) {
  var currencyFormatter = ynab.YNABSharedLibWebInstance.firstInstanceCreated.formattingManager.currencyFormatter;

  var userCurrency = currencyFormatter.getCurrency();

  var formattedCurrency = currencyFormatter.format(value).toString();
  if (userCurrency.symbol_first) {
    if (formattedCurrency.charAt(0) === '-') {
      formattedCurrency = '-' + userCurrency.currency_symbol + formattedCurrency.slice(1);
    } else {
      formattedCurrency = '' + userCurrency.currency_symbol + formattedCurrency;
    }
  } else {
    formattedCurrency = '' + formattedCurrency + userCurrency.currency_symbol;
  }

  return formattedCurrency;
}

/***/ }),
/* 137 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(522);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 138 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(523);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 139 */,
/* 140 */,
/* 141 */,
/* 142 */,
/* 143 */,
/* 144 */,
/* 145 */,
/* 146 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _ynabToolkit = __webpack_require__(147);

var ynabToolkit = new _ynabToolkit.YNABToolkit();
ynabToolkit.initializeToolkit();

/***/ }),
/* 147 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.YNABToolkit = exports.TOOLKIT_BOOTSTRAP_MESSAGE = exports.TOOLKIT_LOADED_MESSAGE = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

__webpack_require__(148);

var _features = __webpack_require__(350);

var _ynab = __webpack_require__(6);

var _feature = __webpack_require__(553);

var _withToolkitError = __webpack_require__(100);

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var TOOLKIT_LOADED_MESSAGE = exports.TOOLKIT_LOADED_MESSAGE = 'ynab-toolkit-loaded';
var TOOLKIT_BOOTSTRAP_MESSAGE = exports.TOOLKIT_BOOTSTRAP_MESSAGE = 'ynab-toolkit-bootstrap';

var YNABToolkit = exports.YNABToolkit = function () {
  function YNABToolkit() {
    var _this = this;

    _classCallCheck(this, YNABToolkit);

    this._featureInstances = [];

    this._onBackgroundMessage = function (event) {
      if (event.source === window && event.data.type === TOOLKIT_BOOTSTRAP_MESSAGE) {
        window.ynabToolKit = event.data.ynabToolKit;
        _this._createFeatureInstances();
        _this._removeMessageListener();
        _this._waitForUserSettings();
      }
    };

    this._invokeFeature = function (featureName) {
      var feature = _this._featureInstances.find(function (f) {
        return f.constructor.name === featureName;
      });
      var wrappedShouldInvoke = feature.shouldInvoke.bind(feature);
      var wrappedInvoke = feature.invoke.bind(feature);
      if ((0, _feature.isFeatureEnabled)(feature) && wrappedShouldInvoke()) {
        wrappedInvoke();
      }
    };

    this._invokeFeatureInstances = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
      return regeneratorRuntime.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              _this._featureInstances.forEach(function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(feature) {
                  var featureName, featureSetting, wrappedShouldInvoke, wrappedInvoke;
                  return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                      switch (_context.prev = _context.next) {
                        case 0:
                          if (!(0, _feature.isFeatureEnabled)(feature)) {
                            _context.next = 15;
                            break;
                          }

                          feature.applyListeners();

                          _context.prev = 2;
                          _context.next = 5;
                          return feature.willInvoke();

                        case 5:
                          _context.next = 12;
                          break;

                        case 7:
                          _context.prev = 7;
                          _context.t0 = _context['catch'](2);
                          featureName = feature.constructor.name;
                          featureSetting = ynabToolKit.options[featureName];

                          (0, _withToolkitError.logFeatureError)(_context.t0, featureName, 'willInvoke', featureSetting);

                        case 12:
                          wrappedShouldInvoke = (0, _withToolkitError.withToolkitError)(feature.shouldInvoke.bind(feature), feature);
                          wrappedInvoke = (0, _withToolkitError.withToolkitError)(feature.invoke.bind(feature), feature);

                          if (wrappedShouldInvoke()) {
                            wrappedInvoke();
                          }

                        case 15:
                        case 'end':
                          return _context.stop();
                      }
                    }
                  }, _callee, _this, [[2, 7]]);
                }));

                return function (_x) {
                  return _ref2.apply(this, arguments);
                };
              }());

            case 1:
            case 'end':
              return _context2.stop();
          }
        }
      }, _callee2, _this);
    }));
  }

  _createClass(YNABToolkit, [{
    key: 'initializeToolkit',
    value: function initializeToolkit() {
      window.addEventListener('message', this._onBackgroundMessage);
      window.postMessage(TOOLKIT_LOADED_MESSAGE, '*');
    }
  }, {
    key: '_removeMessageListener',
    value: function _removeMessageListener() {
      window.removeEventListener('message', this._onBackgroundMessage);
    }
  }, {
    key: '_createFeatureInstances',
    value: function _createFeatureInstances() {
      var _this2 = this;

      _features.features.forEach(function (Feature) {
        _this2._featureInstances.push(new Feature());
      });
    }
  }, {
    key: '_applyGlobalCSS',
    value: function _applyGlobalCSS() {
      var globalCSS = this._featureInstances.reduce(function (css, feature) {
        var wrappedInjectCSS = (0, _withToolkitError.withToolkitError)(feature.injectCSS.bind(feature), feature);
        var featureCSS = wrappedInjectCSS();

        if ((0, _feature.isFeatureEnabled)(feature) && featureCSS) {
          css += '/* == Injected CSS from feature: ' + feature.constructor.name + ' == */\n' + featureCSS + '\n\n';
        }

        return css;
      }, __webpack_require__(554));

      $('head').append($('<style>', { id: 'toolkit-injected-styles', type: 'text/css' }).text(globalCSS));
    }
  }, {
    key: '_waitForUserSettings',
    value: function _waitForUserSettings() {
      var self = this;

      (function poll() {
        if ((0, _ynab.isYNABReady)()) {
          // add a global invokeFeature to the global ynabToolKit for legacy features
          // once leagcy features have been removed, this should be a global exported function
          // from this file that features can require and use
          ynabToolKit.invokeFeature = self._invokeFeature;

          // inject the global css from each feature into the HEAD of the DOM
          self._applyGlobalCSS();

          // Hook up listeners and then invoke any features that are ready to go.
          self._invokeFeatureInstances();
        } else {
          setTimeout(poll, 250);
        }
      })();
    }
  }]);

  return YNABToolkit;
}();

/***/ }),
/* 148 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(global) {

__webpack_require__(149);

__webpack_require__(346);

__webpack_require__(347);

if (global._babelPolyfill) {
  throw new Error("only one instance of babel-polyfill is allowed");
}
global._babelPolyfill = true;

var DEFINE_PROPERTY = "defineProperty";
function define(O, key, value) {
  O[key] || Object[DEFINE_PROPERTY](O, key, {
    writable: true,
    configurable: true,
    value: value
  });
}

define(String.prototype, "padLeft", "".padStart);
define(String.prototype, "padRight", "".padEnd);

"pop,reverse,shift,keys,values,entries,indexOf,every,some,forEach,map,filter,find,findIndex,includes,join,slice,concat,push,splice,unshift,sort,lastIndexOf,reduce,reduceRight,copyWithin,fill".split(",").forEach(function (key) {
  [][key] && define(Array, key, Function.call.bind([][key]));
});
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(101)))

/***/ }),
/* 149 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(150);
__webpack_require__(152);
__webpack_require__(153);
__webpack_require__(154);
__webpack_require__(155);
__webpack_require__(156);
__webpack_require__(157);
__webpack_require__(158);
__webpack_require__(159);
__webpack_require__(160);
__webpack_require__(161);
__webpack_require__(162);
__webpack_require__(163);
__webpack_require__(164);
__webpack_require__(165);
__webpack_require__(166);
__webpack_require__(168);
__webpack_require__(169);
__webpack_require__(170);
__webpack_require__(171);
__webpack_require__(172);
__webpack_require__(173);
__webpack_require__(174);
__webpack_require__(175);
__webpack_require__(176);
__webpack_require__(177);
__webpack_require__(178);
__webpack_require__(179);
__webpack_require__(180);
__webpack_require__(181);
__webpack_require__(182);
__webpack_require__(183);
__webpack_require__(184);
__webpack_require__(185);
__webpack_require__(186);
__webpack_require__(187);
__webpack_require__(188);
__webpack_require__(189);
__webpack_require__(190);
__webpack_require__(191);
__webpack_require__(192);
__webpack_require__(193);
__webpack_require__(194);
__webpack_require__(195);
__webpack_require__(196);
__webpack_require__(197);
__webpack_require__(198);
__webpack_require__(199);
__webpack_require__(200);
__webpack_require__(201);
__webpack_require__(202);
__webpack_require__(203);
__webpack_require__(204);
__webpack_require__(205);
__webpack_require__(206);
__webpack_require__(207);
__webpack_require__(208);
__webpack_require__(209);
__webpack_require__(210);
__webpack_require__(211);
__webpack_require__(212);
__webpack_require__(213);
__webpack_require__(214);
__webpack_require__(215);
__webpack_require__(216);
__webpack_require__(217);
__webpack_require__(218);
__webpack_require__(219);
__webpack_require__(220);
__webpack_require__(221);
__webpack_require__(222);
__webpack_require__(223);
__webpack_require__(224);
__webpack_require__(225);
__webpack_require__(226);
__webpack_require__(227);
__webpack_require__(228);
__webpack_require__(230);
__webpack_require__(231);
__webpack_require__(233);
__webpack_require__(234);
__webpack_require__(235);
__webpack_require__(236);
__webpack_require__(237);
__webpack_require__(238);
__webpack_require__(239);
__webpack_require__(241);
__webpack_require__(242);
__webpack_require__(243);
__webpack_require__(244);
__webpack_require__(245);
__webpack_require__(246);
__webpack_require__(247);
__webpack_require__(248);
__webpack_require__(249);
__webpack_require__(250);
__webpack_require__(251);
__webpack_require__(252);
__webpack_require__(253);
__webpack_require__(95);
__webpack_require__(254);
__webpack_require__(255);
__webpack_require__(120);
__webpack_require__(256);
__webpack_require__(257);
__webpack_require__(258);
__webpack_require__(259);
__webpack_require__(260);
__webpack_require__(123);
__webpack_require__(125);
__webpack_require__(126);
__webpack_require__(261);
__webpack_require__(262);
__webpack_require__(263);
__webpack_require__(264);
__webpack_require__(265);
__webpack_require__(266);
__webpack_require__(267);
__webpack_require__(268);
__webpack_require__(269);
__webpack_require__(270);
__webpack_require__(271);
__webpack_require__(272);
__webpack_require__(273);
__webpack_require__(274);
__webpack_require__(275);
__webpack_require__(276);
__webpack_require__(277);
__webpack_require__(278);
__webpack_require__(279);
__webpack_require__(280);
__webpack_require__(281);
__webpack_require__(282);
__webpack_require__(283);
__webpack_require__(284);
__webpack_require__(285);
__webpack_require__(286);
__webpack_require__(287);
__webpack_require__(288);
__webpack_require__(289);
__webpack_require__(290);
__webpack_require__(291);
__webpack_require__(292);
__webpack_require__(293);
__webpack_require__(294);
__webpack_require__(295);
__webpack_require__(296);
__webpack_require__(297);
__webpack_require__(298);
__webpack_require__(299);
__webpack_require__(300);
__webpack_require__(301);
__webpack_require__(302);
__webpack_require__(303);
__webpack_require__(304);
__webpack_require__(305);
__webpack_require__(306);
__webpack_require__(307);
__webpack_require__(308);
__webpack_require__(309);
__webpack_require__(310);
__webpack_require__(311);
__webpack_require__(312);
__webpack_require__(313);
__webpack_require__(314);
__webpack_require__(315);
__webpack_require__(316);
__webpack_require__(317);
__webpack_require__(318);
__webpack_require__(319);
__webpack_require__(320);
__webpack_require__(321);
__webpack_require__(322);
__webpack_require__(323);
__webpack_require__(324);
__webpack_require__(325);
__webpack_require__(326);
__webpack_require__(327);
__webpack_require__(328);
__webpack_require__(329);
__webpack_require__(330);
__webpack_require__(331);
__webpack_require__(332);
__webpack_require__(333);
__webpack_require__(334);
__webpack_require__(335);
__webpack_require__(336);
__webpack_require__(337);
__webpack_require__(338);
__webpack_require__(339);
__webpack_require__(340);
__webpack_require__(341);
__webpack_require__(342);
__webpack_require__(343);
__webpack_require__(344);
__webpack_require__(345);
module.exports = __webpack_require__(26);


/***/ }),
/* 150 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// ECMAScript 6 symbols shim
var global = __webpack_require__(4);
var has = __webpack_require__(16);
var DESCRIPTORS = __webpack_require__(9);
var $export = __webpack_require__(0);
var redefine = __webpack_require__(18);
var META = __webpack_require__(35).KEY;
var $fails = __webpack_require__(5);
var shared = __webpack_require__(56);
var setToStringTag = __webpack_require__(49);
var uid = __webpack_require__(38);
var wks = __webpack_require__(8);
var wksExt = __webpack_require__(103);
var wksDefine = __webpack_require__(75);
var enumKeys = __webpack_require__(151);
var isArray = __webpack_require__(59);
var anObject = __webpack_require__(3);
var toIObject = __webpack_require__(20);
var toPrimitive = __webpack_require__(27);
var createDesc = __webpack_require__(37);
var _create = __webpack_require__(42);
var gOPNExt = __webpack_require__(106);
var $GOPD = __webpack_require__(21);
var $DP = __webpack_require__(10);
var $keys = __webpack_require__(40);
var gOPD = $GOPD.f;
var dP = $DP.f;
var gOPN = gOPNExt.f;
var $Symbol = global.Symbol;
var $JSON = global.JSON;
var _stringify = $JSON && $JSON.stringify;
var PROTOTYPE = 'prototype';
var HIDDEN = wks('_hidden');
var TO_PRIMITIVE = wks('toPrimitive');
var isEnum = {}.propertyIsEnumerable;
var SymbolRegistry = shared('symbol-registry');
var AllSymbols = shared('symbols');
var OPSymbols = shared('op-symbols');
var ObjectProto = Object[PROTOTYPE];
var USE_NATIVE = typeof $Symbol == 'function';
var QObject = global.QObject;
// Don't use setters in Qt Script, https://github.com/zloirock/core-js/issues/173
var setter = !QObject || !QObject[PROTOTYPE] || !QObject[PROTOTYPE].findChild;

// fallback for old Android, https://code.google.com/p/v8/issues/detail?id=687
var setSymbolDesc = DESCRIPTORS && $fails(function () {
  return _create(dP({}, 'a', {
    get: function () { return dP(this, 'a', { value: 7 }).a; }
  })).a != 7;
}) ? function (it, key, D) {
  var protoDesc = gOPD(ObjectProto, key);
  if (protoDesc) delete ObjectProto[key];
  dP(it, key, D);
  if (protoDesc && it !== ObjectProto) dP(ObjectProto, key, protoDesc);
} : dP;

var wrap = function (tag) {
  var sym = AllSymbols[tag] = _create($Symbol[PROTOTYPE]);
  sym._k = tag;
  return sym;
};

var isSymbol = USE_NATIVE && typeof $Symbol.iterator == 'symbol' ? function (it) {
  return typeof it == 'symbol';
} : function (it) {
  return it instanceof $Symbol;
};

var $defineProperty = function defineProperty(it, key, D) {
  if (it === ObjectProto) $defineProperty(OPSymbols, key, D);
  anObject(it);
  key = toPrimitive(key, true);
  anObject(D);
  if (has(AllSymbols, key)) {
    if (!D.enumerable) {
      if (!has(it, HIDDEN)) dP(it, HIDDEN, createDesc(1, {}));
      it[HIDDEN][key] = true;
    } else {
      if (has(it, HIDDEN) && it[HIDDEN][key]) it[HIDDEN][key] = false;
      D = _create(D, { enumerable: createDesc(0, false) });
    } return setSymbolDesc(it, key, D);
  } return dP(it, key, D);
};
var $defineProperties = function defineProperties(it, P) {
  anObject(it);
  var keys = enumKeys(P = toIObject(P));
  var i = 0;
  var l = keys.length;
  var key;
  while (l > i) $defineProperty(it, key = keys[i++], P[key]);
  return it;
};
var $create = function create(it, P) {
  return P === undefined ? _create(it) : $defineProperties(_create(it), P);
};
var $propertyIsEnumerable = function propertyIsEnumerable(key) {
  var E = isEnum.call(this, key = toPrimitive(key, true));
  if (this === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return false;
  return E || !has(this, key) || !has(AllSymbols, key) || has(this, HIDDEN) && this[HIDDEN][key] ? E : true;
};
var $getOwnPropertyDescriptor = function getOwnPropertyDescriptor(it, key) {
  it = toIObject(it);
  key = toPrimitive(key, true);
  if (it === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return;
  var D = gOPD(it, key);
  if (D && has(AllSymbols, key) && !(has(it, HIDDEN) && it[HIDDEN][key])) D.enumerable = true;
  return D;
};
var $getOwnPropertyNames = function getOwnPropertyNames(it) {
  var names = gOPN(toIObject(it));
  var result = [];
  var i = 0;
  var key;
  while (names.length > i) {
    if (!has(AllSymbols, key = names[i++]) && key != HIDDEN && key != META) result.push(key);
  } return result;
};
var $getOwnPropertySymbols = function getOwnPropertySymbols(it) {
  var IS_OP = it === ObjectProto;
  var names = gOPN(IS_OP ? OPSymbols : toIObject(it));
  var result = [];
  var i = 0;
  var key;
  while (names.length > i) {
    if (has(AllSymbols, key = names[i++]) && (IS_OP ? has(ObjectProto, key) : true)) result.push(AllSymbols[key]);
  } return result;
};

// 19.4.1.1 Symbol([description])
if (!USE_NATIVE) {
  $Symbol = function Symbol() {
    if (this instanceof $Symbol) throw TypeError('Symbol is not a constructor!');
    var tag = uid(arguments.length > 0 ? arguments[0] : undefined);
    var $set = function (value) {
      if (this === ObjectProto) $set.call(OPSymbols, value);
      if (has(this, HIDDEN) && has(this[HIDDEN], tag)) this[HIDDEN][tag] = false;
      setSymbolDesc(this, tag, createDesc(1, value));
    };
    if (DESCRIPTORS && setter) setSymbolDesc(ObjectProto, tag, { configurable: true, set: $set });
    return wrap(tag);
  };
  redefine($Symbol[PROTOTYPE], 'toString', function toString() {
    return this._k;
  });

  $GOPD.f = $getOwnPropertyDescriptor;
  $DP.f = $defineProperty;
  __webpack_require__(43).f = gOPNExt.f = $getOwnPropertyNames;
  __webpack_require__(54).f = $propertyIsEnumerable;
  __webpack_require__(58).f = $getOwnPropertySymbols;

  if (DESCRIPTORS && !__webpack_require__(39)) {
    redefine(ObjectProto, 'propertyIsEnumerable', $propertyIsEnumerable, true);
  }

  wksExt.f = function (name) {
    return wrap(wks(name));
  };
}

$export($export.G + $export.W + $export.F * !USE_NATIVE, { Symbol: $Symbol });

for (var es6Symbols = (
  // 19.4.2.2, 19.4.2.3, 19.4.2.4, 19.4.2.6, 19.4.2.8, 19.4.2.9, 19.4.2.10, 19.4.2.11, 19.4.2.12, 19.4.2.13, 19.4.2.14
  'hasInstance,isConcatSpreadable,iterator,match,replace,search,species,split,toPrimitive,toStringTag,unscopables'
).split(','), j = 0; es6Symbols.length > j;)wks(es6Symbols[j++]);

for (var wellKnownSymbols = $keys(wks.store), k = 0; wellKnownSymbols.length > k;) wksDefine(wellKnownSymbols[k++]);

$export($export.S + $export.F * !USE_NATIVE, 'Symbol', {
  // 19.4.2.1 Symbol.for(key)
  'for': function (key) {
    return has(SymbolRegistry, key += '')
      ? SymbolRegistry[key]
      : SymbolRegistry[key] = $Symbol(key);
  },
  // 19.4.2.5 Symbol.keyFor(sym)
  keyFor: function keyFor(sym) {
    if (!isSymbol(sym)) throw TypeError(sym + ' is not a symbol!');
    for (var key in SymbolRegistry) if (SymbolRegistry[key] === sym) return key;
  },
  useSetter: function () { setter = true; },
  useSimple: function () { setter = false; }
});

$export($export.S + $export.F * !USE_NATIVE, 'Object', {
  // 19.1.2.2 Object.create(O [, Properties])
  create: $create,
  // 19.1.2.4 Object.defineProperty(O, P, Attributes)
  defineProperty: $defineProperty,
  // 19.1.2.3 Object.defineProperties(O, Properties)
  defineProperties: $defineProperties,
  // 19.1.2.6 Object.getOwnPropertyDescriptor(O, P)
  getOwnPropertyDescriptor: $getOwnPropertyDescriptor,
  // 19.1.2.7 Object.getOwnPropertyNames(O)
  getOwnPropertyNames: $getOwnPropertyNames,
  // 19.1.2.8 Object.getOwnPropertySymbols(O)
  getOwnPropertySymbols: $getOwnPropertySymbols
});

// 24.3.2 JSON.stringify(value [, replacer [, space]])
$JSON && $export($export.S + $export.F * (!USE_NATIVE || $fails(function () {
  var S = $Symbol();
  // MS Edge converts symbol values to JSON as {}
  // WebKit converts symbol values to JSON as null
  // V8 throws on boxed symbols
  return _stringify([S]) != '[null]' || _stringify({ a: S }) != '{}' || _stringify(Object(S)) != '{}';
})), 'JSON', {
  stringify: function stringify(it) {
    if (it === undefined || isSymbol(it)) return; // IE8 returns string on undefined
    var args = [it];
    var i = 1;
    var replacer, $replacer;
    while (arguments.length > i) args.push(arguments[i++]);
    replacer = args[1];
    if (typeof replacer == 'function') $replacer = replacer;
    if ($replacer || !isArray(replacer)) replacer = function (key, value) {
      if ($replacer) value = $replacer.call(this, key, value);
      if (!isSymbol(value)) return value;
    };
    args[1] = replacer;
    return _stringify.apply($JSON, args);
  }
});

// 19.4.3.4 Symbol.prototype[@@toPrimitive](hint)
$Symbol[PROTOTYPE][TO_PRIMITIVE] || __webpack_require__(17)($Symbol[PROTOTYPE], TO_PRIMITIVE, $Symbol[PROTOTYPE].valueOf);
// 19.4.3.5 Symbol.prototype[@@toStringTag]
setToStringTag($Symbol, 'Symbol');
// 20.2.1.9 Math[@@toStringTag]
setToStringTag(Math, 'Math', true);
// 24.3.3 JSON[@@toStringTag]
setToStringTag(global.JSON, 'JSON', true);


/***/ }),
/* 151 */
/***/ (function(module, exports, __webpack_require__) {

// all enumerable object keys, includes symbols
var getKeys = __webpack_require__(40);
var gOPS = __webpack_require__(58);
var pIE = __webpack_require__(54);
module.exports = function (it) {
  var result = getKeys(it);
  var getSymbols = gOPS.f;
  if (getSymbols) {
    var symbols = getSymbols(it);
    var isEnum = pIE.f;
    var i = 0;
    var key;
    while (symbols.length > i) if (isEnum.call(it, key = symbols[i++])) result.push(key);
  } return result;
};


/***/ }),
/* 152 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
// 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
$export($export.S, 'Object', { create: __webpack_require__(42) });


/***/ }),
/* 153 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
// 19.1.2.4 / 15.2.3.6 Object.defineProperty(O, P, Attributes)
$export($export.S + $export.F * !__webpack_require__(9), 'Object', { defineProperty: __webpack_require__(10).f });


/***/ }),
/* 154 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
// 19.1.2.3 / 15.2.3.7 Object.defineProperties(O, Properties)
$export($export.S + $export.F * !__webpack_require__(9), 'Object', { defineProperties: __webpack_require__(105) });


/***/ }),
/* 155 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.6 Object.getOwnPropertyDescriptor(O, P)
var toIObject = __webpack_require__(20);
var $getOwnPropertyDescriptor = __webpack_require__(21).f;

__webpack_require__(30)('getOwnPropertyDescriptor', function () {
  return function getOwnPropertyDescriptor(it, key) {
    return $getOwnPropertyDescriptor(toIObject(it), key);
  };
});


/***/ }),
/* 156 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.9 Object.getPrototypeOf(O)
var toObject = __webpack_require__(12);
var $getPrototypeOf = __webpack_require__(22);

__webpack_require__(30)('getPrototypeOf', function () {
  return function getPrototypeOf(it) {
    return $getPrototypeOf(toObject(it));
  };
});


/***/ }),
/* 157 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.14 Object.keys(O)
var toObject = __webpack_require__(12);
var $keys = __webpack_require__(40);

__webpack_require__(30)('keys', function () {
  return function keys(it) {
    return $keys(toObject(it));
  };
});


/***/ }),
/* 158 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.7 Object.getOwnPropertyNames(O)
__webpack_require__(30)('getOwnPropertyNames', function () {
  return __webpack_require__(106).f;
});


/***/ }),
/* 159 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.5 Object.freeze(O)
var isObject = __webpack_require__(7);
var meta = __webpack_require__(35).onFreeze;

__webpack_require__(30)('freeze', function ($freeze) {
  return function freeze(it) {
    return $freeze && isObject(it) ? $freeze(meta(it)) : it;
  };
});


/***/ }),
/* 160 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.17 Object.seal(O)
var isObject = __webpack_require__(7);
var meta = __webpack_require__(35).onFreeze;

__webpack_require__(30)('seal', function ($seal) {
  return function seal(it) {
    return $seal && isObject(it) ? $seal(meta(it)) : it;
  };
});


/***/ }),
/* 161 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.15 Object.preventExtensions(O)
var isObject = __webpack_require__(7);
var meta = __webpack_require__(35).onFreeze;

__webpack_require__(30)('preventExtensions', function ($preventExtensions) {
  return function preventExtensions(it) {
    return $preventExtensions && isObject(it) ? $preventExtensions(meta(it)) : it;
  };
});


/***/ }),
/* 162 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.12 Object.isFrozen(O)
var isObject = __webpack_require__(7);

__webpack_require__(30)('isFrozen', function ($isFrozen) {
  return function isFrozen(it) {
    return isObject(it) ? $isFrozen ? $isFrozen(it) : false : true;
  };
});


/***/ }),
/* 163 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.13 Object.isSealed(O)
var isObject = __webpack_require__(7);

__webpack_require__(30)('isSealed', function ($isSealed) {
  return function isSealed(it) {
    return isObject(it) ? $isSealed ? $isSealed(it) : false : true;
  };
});


/***/ }),
/* 164 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.11 Object.isExtensible(O)
var isObject = __webpack_require__(7);

__webpack_require__(30)('isExtensible', function ($isExtensible) {
  return function isExtensible(it) {
    return isObject(it) ? $isExtensible ? $isExtensible(it) : true : false;
  };
});


/***/ }),
/* 165 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.3.1 Object.assign(target, source)
var $export = __webpack_require__(0);

$export($export.S + $export.F, 'Object', { assign: __webpack_require__(107) });


/***/ }),
/* 166 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.3.10 Object.is(value1, value2)
var $export = __webpack_require__(0);
$export($export.S, 'Object', { is: __webpack_require__(167) });


/***/ }),
/* 167 */
/***/ (function(module, exports) {

// 7.2.9 SameValue(x, y)
module.exports = Object.is || function is(x, y) {
  // eslint-disable-next-line no-self-compare
  return x === y ? x !== 0 || 1 / x === 1 / y : x != x && y != y;
};


/***/ }),
/* 168 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.3.19 Object.setPrototypeOf(O, proto)
var $export = __webpack_require__(0);
$export($export.S, 'Object', { setPrototypeOf: __webpack_require__(79).set });


/***/ }),
/* 169 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 19.1.3.6 Object.prototype.toString()
var classof = __webpack_require__(55);
var test = {};
test[__webpack_require__(8)('toStringTag')] = 'z';
if (test + '' != '[object z]') {
  __webpack_require__(18)(Object.prototype, 'toString', function toString() {
    return '[object ' + classof(this) + ']';
  }, true);
}


/***/ }),
/* 170 */
/***/ (function(module, exports, __webpack_require__) {

// 19.2.3.2 / 15.3.4.5 Function.prototype.bind(thisArg, args...)
var $export = __webpack_require__(0);

$export($export.P, 'Function', { bind: __webpack_require__(108) });


/***/ }),
/* 171 */
/***/ (function(module, exports, __webpack_require__) {

var dP = __webpack_require__(10).f;
var FProto = Function.prototype;
var nameRE = /^\s*function ([^ (]*)/;
var NAME = 'name';

// 19.2.4.2 name
NAME in FProto || __webpack_require__(9) && dP(FProto, NAME, {
  configurable: true,
  get: function () {
    try {
      return ('' + this).match(nameRE)[1];
    } catch (e) {
      return '';
    }
  }
});


/***/ }),
/* 172 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var isObject = __webpack_require__(7);
var getPrototypeOf = __webpack_require__(22);
var HAS_INSTANCE = __webpack_require__(8)('hasInstance');
var FunctionProto = Function.prototype;
// 19.2.3.6 Function.prototype[@@hasInstance](V)
if (!(HAS_INSTANCE in FunctionProto)) __webpack_require__(10).f(FunctionProto, HAS_INSTANCE, { value: function (O) {
  if (typeof this != 'function' || !isObject(O)) return false;
  if (!isObject(this.prototype)) return O instanceof this;
  // for environment w/o native `@@hasInstance` logic enough `instanceof`, but add this:
  while (O = getPrototypeOf(O)) if (this.prototype === O) return true;
  return false;
} });


/***/ }),
/* 173 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var $parseInt = __webpack_require__(110);
// 18.2.5 parseInt(string, radix)
$export($export.G + $export.F * (parseInt != $parseInt), { parseInt: $parseInt });


/***/ }),
/* 174 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var $parseFloat = __webpack_require__(111);
// 18.2.4 parseFloat(string)
$export($export.G + $export.F * (parseFloat != $parseFloat), { parseFloat: $parseFloat });


/***/ }),
/* 175 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var global = __webpack_require__(4);
var has = __webpack_require__(16);
var cof = __webpack_require__(24);
var inheritIfRequired = __webpack_require__(81);
var toPrimitive = __webpack_require__(27);
var fails = __webpack_require__(5);
var gOPN = __webpack_require__(43).f;
var gOPD = __webpack_require__(21).f;
var dP = __webpack_require__(10).f;
var $trim = __webpack_require__(50).trim;
var NUMBER = 'Number';
var $Number = global[NUMBER];
var Base = $Number;
var proto = $Number.prototype;
// Opera ~12 has broken Object#toString
var BROKEN_COF = cof(__webpack_require__(42)(proto)) == NUMBER;
var TRIM = 'trim' in String.prototype;

// 7.1.3 ToNumber(argument)
var toNumber = function (argument) {
  var it = toPrimitive(argument, false);
  if (typeof it == 'string' && it.length > 2) {
    it = TRIM ? it.trim() : $trim(it, 3);
    var first = it.charCodeAt(0);
    var third, radix, maxCode;
    if (first === 43 || first === 45) {
      third = it.charCodeAt(2);
      if (third === 88 || third === 120) return NaN; // Number('+0x1') should be NaN, old V8 fix
    } else if (first === 48) {
      switch (it.charCodeAt(1)) {
        case 66: case 98: radix = 2; maxCode = 49; break; // fast equal /^0b[01]+$/i
        case 79: case 111: radix = 8; maxCode = 55; break; // fast equal /^0o[0-7]+$/i
        default: return +it;
      }
      for (var digits = it.slice(2), i = 0, l = digits.length, code; i < l; i++) {
        code = digits.charCodeAt(i);
        // parseInt parses a string to a first unavailable symbol
        // but ToNumber should return NaN if a string contains unavailable symbols
        if (code < 48 || code > maxCode) return NaN;
      } return parseInt(digits, radix);
    }
  } return +it;
};

if (!$Number(' 0o1') || !$Number('0b1') || $Number('+0x1')) {
  $Number = function Number(value) {
    var it = arguments.length < 1 ? 0 : value;
    var that = this;
    return that instanceof $Number
      // check on 1..constructor(foo) case
      && (BROKEN_COF ? fails(function () { proto.valueOf.call(that); }) : cof(that) != NUMBER)
        ? inheritIfRequired(new Base(toNumber(it)), that, $Number) : toNumber(it);
  };
  for (var keys = __webpack_require__(9) ? gOPN(Base) : (
    // ES3:
    'MAX_VALUE,MIN_VALUE,NaN,NEGATIVE_INFINITY,POSITIVE_INFINITY,' +
    // ES6 (in case, if modules with ES6 Number statics required before):
    'EPSILON,isFinite,isInteger,isNaN,isSafeInteger,MAX_SAFE_INTEGER,' +
    'MIN_SAFE_INTEGER,parseFloat,parseInt,isInteger'
  ).split(','), j = 0, key; keys.length > j; j++) {
    if (has(Base, key = keys[j]) && !has($Number, key)) {
      dP($Number, key, gOPD(Base, key));
    }
  }
  $Number.prototype = proto;
  proto.constructor = $Number;
  __webpack_require__(18)(global, NUMBER, $Number);
}


/***/ }),
/* 176 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var toInteger = __webpack_require__(29);
var aNumberValue = __webpack_require__(112);
var repeat = __webpack_require__(82);
var $toFixed = 1.0.toFixed;
var floor = Math.floor;
var data = [0, 0, 0, 0, 0, 0];
var ERROR = 'Number.toFixed: incorrect invocation!';
var ZERO = '0';

var multiply = function (n, c) {
  var i = -1;
  var c2 = c;
  while (++i < 6) {
    c2 += n * data[i];
    data[i] = c2 % 1e7;
    c2 = floor(c2 / 1e7);
  }
};
var divide = function (n) {
  var i = 6;
  var c = 0;
  while (--i >= 0) {
    c += data[i];
    data[i] = floor(c / n);
    c = (c % n) * 1e7;
  }
};
var numToString = function () {
  var i = 6;
  var s = '';
  while (--i >= 0) {
    if (s !== '' || i === 0 || data[i] !== 0) {
      var t = String(data[i]);
      s = s === '' ? t : s + repeat.call(ZERO, 7 - t.length) + t;
    }
  } return s;
};
var pow = function (x, n, acc) {
  return n === 0 ? acc : n % 2 === 1 ? pow(x, n - 1, acc * x) : pow(x * x, n / 2, acc);
};
var log = function (x) {
  var n = 0;
  var x2 = x;
  while (x2 >= 4096) {
    n += 12;
    x2 /= 4096;
  }
  while (x2 >= 2) {
    n += 1;
    x2 /= 2;
  } return n;
};

$export($export.P + $export.F * (!!$toFixed && (
  0.00008.toFixed(3) !== '0.000' ||
  0.9.toFixed(0) !== '1' ||
  1.255.toFixed(2) !== '1.25' ||
  1000000000000000128.0.toFixed(0) !== '1000000000000000128'
) || !__webpack_require__(5)(function () {
  // V8 ~ Android 4.3-
  $toFixed.call({});
})), 'Number', {
  toFixed: function toFixed(fractionDigits) {
    var x = aNumberValue(this, ERROR);
    var f = toInteger(fractionDigits);
    var s = '';
    var m = ZERO;
    var e, z, j, k;
    if (f < 0 || f > 20) throw RangeError(ERROR);
    // eslint-disable-next-line no-self-compare
    if (x != x) return 'NaN';
    if (x <= -1e21 || x >= 1e21) return String(x);
    if (x < 0) {
      s = '-';
      x = -x;
    }
    if (x > 1e-21) {
      e = log(x * pow(2, 69, 1)) - 69;
      z = e < 0 ? x * pow(2, -e, 1) : x / pow(2, e, 1);
      z *= 0x10000000000000;
      e = 52 - e;
      if (e > 0) {
        multiply(0, z);
        j = f;
        while (j >= 7) {
          multiply(1e7, 0);
          j -= 7;
        }
        multiply(pow(10, j, 1), 0);
        j = e - 1;
        while (j >= 23) {
          divide(1 << 23);
          j -= 23;
        }
        divide(1 << j);
        multiply(1, 1);
        divide(2);
        m = numToString();
      } else {
        multiply(0, z);
        multiply(1 << -e, 0);
        m = numToString() + repeat.call(ZERO, f);
      }
    }
    if (f > 0) {
      k = m.length;
      m = s + (k <= f ? '0.' + repeat.call(ZERO, f - k) + m : m.slice(0, k - f) + '.' + m.slice(k - f));
    } else {
      m = s + m;
    } return m;
  }
});


/***/ }),
/* 177 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $fails = __webpack_require__(5);
var aNumberValue = __webpack_require__(112);
var $toPrecision = 1.0.toPrecision;

$export($export.P + $export.F * ($fails(function () {
  // IE7-
  return $toPrecision.call(1, undefined) !== '1';
}) || !$fails(function () {
  // V8 ~ Android 4.3-
  $toPrecision.call({});
})), 'Number', {
  toPrecision: function toPrecision(precision) {
    var that = aNumberValue(this, 'Number#toPrecision: incorrect invocation!');
    return precision === undefined ? $toPrecision.call(that) : $toPrecision.call(that, precision);
  }
});


/***/ }),
/* 178 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.1 Number.EPSILON
var $export = __webpack_require__(0);

$export($export.S, 'Number', { EPSILON: Math.pow(2, -52) });


/***/ }),
/* 179 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.2 Number.isFinite(number)
var $export = __webpack_require__(0);
var _isFinite = __webpack_require__(4).isFinite;

$export($export.S, 'Number', {
  isFinite: function isFinite(it) {
    return typeof it == 'number' && _isFinite(it);
  }
});


/***/ }),
/* 180 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.3 Number.isInteger(number)
var $export = __webpack_require__(0);

$export($export.S, 'Number', { isInteger: __webpack_require__(113) });


/***/ }),
/* 181 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.4 Number.isNaN(number)
var $export = __webpack_require__(0);

$export($export.S, 'Number', {
  isNaN: function isNaN(number) {
    // eslint-disable-next-line no-self-compare
    return number != number;
  }
});


/***/ }),
/* 182 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.5 Number.isSafeInteger(number)
var $export = __webpack_require__(0);
var isInteger = __webpack_require__(113);
var abs = Math.abs;

$export($export.S, 'Number', {
  isSafeInteger: function isSafeInteger(number) {
    return isInteger(number) && abs(number) <= 0x1fffffffffffff;
  }
});


/***/ }),
/* 183 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.6 Number.MAX_SAFE_INTEGER
var $export = __webpack_require__(0);

$export($export.S, 'Number', { MAX_SAFE_INTEGER: 0x1fffffffffffff });


/***/ }),
/* 184 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.10 Number.MIN_SAFE_INTEGER
var $export = __webpack_require__(0);

$export($export.S, 'Number', { MIN_SAFE_INTEGER: -0x1fffffffffffff });


/***/ }),
/* 185 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var $parseFloat = __webpack_require__(111);
// 20.1.2.12 Number.parseFloat(string)
$export($export.S + $export.F * (Number.parseFloat != $parseFloat), 'Number', { parseFloat: $parseFloat });


/***/ }),
/* 186 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var $parseInt = __webpack_require__(110);
// 20.1.2.13 Number.parseInt(string, radix)
$export($export.S + $export.F * (Number.parseInt != $parseInt), 'Number', { parseInt: $parseInt });


/***/ }),
/* 187 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.3 Math.acosh(x)
var $export = __webpack_require__(0);
var log1p = __webpack_require__(114);
var sqrt = Math.sqrt;
var $acosh = Math.acosh;

$export($export.S + $export.F * !($acosh
  // V8 bug: https://code.google.com/p/v8/issues/detail?id=3509
  && Math.floor($acosh(Number.MAX_VALUE)) == 710
  // Tor Browser bug: Math.acosh(Infinity) -> NaN
  && $acosh(Infinity) == Infinity
), 'Math', {
  acosh: function acosh(x) {
    return (x = +x) < 1 ? NaN : x > 94906265.62425156
      ? Math.log(x) + Math.LN2
      : log1p(x - 1 + sqrt(x - 1) * sqrt(x + 1));
  }
});


/***/ }),
/* 188 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.5 Math.asinh(x)
var $export = __webpack_require__(0);
var $asinh = Math.asinh;

function asinh(x) {
  return !isFinite(x = +x) || x == 0 ? x : x < 0 ? -asinh(-x) : Math.log(x + Math.sqrt(x * x + 1));
}

// Tor Browser bug: Math.asinh(0) -> -0
$export($export.S + $export.F * !($asinh && 1 / $asinh(0) > 0), 'Math', { asinh: asinh });


/***/ }),
/* 189 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.7 Math.atanh(x)
var $export = __webpack_require__(0);
var $atanh = Math.atanh;

// Tor Browser bug: Math.atanh(-0) -> 0
$export($export.S + $export.F * !($atanh && 1 / $atanh(-0) < 0), 'Math', {
  atanh: function atanh(x) {
    return (x = +x) == 0 ? x : Math.log((1 + x) / (1 - x)) / 2;
  }
});


/***/ }),
/* 190 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.9 Math.cbrt(x)
var $export = __webpack_require__(0);
var sign = __webpack_require__(83);

$export($export.S, 'Math', {
  cbrt: function cbrt(x) {
    return sign(x = +x) * Math.pow(Math.abs(x), 1 / 3);
  }
});


/***/ }),
/* 191 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.11 Math.clz32(x)
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  clz32: function clz32(x) {
    return (x >>>= 0) ? 31 - Math.floor(Math.log(x + 0.5) * Math.LOG2E) : 32;
  }
});


/***/ }),
/* 192 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.12 Math.cosh(x)
var $export = __webpack_require__(0);
var exp = Math.exp;

$export($export.S, 'Math', {
  cosh: function cosh(x) {
    return (exp(x = +x) + exp(-x)) / 2;
  }
});


/***/ }),
/* 193 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.14 Math.expm1(x)
var $export = __webpack_require__(0);
var $expm1 = __webpack_require__(84);

$export($export.S + $export.F * ($expm1 != Math.expm1), 'Math', { expm1: $expm1 });


/***/ }),
/* 194 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.16 Math.fround(x)
var $export = __webpack_require__(0);

$export($export.S, 'Math', { fround: __webpack_require__(115) });


/***/ }),
/* 195 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.17 Math.hypot([value1[, value2[, … ]]])
var $export = __webpack_require__(0);
var abs = Math.abs;

$export($export.S, 'Math', {
  hypot: function hypot(value1, value2) { // eslint-disable-line no-unused-vars
    var sum = 0;
    var i = 0;
    var aLen = arguments.length;
    var larg = 0;
    var arg, div;
    while (i < aLen) {
      arg = abs(arguments[i++]);
      if (larg < arg) {
        div = larg / arg;
        sum = sum * div * div + 1;
        larg = arg;
      } else if (arg > 0) {
        div = arg / larg;
        sum += div * div;
      } else sum += arg;
    }
    return larg === Infinity ? Infinity : larg * Math.sqrt(sum);
  }
});


/***/ }),
/* 196 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.18 Math.imul(x, y)
var $export = __webpack_require__(0);
var $imul = Math.imul;

// some WebKit versions fails with big numbers, some has wrong arity
$export($export.S + $export.F * __webpack_require__(5)(function () {
  return $imul(0xffffffff, 5) != -5 || $imul.length != 2;
}), 'Math', {
  imul: function imul(x, y) {
    var UINT16 = 0xffff;
    var xn = +x;
    var yn = +y;
    var xl = UINT16 & xn;
    var yl = UINT16 & yn;
    return 0 | xl * yl + ((UINT16 & xn >>> 16) * yl + xl * (UINT16 & yn >>> 16) << 16 >>> 0);
  }
});


/***/ }),
/* 197 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.21 Math.log10(x)
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  log10: function log10(x) {
    return Math.log(x) * Math.LOG10E;
  }
});


/***/ }),
/* 198 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.20 Math.log1p(x)
var $export = __webpack_require__(0);

$export($export.S, 'Math', { log1p: __webpack_require__(114) });


/***/ }),
/* 199 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.22 Math.log2(x)
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  log2: function log2(x) {
    return Math.log(x) / Math.LN2;
  }
});


/***/ }),
/* 200 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.28 Math.sign(x)
var $export = __webpack_require__(0);

$export($export.S, 'Math', { sign: __webpack_require__(83) });


/***/ }),
/* 201 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.30 Math.sinh(x)
var $export = __webpack_require__(0);
var expm1 = __webpack_require__(84);
var exp = Math.exp;

// V8 near Chromium 38 has a problem with very small numbers
$export($export.S + $export.F * __webpack_require__(5)(function () {
  return !Math.sinh(-2e-17) != -2e-17;
}), 'Math', {
  sinh: function sinh(x) {
    return Math.abs(x = +x) < 1
      ? (expm1(x) - expm1(-x)) / 2
      : (exp(x - 1) - exp(-x - 1)) * (Math.E / 2);
  }
});


/***/ }),
/* 202 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.33 Math.tanh(x)
var $export = __webpack_require__(0);
var expm1 = __webpack_require__(84);
var exp = Math.exp;

$export($export.S, 'Math', {
  tanh: function tanh(x) {
    var a = expm1(x = +x);
    var b = expm1(-x);
    return a == Infinity ? 1 : b == Infinity ? -1 : (a - b) / (exp(x) + exp(-x));
  }
});


/***/ }),
/* 203 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.34 Math.trunc(x)
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  trunc: function trunc(it) {
    return (it > 0 ? Math.floor : Math.ceil)(it);
  }
});


/***/ }),
/* 204 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var toAbsoluteIndex = __webpack_require__(41);
var fromCharCode = String.fromCharCode;
var $fromCodePoint = String.fromCodePoint;

// length should be 1, old FF problem
$export($export.S + $export.F * (!!$fromCodePoint && $fromCodePoint.length != 1), 'String', {
  // 21.1.2.2 String.fromCodePoint(...codePoints)
  fromCodePoint: function fromCodePoint(x) { // eslint-disable-line no-unused-vars
    var res = [];
    var aLen = arguments.length;
    var i = 0;
    var code;
    while (aLen > i) {
      code = +arguments[i++];
      if (toAbsoluteIndex(code, 0x10ffff) !== code) throw RangeError(code + ' is not a valid code point');
      res.push(code < 0x10000
        ? fromCharCode(code)
        : fromCharCode(((code -= 0x10000) >> 10) + 0xd800, code % 0x400 + 0xdc00)
      );
    } return res.join('');
  }
});


/***/ }),
/* 205 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var toIObject = __webpack_require__(20);
var toLength = __webpack_require__(11);

$export($export.S, 'String', {
  // 21.1.2.4 String.raw(callSite, ...substitutions)
  raw: function raw(callSite) {
    var tpl = toIObject(callSite.raw);
    var len = toLength(tpl.length);
    var aLen = arguments.length;
    var res = [];
    var i = 0;
    while (len > i) {
      res.push(String(tpl[i++]));
      if (i < aLen) res.push(String(arguments[i]));
    } return res.join('');
  }
});


/***/ }),
/* 206 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 21.1.3.25 String.prototype.trim()
__webpack_require__(50)('trim', function ($trim) {
  return function trim() {
    return $trim(this, 3);
  };
});


/***/ }),
/* 207 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $at = __webpack_require__(85)(true);

// 21.1.3.27 String.prototype[@@iterator]()
__webpack_require__(86)(String, 'String', function (iterated) {
  this._t = String(iterated); // target
  this._i = 0;                // next index
// 21.1.5.2.1 %StringIteratorPrototype%.next()
}, function () {
  var O = this._t;
  var index = this._i;
  var point;
  if (index >= O.length) return { value: undefined, done: true };
  point = $at(O, index);
  this._i += point.length;
  return { value: point, done: false };
});


/***/ }),
/* 208 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $at = __webpack_require__(85)(false);
$export($export.P, 'String', {
  // 21.1.3.3 String.prototype.codePointAt(pos)
  codePointAt: function codePointAt(pos) {
    return $at(this, pos);
  }
});


/***/ }),
/* 209 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// 21.1.3.6 String.prototype.endsWith(searchString [, endPosition])

var $export = __webpack_require__(0);
var toLength = __webpack_require__(11);
var context = __webpack_require__(88);
var ENDS_WITH = 'endsWith';
var $endsWith = ''[ENDS_WITH];

$export($export.P + $export.F * __webpack_require__(89)(ENDS_WITH), 'String', {
  endsWith: function endsWith(searchString /* , endPosition = @length */) {
    var that = context(this, searchString, ENDS_WITH);
    var endPosition = arguments.length > 1 ? arguments[1] : undefined;
    var len = toLength(that.length);
    var end = endPosition === undefined ? len : Math.min(toLength(endPosition), len);
    var search = String(searchString);
    return $endsWith
      ? $endsWith.call(that, search, end)
      : that.slice(end - search.length, end) === search;
  }
});


/***/ }),
/* 210 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// 21.1.3.7 String.prototype.includes(searchString, position = 0)

var $export = __webpack_require__(0);
var context = __webpack_require__(88);
var INCLUDES = 'includes';

$export($export.P + $export.F * __webpack_require__(89)(INCLUDES), 'String', {
  includes: function includes(searchString /* , position = 0 */) {
    return !!~context(this, searchString, INCLUDES)
      .indexOf(searchString, arguments.length > 1 ? arguments[1] : undefined);
  }
});


/***/ }),
/* 211 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);

$export($export.P, 'String', {
  // 21.1.3.13 String.prototype.repeat(count)
  repeat: __webpack_require__(82)
});


/***/ }),
/* 212 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// 21.1.3.18 String.prototype.startsWith(searchString [, position ])

var $export = __webpack_require__(0);
var toLength = __webpack_require__(11);
var context = __webpack_require__(88);
var STARTS_WITH = 'startsWith';
var $startsWith = ''[STARTS_WITH];

$export($export.P + $export.F * __webpack_require__(89)(STARTS_WITH), 'String', {
  startsWith: function startsWith(searchString /* , position = 0 */) {
    var that = context(this, searchString, STARTS_WITH);
    var index = toLength(Math.min(arguments.length > 1 ? arguments[1] : undefined, that.length));
    var search = String(searchString);
    return $startsWith
      ? $startsWith.call(that, search, index)
      : that.slice(index, index + search.length) === search;
  }
});


/***/ }),
/* 213 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.2 String.prototype.anchor(name)
__webpack_require__(19)('anchor', function (createHTML) {
  return function anchor(name) {
    return createHTML(this, 'a', 'name', name);
  };
});


/***/ }),
/* 214 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.3 String.prototype.big()
__webpack_require__(19)('big', function (createHTML) {
  return function big() {
    return createHTML(this, 'big', '', '');
  };
});


/***/ }),
/* 215 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.4 String.prototype.blink()
__webpack_require__(19)('blink', function (createHTML) {
  return function blink() {
    return createHTML(this, 'blink', '', '');
  };
});


/***/ }),
/* 216 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.5 String.prototype.bold()
__webpack_require__(19)('bold', function (createHTML) {
  return function bold() {
    return createHTML(this, 'b', '', '');
  };
});


/***/ }),
/* 217 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.6 String.prototype.fixed()
__webpack_require__(19)('fixed', function (createHTML) {
  return function fixed() {
    return createHTML(this, 'tt', '', '');
  };
});


/***/ }),
/* 218 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.7 String.prototype.fontcolor(color)
__webpack_require__(19)('fontcolor', function (createHTML) {
  return function fontcolor(color) {
    return createHTML(this, 'font', 'color', color);
  };
});


/***/ }),
/* 219 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.8 String.prototype.fontsize(size)
__webpack_require__(19)('fontsize', function (createHTML) {
  return function fontsize(size) {
    return createHTML(this, 'font', 'size', size);
  };
});


/***/ }),
/* 220 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.9 String.prototype.italics()
__webpack_require__(19)('italics', function (createHTML) {
  return function italics() {
    return createHTML(this, 'i', '', '');
  };
});


/***/ }),
/* 221 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.10 String.prototype.link(url)
__webpack_require__(19)('link', function (createHTML) {
  return function link(url) {
    return createHTML(this, 'a', 'href', url);
  };
});


/***/ }),
/* 222 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.11 String.prototype.small()
__webpack_require__(19)('small', function (createHTML) {
  return function small() {
    return createHTML(this, 'small', '', '');
  };
});


/***/ }),
/* 223 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.12 String.prototype.strike()
__webpack_require__(19)('strike', function (createHTML) {
  return function strike() {
    return createHTML(this, 'strike', '', '');
  };
});


/***/ }),
/* 224 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.13 String.prototype.sub()
__webpack_require__(19)('sub', function (createHTML) {
  return function sub() {
    return createHTML(this, 'sub', '', '');
  };
});


/***/ }),
/* 225 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.14 String.prototype.sup()
__webpack_require__(19)('sup', function (createHTML) {
  return function sup() {
    return createHTML(this, 'sup', '', '');
  };
});


/***/ }),
/* 226 */
/***/ (function(module, exports, __webpack_require__) {

// 20.3.3.1 / 15.9.4.4 Date.now()
var $export = __webpack_require__(0);

$export($export.S, 'Date', { now: function () { return new Date().getTime(); } });


/***/ }),
/* 227 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var toObject = __webpack_require__(12);
var toPrimitive = __webpack_require__(27);

$export($export.P + $export.F * __webpack_require__(5)(function () {
  return new Date(NaN).toJSON() !== null
    || Date.prototype.toJSON.call({ toISOString: function () { return 1; } }) !== 1;
}), 'Date', {
  // eslint-disable-next-line no-unused-vars
  toJSON: function toJSON(key) {
    var O = toObject(this);
    var pv = toPrimitive(O);
    return typeof pv == 'number' && !isFinite(pv) ? null : O.toISOString();
  }
});


/***/ }),
/* 228 */
/***/ (function(module, exports, __webpack_require__) {

// 20.3.4.36 / 15.9.5.43 Date.prototype.toISOString()
var $export = __webpack_require__(0);
var toISOString = __webpack_require__(229);

// PhantomJS / old WebKit has a broken implementations
$export($export.P + $export.F * (Date.prototype.toISOString !== toISOString), 'Date', {
  toISOString: toISOString
});


/***/ }),
/* 229 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 20.3.4.36 / 15.9.5.43 Date.prototype.toISOString()
var fails = __webpack_require__(5);
var getTime = Date.prototype.getTime;
var $toISOString = Date.prototype.toISOString;

var lz = function (num) {
  return num > 9 ? num : '0' + num;
};

// PhantomJS / old WebKit has a broken implementations
module.exports = (fails(function () {
  return $toISOString.call(new Date(-5e13 - 1)) != '0385-07-25T07:06:39.999Z';
}) || !fails(function () {
  $toISOString.call(new Date(NaN));
})) ? function toISOString() {
  if (!isFinite(getTime.call(this))) throw RangeError('Invalid time value');
  var d = this;
  var y = d.getUTCFullYear();
  var m = d.getUTCMilliseconds();
  var s = y < 0 ? '-' : y > 9999 ? '+' : '';
  return s + ('00000' + Math.abs(y)).slice(s ? -6 : -4) +
    '-' + lz(d.getUTCMonth() + 1) + '-' + lz(d.getUTCDate()) +
    'T' + lz(d.getUTCHours()) + ':' + lz(d.getUTCMinutes()) +
    ':' + lz(d.getUTCSeconds()) + '.' + (m > 99 ? m : '0' + lz(m)) + 'Z';
} : $toISOString;


/***/ }),
/* 230 */
/***/ (function(module, exports, __webpack_require__) {

var DateProto = Date.prototype;
var INVALID_DATE = 'Invalid Date';
var TO_STRING = 'toString';
var $toString = DateProto[TO_STRING];
var getTime = DateProto.getTime;
if (new Date(NaN) + '' != INVALID_DATE) {
  __webpack_require__(18)(DateProto, TO_STRING, function toString() {
    var value = getTime.call(this);
    // eslint-disable-next-line no-self-compare
    return value === value ? $toString.call(this) : INVALID_DATE;
  });
}


/***/ }),
/* 231 */
/***/ (function(module, exports, __webpack_require__) {

var TO_PRIMITIVE = __webpack_require__(8)('toPrimitive');
var proto = Date.prototype;

if (!(TO_PRIMITIVE in proto)) __webpack_require__(17)(proto, TO_PRIMITIVE, __webpack_require__(232));


/***/ }),
/* 232 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var anObject = __webpack_require__(3);
var toPrimitive = __webpack_require__(27);
var NUMBER = 'number';

module.exports = function (hint) {
  if (hint !== 'string' && hint !== NUMBER && hint !== 'default') throw TypeError('Incorrect hint');
  return toPrimitive(anObject(this), hint != NUMBER);
};


/***/ }),
/* 233 */
/***/ (function(module, exports, __webpack_require__) {

// 22.1.2.2 / 15.4.3.2 Array.isArray(arg)
var $export = __webpack_require__(0);

$export($export.S, 'Array', { isArray: __webpack_require__(59) });


/***/ }),
/* 234 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var ctx = __webpack_require__(23);
var $export = __webpack_require__(0);
var toObject = __webpack_require__(12);
var call = __webpack_require__(116);
var isArrayIter = __webpack_require__(90);
var toLength = __webpack_require__(11);
var createProperty = __webpack_require__(91);
var getIterFn = __webpack_require__(92);

$export($export.S + $export.F * !__webpack_require__(61)(function (iter) { Array.from(iter); }), 'Array', {
  // 22.1.2.1 Array.from(arrayLike, mapfn = undefined, thisArg = undefined)
  from: function from(arrayLike /* , mapfn = undefined, thisArg = undefined */) {
    var O = toObject(arrayLike);
    var C = typeof this == 'function' ? this : Array;
    var aLen = arguments.length;
    var mapfn = aLen > 1 ? arguments[1] : undefined;
    var mapping = mapfn !== undefined;
    var index = 0;
    var iterFn = getIterFn(O);
    var length, result, step, iterator;
    if (mapping) mapfn = ctx(mapfn, aLen > 2 ? arguments[2] : undefined, 2);
    // if object isn't iterable or it's array with default iterator - use simple case
    if (iterFn != undefined && !(C == Array && isArrayIter(iterFn))) {
      for (iterator = iterFn.call(O), result = new C(); !(step = iterator.next()).done; index++) {
        createProperty(result, index, mapping ? call(iterator, mapfn, [step.value, index], true) : step.value);
      }
    } else {
      length = toLength(O.length);
      for (result = new C(length); length > index; index++) {
        createProperty(result, index, mapping ? mapfn(O[index], index) : O[index]);
      }
    }
    result.length = index;
    return result;
  }
});


/***/ }),
/* 235 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var createProperty = __webpack_require__(91);

// WebKit Array.of isn't generic
$export($export.S + $export.F * __webpack_require__(5)(function () {
  function F() { /* empty */ }
  return !(Array.of.call(F) instanceof F);
}), 'Array', {
  // 22.1.2.3 Array.of( ...items)
  of: function of(/* ...args */) {
    var index = 0;
    var aLen = arguments.length;
    var result = new (typeof this == 'function' ? this : Array)(aLen);
    while (aLen > index) createProperty(result, index, arguments[index++]);
    result.length = aLen;
    return result;
  }
});


/***/ }),
/* 236 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 22.1.3.13 Array.prototype.join(separator)
var $export = __webpack_require__(0);
var toIObject = __webpack_require__(20);
var arrayJoin = [].join;

// fallback for not array-like strings
$export($export.P + $export.F * (__webpack_require__(53) != Object || !__webpack_require__(25)(arrayJoin)), 'Array', {
  join: function join(separator) {
    return arrayJoin.call(toIObject(this), separator === undefined ? ',' : separator);
  }
});


/***/ }),
/* 237 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var html = __webpack_require__(78);
var cof = __webpack_require__(24);
var toAbsoluteIndex = __webpack_require__(41);
var toLength = __webpack_require__(11);
var arraySlice = [].slice;

// fallback for not array-like ES3 strings and DOM objects
$export($export.P + $export.F * __webpack_require__(5)(function () {
  if (html) arraySlice.call(html);
}), 'Array', {
  slice: function slice(begin, end) {
    var len = toLength(this.length);
    var klass = cof(this);
    end = end === undefined ? len : end;
    if (klass == 'Array') return arraySlice.call(this, begin, end);
    var start = toAbsoluteIndex(begin, len);
    var upTo = toAbsoluteIndex(end, len);
    var size = toLength(upTo - start);
    var cloned = Array(size);
    var i = 0;
    for (; i < size; i++) cloned[i] = klass == 'String'
      ? this.charAt(start + i)
      : this[start + i];
    return cloned;
  }
});


/***/ }),
/* 238 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var aFunction = __webpack_require__(14);
var toObject = __webpack_require__(12);
var fails = __webpack_require__(5);
var $sort = [].sort;
var test = [1, 2, 3];

$export($export.P + $export.F * (fails(function () {
  // IE8-
  test.sort(undefined);
}) || !fails(function () {
  // V8 bug
  test.sort(null);
  // Old WebKit
}) || !__webpack_require__(25)($sort)), 'Array', {
  // 22.1.3.25 Array.prototype.sort(comparefn)
  sort: function sort(comparefn) {
    return comparefn === undefined
      ? $sort.call(toObject(this))
      : $sort.call(toObject(this), aFunction(comparefn));
  }
});


/***/ }),
/* 239 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $forEach = __webpack_require__(31)(0);
var STRICT = __webpack_require__(25)([].forEach, true);

$export($export.P + $export.F * !STRICT, 'Array', {
  // 22.1.3.10 / 15.4.4.18 Array.prototype.forEach(callbackfn [, thisArg])
  forEach: function forEach(callbackfn /* , thisArg */) {
    return $forEach(this, callbackfn, arguments[1]);
  }
});


/***/ }),
/* 240 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(7);
var isArray = __webpack_require__(59);
var SPECIES = __webpack_require__(8)('species');

module.exports = function (original) {
  var C;
  if (isArray(original)) {
    C = original.constructor;
    // cross-realm fallback
    if (typeof C == 'function' && (C === Array || isArray(C.prototype))) C = undefined;
    if (isObject(C)) {
      C = C[SPECIES];
      if (C === null) C = undefined;
    }
  } return C === undefined ? Array : C;
};


/***/ }),
/* 241 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $map = __webpack_require__(31)(1);

$export($export.P + $export.F * !__webpack_require__(25)([].map, true), 'Array', {
  // 22.1.3.15 / 15.4.4.19 Array.prototype.map(callbackfn [, thisArg])
  map: function map(callbackfn /* , thisArg */) {
    return $map(this, callbackfn, arguments[1]);
  }
});


/***/ }),
/* 242 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $filter = __webpack_require__(31)(2);

$export($export.P + $export.F * !__webpack_require__(25)([].filter, true), 'Array', {
  // 22.1.3.7 / 15.4.4.20 Array.prototype.filter(callbackfn [, thisArg])
  filter: function filter(callbackfn /* , thisArg */) {
    return $filter(this, callbackfn, arguments[1]);
  }
});


/***/ }),
/* 243 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $some = __webpack_require__(31)(3);

$export($export.P + $export.F * !__webpack_require__(25)([].some, true), 'Array', {
  // 22.1.3.23 / 15.4.4.17 Array.prototype.some(callbackfn [, thisArg])
  some: function some(callbackfn /* , thisArg */) {
    return $some(this, callbackfn, arguments[1]);
  }
});


/***/ }),
/* 244 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $every = __webpack_require__(31)(4);

$export($export.P + $export.F * !__webpack_require__(25)([].every, true), 'Array', {
  // 22.1.3.5 / 15.4.4.16 Array.prototype.every(callbackfn [, thisArg])
  every: function every(callbackfn /* , thisArg */) {
    return $every(this, callbackfn, arguments[1]);
  }
});


/***/ }),
/* 245 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $reduce = __webpack_require__(117);

$export($export.P + $export.F * !__webpack_require__(25)([].reduce, true), 'Array', {
  // 22.1.3.18 / 15.4.4.21 Array.prototype.reduce(callbackfn [, initialValue])
  reduce: function reduce(callbackfn /* , initialValue */) {
    return $reduce(this, callbackfn, arguments.length, arguments[1], false);
  }
});


/***/ }),
/* 246 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $reduce = __webpack_require__(117);

$export($export.P + $export.F * !__webpack_require__(25)([].reduceRight, true), 'Array', {
  // 22.1.3.19 / 15.4.4.22 Array.prototype.reduceRight(callbackfn [, initialValue])
  reduceRight: function reduceRight(callbackfn /* , initialValue */) {
    return $reduce(this, callbackfn, arguments.length, arguments[1], true);
  }
});


/***/ }),
/* 247 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $indexOf = __webpack_require__(57)(false);
var $native = [].indexOf;
var NEGATIVE_ZERO = !!$native && 1 / [1].indexOf(1, -0) < 0;

$export($export.P + $export.F * (NEGATIVE_ZERO || !__webpack_require__(25)($native)), 'Array', {
  // 22.1.3.11 / 15.4.4.14 Array.prototype.indexOf(searchElement [, fromIndex])
  indexOf: function indexOf(searchElement /* , fromIndex = 0 */) {
    return NEGATIVE_ZERO
      // convert -0 to +0
      ? $native.apply(this, arguments) || 0
      : $indexOf(this, searchElement, arguments[1]);
  }
});


/***/ }),
/* 248 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var toIObject = __webpack_require__(20);
var toInteger = __webpack_require__(29);
var toLength = __webpack_require__(11);
var $native = [].lastIndexOf;
var NEGATIVE_ZERO = !!$native && 1 / [1].lastIndexOf(1, -0) < 0;

$export($export.P + $export.F * (NEGATIVE_ZERO || !__webpack_require__(25)($native)), 'Array', {
  // 22.1.3.14 / 15.4.4.15 Array.prototype.lastIndexOf(searchElement [, fromIndex])
  lastIndexOf: function lastIndexOf(searchElement /* , fromIndex = @[*-1] */) {
    // convert -0 to +0
    if (NEGATIVE_ZERO) return $native.apply(this, arguments) || 0;
    var O = toIObject(this);
    var length = toLength(O.length);
    var index = length - 1;
    if (arguments.length > 1) index = Math.min(index, toInteger(arguments[1]));
    if (index < 0) index = length + index;
    for (;index >= 0; index--) if (index in O) if (O[index] === searchElement) return index || 0;
    return -1;
  }
});


/***/ }),
/* 249 */
/***/ (function(module, exports, __webpack_require__) {

// 22.1.3.3 Array.prototype.copyWithin(target, start, end = this.length)
var $export = __webpack_require__(0);

$export($export.P, 'Array', { copyWithin: __webpack_require__(118) });

__webpack_require__(36)('copyWithin');


/***/ }),
/* 250 */
/***/ (function(module, exports, __webpack_require__) {

// 22.1.3.6 Array.prototype.fill(value, start = 0, end = this.length)
var $export = __webpack_require__(0);

$export($export.P, 'Array', { fill: __webpack_require__(94) });

__webpack_require__(36)('fill');


/***/ }),
/* 251 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 22.1.3.8 Array.prototype.find(predicate, thisArg = undefined)
var $export = __webpack_require__(0);
var $find = __webpack_require__(31)(5);
var KEY = 'find';
var forced = true;
// Shouldn't skip holes
if (KEY in []) Array(1)[KEY](function () { forced = false; });
$export($export.P + $export.F * forced, 'Array', {
  find: function find(callbackfn /* , that = undefined */) {
    return $find(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});
__webpack_require__(36)(KEY);


/***/ }),
/* 252 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 22.1.3.9 Array.prototype.findIndex(predicate, thisArg = undefined)
var $export = __webpack_require__(0);
var $find = __webpack_require__(31)(6);
var KEY = 'findIndex';
var forced = true;
// Shouldn't skip holes
if (KEY in []) Array(1)[KEY](function () { forced = false; });
$export($export.P + $export.F * forced, 'Array', {
  findIndex: function findIndex(callbackfn /* , that = undefined */) {
    return $find(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});
__webpack_require__(36)(KEY);


/***/ }),
/* 253 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(44)('Array');


/***/ }),
/* 254 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(4);
var inheritIfRequired = __webpack_require__(81);
var dP = __webpack_require__(10).f;
var gOPN = __webpack_require__(43).f;
var isRegExp = __webpack_require__(60);
var $flags = __webpack_require__(62);
var $RegExp = global.RegExp;
var Base = $RegExp;
var proto = $RegExp.prototype;
var re1 = /a/g;
var re2 = /a/g;
// "new" creates a new object, old webkit buggy here
var CORRECT_NEW = new $RegExp(re1) !== re1;

if (__webpack_require__(9) && (!CORRECT_NEW || __webpack_require__(5)(function () {
  re2[__webpack_require__(8)('match')] = false;
  // RegExp constructor can alter flags and IsRegExp works correct with @@match
  return $RegExp(re1) != re1 || $RegExp(re2) == re2 || $RegExp(re1, 'i') != '/a/i';
}))) {
  $RegExp = function RegExp(p, f) {
    var tiRE = this instanceof $RegExp;
    var piRE = isRegExp(p);
    var fiU = f === undefined;
    return !tiRE && piRE && p.constructor === $RegExp && fiU ? p
      : inheritIfRequired(CORRECT_NEW
        ? new Base(piRE && !fiU ? p.source : p, f)
        : Base((piRE = p instanceof $RegExp) ? p.source : p, piRE && fiU ? $flags.call(p) : f)
      , tiRE ? this : proto, $RegExp);
  };
  var proxy = function (key) {
    key in $RegExp || dP($RegExp, key, {
      configurable: true,
      get: function () { return Base[key]; },
      set: function (it) { Base[key] = it; }
    });
  };
  for (var keys = gOPN(Base), i = 0; keys.length > i;) proxy(keys[i++]);
  proto.constructor = $RegExp;
  $RegExp.prototype = proto;
  __webpack_require__(18)(global, 'RegExp', $RegExp);
}

__webpack_require__(44)('RegExp');


/***/ }),
/* 255 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

__webpack_require__(120);
var anObject = __webpack_require__(3);
var $flags = __webpack_require__(62);
var DESCRIPTORS = __webpack_require__(9);
var TO_STRING = 'toString';
var $toString = /./[TO_STRING];

var define = function (fn) {
  __webpack_require__(18)(RegExp.prototype, TO_STRING, fn, true);
};

// 21.2.5.14 RegExp.prototype.toString()
if (__webpack_require__(5)(function () { return $toString.call({ source: 'a', flags: 'b' }) != '/a/b'; })) {
  define(function toString() {
    var R = anObject(this);
    return '/'.concat(R.source, '/',
      'flags' in R ? R.flags : !DESCRIPTORS && R instanceof RegExp ? $flags.call(R) : undefined);
  });
// FF44- RegExp#toString has a wrong name
} else if ($toString.name != TO_STRING) {
  define(function toString() {
    return $toString.call(this);
  });
}


/***/ }),
/* 256 */
/***/ (function(module, exports, __webpack_require__) {

// @@match logic
__webpack_require__(63)('match', 1, function (defined, MATCH, $match) {
  // 21.1.3.11 String.prototype.match(regexp)
  return [function match(regexp) {
    'use strict';
    var O = defined(this);
    var fn = regexp == undefined ? undefined : regexp[MATCH];
    return fn !== undefined ? fn.call(regexp, O) : new RegExp(regexp)[MATCH](String(O));
  }, $match];
});


/***/ }),
/* 257 */
/***/ (function(module, exports, __webpack_require__) {

// @@replace logic
__webpack_require__(63)('replace', 2, function (defined, REPLACE, $replace) {
  // 21.1.3.14 String.prototype.replace(searchValue, replaceValue)
  return [function replace(searchValue, replaceValue) {
    'use strict';
    var O = defined(this);
    var fn = searchValue == undefined ? undefined : searchValue[REPLACE];
    return fn !== undefined
      ? fn.call(searchValue, O, replaceValue)
      : $replace.call(String(O), searchValue, replaceValue);
  }, $replace];
});


/***/ }),
/* 258 */
/***/ (function(module, exports, __webpack_require__) {

// @@search logic
__webpack_require__(63)('search', 1, function (defined, SEARCH, $search) {
  // 21.1.3.15 String.prototype.search(regexp)
  return [function search(regexp) {
    'use strict';
    var O = defined(this);
    var fn = regexp == undefined ? undefined : regexp[SEARCH];
    return fn !== undefined ? fn.call(regexp, O) : new RegExp(regexp)[SEARCH](String(O));
  }, $search];
});


/***/ }),
/* 259 */
/***/ (function(module, exports, __webpack_require__) {

// @@split logic
__webpack_require__(63)('split', 2, function (defined, SPLIT, $split) {
  'use strict';
  var isRegExp = __webpack_require__(60);
  var _split = $split;
  var $push = [].push;
  var $SPLIT = 'split';
  var LENGTH = 'length';
  var LAST_INDEX = 'lastIndex';
  if (
    'abbc'[$SPLIT](/(b)*/)[1] == 'c' ||
    'test'[$SPLIT](/(?:)/, -1)[LENGTH] != 4 ||
    'ab'[$SPLIT](/(?:ab)*/)[LENGTH] != 2 ||
    '.'[$SPLIT](/(.?)(.?)/)[LENGTH] != 4 ||
    '.'[$SPLIT](/()()/)[LENGTH] > 1 ||
    ''[$SPLIT](/.?/)[LENGTH]
  ) {
    var NPCG = /()??/.exec('')[1] === undefined; // nonparticipating capturing group
    // based on es5-shim implementation, need to rework it
    $split = function (separator, limit) {
      var string = String(this);
      if (separator === undefined && limit === 0) return [];
      // If `separator` is not a regex, use native split
      if (!isRegExp(separator)) return _split.call(string, separator, limit);
      var output = [];
      var flags = (separator.ignoreCase ? 'i' : '') +
                  (separator.multiline ? 'm' : '') +
                  (separator.unicode ? 'u' : '') +
                  (separator.sticky ? 'y' : '');
      var lastLastIndex = 0;
      var splitLimit = limit === undefined ? 4294967295 : limit >>> 0;
      // Make `global` and avoid `lastIndex` issues by working with a copy
      var separatorCopy = new RegExp(separator.source, flags + 'g');
      var separator2, match, lastIndex, lastLength, i;
      // Doesn't need flags gy, but they don't hurt
      if (!NPCG) separator2 = new RegExp('^' + separatorCopy.source + '$(?!\\s)', flags);
      while (match = separatorCopy.exec(string)) {
        // `separatorCopy.lastIndex` is not reliable cross-browser
        lastIndex = match.index + match[0][LENGTH];
        if (lastIndex > lastLastIndex) {
          output.push(string.slice(lastLastIndex, match.index));
          // Fix browsers whose `exec` methods don't consistently return `undefined` for NPCG
          // eslint-disable-next-line no-loop-func
          if (!NPCG && match[LENGTH] > 1) match[0].replace(separator2, function () {
            for (i = 1; i < arguments[LENGTH] - 2; i++) if (arguments[i] === undefined) match[i] = undefined;
          });
          if (match[LENGTH] > 1 && match.index < string[LENGTH]) $push.apply(output, match.slice(1));
          lastLength = match[0][LENGTH];
          lastLastIndex = lastIndex;
          if (output[LENGTH] >= splitLimit) break;
        }
        if (separatorCopy[LAST_INDEX] === match.index) separatorCopy[LAST_INDEX]++; // Avoid an infinite loop
      }
      if (lastLastIndex === string[LENGTH]) {
        if (lastLength || !separatorCopy.test('')) output.push('');
      } else output.push(string.slice(lastLastIndex));
      return output[LENGTH] > splitLimit ? output.slice(0, splitLimit) : output;
    };
  // Chakra, V8
  } else if ('0'[$SPLIT](undefined, 0)[LENGTH]) {
    $split = function (separator, limit) {
      return separator === undefined && limit === 0 ? [] : _split.call(this, separator, limit);
    };
  }
  // 21.1.3.17 String.prototype.split(separator, limit)
  return [function split(separator, limit) {
    var O = defined(this);
    var fn = separator == undefined ? undefined : separator[SPLIT];
    return fn !== undefined ? fn.call(separator, O, limit) : $split.call(String(O), separator, limit);
  }, $split];
});


/***/ }),
/* 260 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var LIBRARY = __webpack_require__(39);
var global = __webpack_require__(4);
var ctx = __webpack_require__(23);
var classof = __webpack_require__(55);
var $export = __webpack_require__(0);
var isObject = __webpack_require__(7);
var aFunction = __webpack_require__(14);
var anInstance = __webpack_require__(45);
var forOf = __webpack_require__(46);
var speciesConstructor = __webpack_require__(64);
var task = __webpack_require__(96).set;
var microtask = __webpack_require__(97)();
var newPromiseCapabilityModule = __webpack_require__(98);
var perform = __webpack_require__(121);
var promiseResolve = __webpack_require__(122);
var PROMISE = 'Promise';
var TypeError = global.TypeError;
var process = global.process;
var $Promise = global[PROMISE];
var isNode = classof(process) == 'process';
var empty = function () { /* empty */ };
var Internal, newGenericPromiseCapability, OwnPromiseCapability, Wrapper;
var newPromiseCapability = newGenericPromiseCapability = newPromiseCapabilityModule.f;

var USE_NATIVE = !!function () {
  try {
    // correct subclassing with @@species support
    var promise = $Promise.resolve(1);
    var FakePromise = (promise.constructor = {})[__webpack_require__(8)('species')] = function (exec) {
      exec(empty, empty);
    };
    // unhandled rejections tracking support, NodeJS Promise without it fails @@species test
    return (isNode || typeof PromiseRejectionEvent == 'function') && promise.then(empty) instanceof FakePromise;
  } catch (e) { /* empty */ }
}();

// helpers
var isThenable = function (it) {
  var then;
  return isObject(it) && typeof (then = it.then) == 'function' ? then : false;
};
var notify = function (promise, isReject) {
  if (promise._n) return;
  promise._n = true;
  var chain = promise._c;
  microtask(function () {
    var value = promise._v;
    var ok = promise._s == 1;
    var i = 0;
    var run = function (reaction) {
      var handler = ok ? reaction.ok : reaction.fail;
      var resolve = reaction.resolve;
      var reject = reaction.reject;
      var domain = reaction.domain;
      var result, then;
      try {
        if (handler) {
          if (!ok) {
            if (promise._h == 2) onHandleUnhandled(promise);
            promise._h = 1;
          }
          if (handler === true) result = value;
          else {
            if (domain) domain.enter();
            result = handler(value);
            if (domain) domain.exit();
          }
          if (result === reaction.promise) {
            reject(TypeError('Promise-chain cycle'));
          } else if (then = isThenable(result)) {
            then.call(result, resolve, reject);
          } else resolve(result);
        } else reject(value);
      } catch (e) {
        reject(e);
      }
    };
    while (chain.length > i) run(chain[i++]); // variable length - can't use forEach
    promise._c = [];
    promise._n = false;
    if (isReject && !promise._h) onUnhandled(promise);
  });
};
var onUnhandled = function (promise) {
  task.call(global, function () {
    var value = promise._v;
    var unhandled = isUnhandled(promise);
    var result, handler, console;
    if (unhandled) {
      result = perform(function () {
        if (isNode) {
          process.emit('unhandledRejection', value, promise);
        } else if (handler = global.onunhandledrejection) {
          handler({ promise: promise, reason: value });
        } else if ((console = global.console) && console.error) {
          console.error('Unhandled promise rejection', value);
        }
      });
      // Browsers should not trigger `rejectionHandled` event if it was handled here, NodeJS - should
      promise._h = isNode || isUnhandled(promise) ? 2 : 1;
    } promise._a = undefined;
    if (unhandled && result.e) throw result.v;
  });
};
var isUnhandled = function (promise) {
  if (promise._h == 1) return false;
  var chain = promise._a || promise._c;
  var i = 0;
  var reaction;
  while (chain.length > i) {
    reaction = chain[i++];
    if (reaction.fail || !isUnhandled(reaction.promise)) return false;
  } return true;
};
var onHandleUnhandled = function (promise) {
  task.call(global, function () {
    var handler;
    if (isNode) {
      process.emit('rejectionHandled', promise);
    } else if (handler = global.onrejectionhandled) {
      handler({ promise: promise, reason: promise._v });
    }
  });
};
var $reject = function (value) {
  var promise = this;
  if (promise._d) return;
  promise._d = true;
  promise = promise._w || promise; // unwrap
  promise._v = value;
  promise._s = 2;
  if (!promise._a) promise._a = promise._c.slice();
  notify(promise, true);
};
var $resolve = function (value) {
  var promise = this;
  var then;
  if (promise._d) return;
  promise._d = true;
  promise = promise._w || promise; // unwrap
  try {
    if (promise === value) throw TypeError("Promise can't be resolved itself");
    if (then = isThenable(value)) {
      microtask(function () {
        var wrapper = { _w: promise, _d: false }; // wrap
        try {
          then.call(value, ctx($resolve, wrapper, 1), ctx($reject, wrapper, 1));
        } catch (e) {
          $reject.call(wrapper, e);
        }
      });
    } else {
      promise._v = value;
      promise._s = 1;
      notify(promise, false);
    }
  } catch (e) {
    $reject.call({ _w: promise, _d: false }, e); // wrap
  }
};

// constructor polyfill
if (!USE_NATIVE) {
  // 25.4.3.1 Promise(executor)
  $Promise = function Promise(executor) {
    anInstance(this, $Promise, PROMISE, '_h');
    aFunction(executor);
    Internal.call(this);
    try {
      executor(ctx($resolve, this, 1), ctx($reject, this, 1));
    } catch (err) {
      $reject.call(this, err);
    }
  };
  // eslint-disable-next-line no-unused-vars
  Internal = function Promise(executor) {
    this._c = [];             // <- awaiting reactions
    this._a = undefined;      // <- checked in isUnhandled reactions
    this._s = 0;              // <- state
    this._d = false;          // <- done
    this._v = undefined;      // <- value
    this._h = 0;              // <- rejection state, 0 - default, 1 - handled, 2 - unhandled
    this._n = false;          // <- notify
  };
  Internal.prototype = __webpack_require__(47)($Promise.prototype, {
    // 25.4.5.3 Promise.prototype.then(onFulfilled, onRejected)
    then: function then(onFulfilled, onRejected) {
      var reaction = newPromiseCapability(speciesConstructor(this, $Promise));
      reaction.ok = typeof onFulfilled == 'function' ? onFulfilled : true;
      reaction.fail = typeof onRejected == 'function' && onRejected;
      reaction.domain = isNode ? process.domain : undefined;
      this._c.push(reaction);
      if (this._a) this._a.push(reaction);
      if (this._s) notify(this, false);
      return reaction.promise;
    },
    // 25.4.5.1 Promise.prototype.catch(onRejected)
    'catch': function (onRejected) {
      return this.then(undefined, onRejected);
    }
  });
  OwnPromiseCapability = function () {
    var promise = new Internal();
    this.promise = promise;
    this.resolve = ctx($resolve, promise, 1);
    this.reject = ctx($reject, promise, 1);
  };
  newPromiseCapabilityModule.f = newPromiseCapability = function (C) {
    return C === $Promise || C === Wrapper
      ? new OwnPromiseCapability(C)
      : newGenericPromiseCapability(C);
  };
}

$export($export.G + $export.W + $export.F * !USE_NATIVE, { Promise: $Promise });
__webpack_require__(49)($Promise, PROMISE);
__webpack_require__(44)(PROMISE);
Wrapper = __webpack_require__(26)[PROMISE];

// statics
$export($export.S + $export.F * !USE_NATIVE, PROMISE, {
  // 25.4.4.5 Promise.reject(r)
  reject: function reject(r) {
    var capability = newPromiseCapability(this);
    var $$reject = capability.reject;
    $$reject(r);
    return capability.promise;
  }
});
$export($export.S + $export.F * (LIBRARY || !USE_NATIVE), PROMISE, {
  // 25.4.4.6 Promise.resolve(x)
  resolve: function resolve(x) {
    return promiseResolve(LIBRARY && this === Wrapper ? $Promise : this, x);
  }
});
$export($export.S + $export.F * !(USE_NATIVE && __webpack_require__(61)(function (iter) {
  $Promise.all(iter)['catch'](empty);
})), PROMISE, {
  // 25.4.4.1 Promise.all(iterable)
  all: function all(iterable) {
    var C = this;
    var capability = newPromiseCapability(C);
    var resolve = capability.resolve;
    var reject = capability.reject;
    var result = perform(function () {
      var values = [];
      var index = 0;
      var remaining = 1;
      forOf(iterable, false, function (promise) {
        var $index = index++;
        var alreadyCalled = false;
        values.push(undefined);
        remaining++;
        C.resolve(promise).then(function (value) {
          if (alreadyCalled) return;
          alreadyCalled = true;
          values[$index] = value;
          --remaining || resolve(values);
        }, reject);
      });
      --remaining || resolve(values);
    });
    if (result.e) reject(result.v);
    return capability.promise;
  },
  // 25.4.4.4 Promise.race(iterable)
  race: function race(iterable) {
    var C = this;
    var capability = newPromiseCapability(C);
    var reject = capability.reject;
    var result = perform(function () {
      forOf(iterable, false, function (promise) {
        C.resolve(promise).then(capability.resolve, reject);
      });
    });
    if (result.e) reject(result.v);
    return capability.promise;
  }
});


/***/ }),
/* 261 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var weak = __webpack_require__(127);
var validate = __webpack_require__(52);
var WEAK_SET = 'WeakSet';

// 23.4 WeakSet Objects
__webpack_require__(65)(WEAK_SET, function (get) {
  return function WeakSet() { return get(this, arguments.length > 0 ? arguments[0] : undefined); };
}, {
  // 23.4.3.1 WeakSet.prototype.add(value)
  add: function add(value) {
    return weak.def(validate(this, WEAK_SET), value, true);
  }
}, weak, false, true);


/***/ }),
/* 262 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $typed = __webpack_require__(66);
var buffer = __webpack_require__(99);
var anObject = __webpack_require__(3);
var toAbsoluteIndex = __webpack_require__(41);
var toLength = __webpack_require__(11);
var isObject = __webpack_require__(7);
var ArrayBuffer = __webpack_require__(4).ArrayBuffer;
var speciesConstructor = __webpack_require__(64);
var $ArrayBuffer = buffer.ArrayBuffer;
var $DataView = buffer.DataView;
var $isView = $typed.ABV && ArrayBuffer.isView;
var $slice = $ArrayBuffer.prototype.slice;
var VIEW = $typed.VIEW;
var ARRAY_BUFFER = 'ArrayBuffer';

$export($export.G + $export.W + $export.F * (ArrayBuffer !== $ArrayBuffer), { ArrayBuffer: $ArrayBuffer });

$export($export.S + $export.F * !$typed.CONSTR, ARRAY_BUFFER, {
  // 24.1.3.1 ArrayBuffer.isView(arg)
  isView: function isView(it) {
    return $isView && $isView(it) || isObject(it) && VIEW in it;
  }
});

$export($export.P + $export.U + $export.F * __webpack_require__(5)(function () {
  return !new $ArrayBuffer(2).slice(1, undefined).byteLength;
}), ARRAY_BUFFER, {
  // 24.1.4.3 ArrayBuffer.prototype.slice(start, end)
  slice: function slice(start, end) {
    if ($slice !== undefined && end === undefined) return $slice.call(anObject(this), start); // FF fix
    var len = anObject(this).byteLength;
    var first = toAbsoluteIndex(start, len);
    var final = toAbsoluteIndex(end === undefined ? len : end, len);
    var result = new (speciesConstructor(this, $ArrayBuffer))(toLength(final - first));
    var viewS = new $DataView(this);
    var viewT = new $DataView(result);
    var index = 0;
    while (first < final) {
      viewT.setUint8(index++, viewS.getUint8(first++));
    } return result;
  }
});

__webpack_require__(44)(ARRAY_BUFFER);


/***/ }),
/* 263 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
$export($export.G + $export.W + $export.F * !__webpack_require__(66).ABV, {
  DataView: __webpack_require__(99).DataView
});


/***/ }),
/* 264 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(33)('Int8', 1, function (init) {
  return function Int8Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 265 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(33)('Uint8', 1, function (init) {
  return function Uint8Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 266 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(33)('Uint8', 1, function (init) {
  return function Uint8ClampedArray(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
}, true);


/***/ }),
/* 267 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(33)('Int16', 2, function (init) {
  return function Int16Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 268 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(33)('Uint16', 2, function (init) {
  return function Uint16Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 269 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(33)('Int32', 4, function (init) {
  return function Int32Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 270 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(33)('Uint32', 4, function (init) {
  return function Uint32Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 271 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(33)('Float32', 4, function (init) {
  return function Float32Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 272 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(33)('Float64', 8, function (init) {
  return function Float64Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 273 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.1 Reflect.apply(target, thisArgument, argumentsList)
var $export = __webpack_require__(0);
var aFunction = __webpack_require__(14);
var anObject = __webpack_require__(3);
var rApply = (__webpack_require__(4).Reflect || {}).apply;
var fApply = Function.apply;
// MS Edge argumentsList argument is optional
$export($export.S + $export.F * !__webpack_require__(5)(function () {
  rApply(function () { /* empty */ });
}), 'Reflect', {
  apply: function apply(target, thisArgument, argumentsList) {
    var T = aFunction(target);
    var L = anObject(argumentsList);
    return rApply ? rApply(T, thisArgument, L) : fApply.call(T, thisArgument, L);
  }
});


/***/ }),
/* 274 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.2 Reflect.construct(target, argumentsList [, newTarget])
var $export = __webpack_require__(0);
var create = __webpack_require__(42);
var aFunction = __webpack_require__(14);
var anObject = __webpack_require__(3);
var isObject = __webpack_require__(7);
var fails = __webpack_require__(5);
var bind = __webpack_require__(108);
var rConstruct = (__webpack_require__(4).Reflect || {}).construct;

// MS Edge supports only 2 arguments and argumentsList argument is optional
// FF Nightly sets third argument as `new.target`, but does not create `this` from it
var NEW_TARGET_BUG = fails(function () {
  function F() { /* empty */ }
  return !(rConstruct(function () { /* empty */ }, [], F) instanceof F);
});
var ARGS_BUG = !fails(function () {
  rConstruct(function () { /* empty */ });
});

$export($export.S + $export.F * (NEW_TARGET_BUG || ARGS_BUG), 'Reflect', {
  construct: function construct(Target, args /* , newTarget */) {
    aFunction(Target);
    anObject(args);
    var newTarget = arguments.length < 3 ? Target : aFunction(arguments[2]);
    if (ARGS_BUG && !NEW_TARGET_BUG) return rConstruct(Target, args, newTarget);
    if (Target == newTarget) {
      // w/o altered newTarget, optimization for 0-4 arguments
      switch (args.length) {
        case 0: return new Target();
        case 1: return new Target(args[0]);
        case 2: return new Target(args[0], args[1]);
        case 3: return new Target(args[0], args[1], args[2]);
        case 4: return new Target(args[0], args[1], args[2], args[3]);
      }
      // w/o altered newTarget, lot of arguments case
      var $args = [null];
      $args.push.apply($args, args);
      return new (bind.apply(Target, $args))();
    }
    // with altered newTarget, not support built-in constructors
    var proto = newTarget.prototype;
    var instance = create(isObject(proto) ? proto : Object.prototype);
    var result = Function.apply.call(Target, instance, args);
    return isObject(result) ? result : instance;
  }
});


/***/ }),
/* 275 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.3 Reflect.defineProperty(target, propertyKey, attributes)
var dP = __webpack_require__(10);
var $export = __webpack_require__(0);
var anObject = __webpack_require__(3);
var toPrimitive = __webpack_require__(27);

// MS Edge has broken Reflect.defineProperty - throwing instead of returning false
$export($export.S + $export.F * __webpack_require__(5)(function () {
  // eslint-disable-next-line no-undef
  Reflect.defineProperty(dP.f({}, 1, { value: 1 }), 1, { value: 2 });
}), 'Reflect', {
  defineProperty: function defineProperty(target, propertyKey, attributes) {
    anObject(target);
    propertyKey = toPrimitive(propertyKey, true);
    anObject(attributes);
    try {
      dP.f(target, propertyKey, attributes);
      return true;
    } catch (e) {
      return false;
    }
  }
});


/***/ }),
/* 276 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.4 Reflect.deleteProperty(target, propertyKey)
var $export = __webpack_require__(0);
var gOPD = __webpack_require__(21).f;
var anObject = __webpack_require__(3);

$export($export.S, 'Reflect', {
  deleteProperty: function deleteProperty(target, propertyKey) {
    var desc = gOPD(anObject(target), propertyKey);
    return desc && !desc.configurable ? false : delete target[propertyKey];
  }
});


/***/ }),
/* 277 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 26.1.5 Reflect.enumerate(target)
var $export = __webpack_require__(0);
var anObject = __webpack_require__(3);
var Enumerate = function (iterated) {
  this._t = anObject(iterated); // target
  this._i = 0;                  // next index
  var keys = this._k = [];      // keys
  var key;
  for (key in iterated) keys.push(key);
};
__webpack_require__(87)(Enumerate, 'Object', function () {
  var that = this;
  var keys = that._k;
  var key;
  do {
    if (that._i >= keys.length) return { value: undefined, done: true };
  } while (!((key = keys[that._i++]) in that._t));
  return { value: key, done: false };
});

$export($export.S, 'Reflect', {
  enumerate: function enumerate(target) {
    return new Enumerate(target);
  }
});


/***/ }),
/* 278 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.6 Reflect.get(target, propertyKey [, receiver])
var gOPD = __webpack_require__(21);
var getPrototypeOf = __webpack_require__(22);
var has = __webpack_require__(16);
var $export = __webpack_require__(0);
var isObject = __webpack_require__(7);
var anObject = __webpack_require__(3);

function get(target, propertyKey /* , receiver */) {
  var receiver = arguments.length < 3 ? target : arguments[2];
  var desc, proto;
  if (anObject(target) === receiver) return target[propertyKey];
  if (desc = gOPD.f(target, propertyKey)) return has(desc, 'value')
    ? desc.value
    : desc.get !== undefined
      ? desc.get.call(receiver)
      : undefined;
  if (isObject(proto = getPrototypeOf(target))) return get(proto, propertyKey, receiver);
}

$export($export.S, 'Reflect', { get: get });


/***/ }),
/* 279 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.7 Reflect.getOwnPropertyDescriptor(target, propertyKey)
var gOPD = __webpack_require__(21);
var $export = __webpack_require__(0);
var anObject = __webpack_require__(3);

$export($export.S, 'Reflect', {
  getOwnPropertyDescriptor: function getOwnPropertyDescriptor(target, propertyKey) {
    return gOPD.f(anObject(target), propertyKey);
  }
});


/***/ }),
/* 280 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.8 Reflect.getPrototypeOf(target)
var $export = __webpack_require__(0);
var getProto = __webpack_require__(22);
var anObject = __webpack_require__(3);

$export($export.S, 'Reflect', {
  getPrototypeOf: function getPrototypeOf(target) {
    return getProto(anObject(target));
  }
});


/***/ }),
/* 281 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.9 Reflect.has(target, propertyKey)
var $export = __webpack_require__(0);

$export($export.S, 'Reflect', {
  has: function has(target, propertyKey) {
    return propertyKey in target;
  }
});


/***/ }),
/* 282 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.10 Reflect.isExtensible(target)
var $export = __webpack_require__(0);
var anObject = __webpack_require__(3);
var $isExtensible = Object.isExtensible;

$export($export.S, 'Reflect', {
  isExtensible: function isExtensible(target) {
    anObject(target);
    return $isExtensible ? $isExtensible(target) : true;
  }
});


/***/ }),
/* 283 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.11 Reflect.ownKeys(target)
var $export = __webpack_require__(0);

$export($export.S, 'Reflect', { ownKeys: __webpack_require__(129) });


/***/ }),
/* 284 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.12 Reflect.preventExtensions(target)
var $export = __webpack_require__(0);
var anObject = __webpack_require__(3);
var $preventExtensions = Object.preventExtensions;

$export($export.S, 'Reflect', {
  preventExtensions: function preventExtensions(target) {
    anObject(target);
    try {
      if ($preventExtensions) $preventExtensions(target);
      return true;
    } catch (e) {
      return false;
    }
  }
});


/***/ }),
/* 285 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.13 Reflect.set(target, propertyKey, V [, receiver])
var dP = __webpack_require__(10);
var gOPD = __webpack_require__(21);
var getPrototypeOf = __webpack_require__(22);
var has = __webpack_require__(16);
var $export = __webpack_require__(0);
var createDesc = __webpack_require__(37);
var anObject = __webpack_require__(3);
var isObject = __webpack_require__(7);

function set(target, propertyKey, V /* , receiver */) {
  var receiver = arguments.length < 4 ? target : arguments[3];
  var ownDesc = gOPD.f(anObject(target), propertyKey);
  var existingDescriptor, proto;
  if (!ownDesc) {
    if (isObject(proto = getPrototypeOf(target))) {
      return set(proto, propertyKey, V, receiver);
    }
    ownDesc = createDesc(0);
  }
  if (has(ownDesc, 'value')) {
    if (ownDesc.writable === false || !isObject(receiver)) return false;
    existingDescriptor = gOPD.f(receiver, propertyKey) || createDesc(0);
    existingDescriptor.value = V;
    dP.f(receiver, propertyKey, existingDescriptor);
    return true;
  }
  return ownDesc.set === undefined ? false : (ownDesc.set.call(receiver, V), true);
}

$export($export.S, 'Reflect', { set: set });


/***/ }),
/* 286 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.14 Reflect.setPrototypeOf(target, proto)
var $export = __webpack_require__(0);
var setProto = __webpack_require__(79);

if (setProto) $export($export.S, 'Reflect', {
  setPrototypeOf: function setPrototypeOf(target, proto) {
    setProto.check(target, proto);
    try {
      setProto.set(target, proto);
      return true;
    } catch (e) {
      return false;
    }
  }
});


/***/ }),
/* 287 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/tc39/Array.prototype.includes
var $export = __webpack_require__(0);
var $includes = __webpack_require__(57)(true);

$export($export.P, 'Array', {
  includes: function includes(el /* , fromIndex = 0 */) {
    return $includes(this, el, arguments.length > 1 ? arguments[1] : undefined);
  }
});

__webpack_require__(36)('includes');


/***/ }),
/* 288 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://tc39.github.io/proposal-flatMap/#sec-Array.prototype.flatMap
var $export = __webpack_require__(0);
var flattenIntoArray = __webpack_require__(130);
var toObject = __webpack_require__(12);
var toLength = __webpack_require__(11);
var aFunction = __webpack_require__(14);
var arraySpeciesCreate = __webpack_require__(93);

$export($export.P, 'Array', {
  flatMap: function flatMap(callbackfn /* , thisArg */) {
    var O = toObject(this);
    var sourceLen, A;
    aFunction(callbackfn);
    sourceLen = toLength(O.length);
    A = arraySpeciesCreate(O, 0);
    flattenIntoArray(A, O, O, sourceLen, 0, 1, callbackfn, arguments[1]);
    return A;
  }
});

__webpack_require__(36)('flatMap');


/***/ }),
/* 289 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://tc39.github.io/proposal-flatMap/#sec-Array.prototype.flatten
var $export = __webpack_require__(0);
var flattenIntoArray = __webpack_require__(130);
var toObject = __webpack_require__(12);
var toLength = __webpack_require__(11);
var toInteger = __webpack_require__(29);
var arraySpeciesCreate = __webpack_require__(93);

$export($export.P, 'Array', {
  flatten: function flatten(/* depthArg = 1 */) {
    var depthArg = arguments[0];
    var O = toObject(this);
    var sourceLen = toLength(O.length);
    var A = arraySpeciesCreate(O, 0);
    flattenIntoArray(A, O, O, sourceLen, 0, depthArg === undefined ? 1 : toInteger(depthArg));
    return A;
  }
});

__webpack_require__(36)('flatten');


/***/ }),
/* 290 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/mathiasbynens/String.prototype.at
var $export = __webpack_require__(0);
var $at = __webpack_require__(85)(true);

$export($export.P, 'String', {
  at: function at(pos) {
    return $at(this, pos);
  }
});


/***/ }),
/* 291 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/tc39/proposal-string-pad-start-end
var $export = __webpack_require__(0);
var $pad = __webpack_require__(131);

$export($export.P, 'String', {
  padStart: function padStart(maxLength /* , fillString = ' ' */) {
    return $pad(this, maxLength, arguments.length > 1 ? arguments[1] : undefined, true);
  }
});


/***/ }),
/* 292 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/tc39/proposal-string-pad-start-end
var $export = __webpack_require__(0);
var $pad = __webpack_require__(131);

$export($export.P, 'String', {
  padEnd: function padEnd(maxLength /* , fillString = ' ' */) {
    return $pad(this, maxLength, arguments.length > 1 ? arguments[1] : undefined, false);
  }
});


/***/ }),
/* 293 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/sebmarkbage/ecmascript-string-left-right-trim
__webpack_require__(50)('trimLeft', function ($trim) {
  return function trimLeft() {
    return $trim(this, 1);
  };
}, 'trimStart');


/***/ }),
/* 294 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/sebmarkbage/ecmascript-string-left-right-trim
__webpack_require__(50)('trimRight', function ($trim) {
  return function trimRight() {
    return $trim(this, 2);
  };
}, 'trimEnd');


/***/ }),
/* 295 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://tc39.github.io/String.prototype.matchAll/
var $export = __webpack_require__(0);
var defined = __webpack_require__(28);
var toLength = __webpack_require__(11);
var isRegExp = __webpack_require__(60);
var getFlags = __webpack_require__(62);
var RegExpProto = RegExp.prototype;

var $RegExpStringIterator = function (regexp, string) {
  this._r = regexp;
  this._s = string;
};

__webpack_require__(87)($RegExpStringIterator, 'RegExp String', function next() {
  var match = this._r.exec(this._s);
  return { value: match, done: match === null };
});

$export($export.P, 'String', {
  matchAll: function matchAll(regexp) {
    defined(this);
    if (!isRegExp(regexp)) throw TypeError(regexp + ' is not a regexp!');
    var S = String(this);
    var flags = 'flags' in RegExpProto ? String(regexp.flags) : getFlags.call(regexp);
    var rx = new RegExp(regexp.source, ~flags.indexOf('g') ? flags : 'g' + flags);
    rx.lastIndex = toLength(regexp.lastIndex);
    return new $RegExpStringIterator(rx, S);
  }
});


/***/ }),
/* 296 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(75)('asyncIterator');


/***/ }),
/* 297 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(75)('observable');


/***/ }),
/* 298 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/tc39/proposal-object-getownpropertydescriptors
var $export = __webpack_require__(0);
var ownKeys = __webpack_require__(129);
var toIObject = __webpack_require__(20);
var gOPD = __webpack_require__(21);
var createProperty = __webpack_require__(91);

$export($export.S, 'Object', {
  getOwnPropertyDescriptors: function getOwnPropertyDescriptors(object) {
    var O = toIObject(object);
    var getDesc = gOPD.f;
    var keys = ownKeys(O);
    var result = {};
    var i = 0;
    var key, desc;
    while (keys.length > i) {
      desc = getDesc(O, key = keys[i++]);
      if (desc !== undefined) createProperty(result, key, desc);
    }
    return result;
  }
});


/***/ }),
/* 299 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/tc39/proposal-object-values-entries
var $export = __webpack_require__(0);
var $values = __webpack_require__(132)(false);

$export($export.S, 'Object', {
  values: function values(it) {
    return $values(it);
  }
});


/***/ }),
/* 300 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/tc39/proposal-object-values-entries
var $export = __webpack_require__(0);
var $entries = __webpack_require__(132)(true);

$export($export.S, 'Object', {
  entries: function entries(it) {
    return $entries(it);
  }
});


/***/ }),
/* 301 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var toObject = __webpack_require__(12);
var aFunction = __webpack_require__(14);
var $defineProperty = __webpack_require__(10);

// B.2.2.2 Object.prototype.__defineGetter__(P, getter)
__webpack_require__(9) && $export($export.P + __webpack_require__(67), 'Object', {
  __defineGetter__: function __defineGetter__(P, getter) {
    $defineProperty.f(toObject(this), P, { get: aFunction(getter), enumerable: true, configurable: true });
  }
});


/***/ }),
/* 302 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var toObject = __webpack_require__(12);
var aFunction = __webpack_require__(14);
var $defineProperty = __webpack_require__(10);

// B.2.2.3 Object.prototype.__defineSetter__(P, setter)
__webpack_require__(9) && $export($export.P + __webpack_require__(67), 'Object', {
  __defineSetter__: function __defineSetter__(P, setter) {
    $defineProperty.f(toObject(this), P, { set: aFunction(setter), enumerable: true, configurable: true });
  }
});


/***/ }),
/* 303 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var toObject = __webpack_require__(12);
var toPrimitive = __webpack_require__(27);
var getPrototypeOf = __webpack_require__(22);
var getOwnPropertyDescriptor = __webpack_require__(21).f;

// B.2.2.4 Object.prototype.__lookupGetter__(P)
__webpack_require__(9) && $export($export.P + __webpack_require__(67), 'Object', {
  __lookupGetter__: function __lookupGetter__(P) {
    var O = toObject(this);
    var K = toPrimitive(P, true);
    var D;
    do {
      if (D = getOwnPropertyDescriptor(O, K)) return D.get;
    } while (O = getPrototypeOf(O));
  }
});


/***/ }),
/* 304 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var toObject = __webpack_require__(12);
var toPrimitive = __webpack_require__(27);
var getPrototypeOf = __webpack_require__(22);
var getOwnPropertyDescriptor = __webpack_require__(21).f;

// B.2.2.5 Object.prototype.__lookupSetter__(P)
__webpack_require__(9) && $export($export.P + __webpack_require__(67), 'Object', {
  __lookupSetter__: function __lookupSetter__(P) {
    var O = toObject(this);
    var K = toPrimitive(P, true);
    var D;
    do {
      if (D = getOwnPropertyDescriptor(O, K)) return D.set;
    } while (O = getPrototypeOf(O));
  }
});


/***/ }),
/* 305 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/DavidBruant/Map-Set.prototype.toJSON
var $export = __webpack_require__(0);

$export($export.P + $export.R, 'Map', { toJSON: __webpack_require__(133)('Map') });


/***/ }),
/* 306 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/DavidBruant/Map-Set.prototype.toJSON
var $export = __webpack_require__(0);

$export($export.P + $export.R, 'Set', { toJSON: __webpack_require__(133)('Set') });


/***/ }),
/* 307 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-map.of
__webpack_require__(68)('Map');


/***/ }),
/* 308 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-set.of
__webpack_require__(68)('Set');


/***/ }),
/* 309 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-weakmap.of
__webpack_require__(68)('WeakMap');


/***/ }),
/* 310 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-weakset.of
__webpack_require__(68)('WeakSet');


/***/ }),
/* 311 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-map.from
__webpack_require__(69)('Map');


/***/ }),
/* 312 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-set.from
__webpack_require__(69)('Set');


/***/ }),
/* 313 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-weakmap.from
__webpack_require__(69)('WeakMap');


/***/ }),
/* 314 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-weakset.from
__webpack_require__(69)('WeakSet');


/***/ }),
/* 315 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/tc39/proposal-global
var $export = __webpack_require__(0);

$export($export.G, { global: __webpack_require__(4) });


/***/ }),
/* 316 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/tc39/proposal-global
var $export = __webpack_require__(0);

$export($export.S, 'System', { global: __webpack_require__(4) });


/***/ }),
/* 317 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/ljharb/proposal-is-error
var $export = __webpack_require__(0);
var cof = __webpack_require__(24);

$export($export.S, 'Error', {
  isError: function isError(it) {
    return cof(it) === 'Error';
  }
});


/***/ }),
/* 318 */
/***/ (function(module, exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  clamp: function clamp(x, lower, upper) {
    return Math.min(upper, Math.max(lower, x));
  }
});


/***/ }),
/* 319 */
/***/ (function(module, exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(0);

$export($export.S, 'Math', { DEG_PER_RAD: Math.PI / 180 });


/***/ }),
/* 320 */
/***/ (function(module, exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(0);
var RAD_PER_DEG = 180 / Math.PI;

$export($export.S, 'Math', {
  degrees: function degrees(radians) {
    return radians * RAD_PER_DEG;
  }
});


/***/ }),
/* 321 */
/***/ (function(module, exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(0);
var scale = __webpack_require__(135);
var fround = __webpack_require__(115);

$export($export.S, 'Math', {
  fscale: function fscale(x, inLow, inHigh, outLow, outHigh) {
    return fround(scale(x, inLow, inHigh, outLow, outHigh));
  }
});


/***/ }),
/* 322 */
/***/ (function(module, exports, __webpack_require__) {

// https://gist.github.com/BrendanEich/4294d5c212a6d2254703
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  iaddh: function iaddh(x0, x1, y0, y1) {
    var $x0 = x0 >>> 0;
    var $x1 = x1 >>> 0;
    var $y0 = y0 >>> 0;
    return $x1 + (y1 >>> 0) + (($x0 & $y0 | ($x0 | $y0) & ~($x0 + $y0 >>> 0)) >>> 31) | 0;
  }
});


/***/ }),
/* 323 */
/***/ (function(module, exports, __webpack_require__) {

// https://gist.github.com/BrendanEich/4294d5c212a6d2254703
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  isubh: function isubh(x0, x1, y0, y1) {
    var $x0 = x0 >>> 0;
    var $x1 = x1 >>> 0;
    var $y0 = y0 >>> 0;
    return $x1 - (y1 >>> 0) - ((~$x0 & $y0 | ~($x0 ^ $y0) & $x0 - $y0 >>> 0) >>> 31) | 0;
  }
});


/***/ }),
/* 324 */
/***/ (function(module, exports, __webpack_require__) {

// https://gist.github.com/BrendanEich/4294d5c212a6d2254703
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  imulh: function imulh(u, v) {
    var UINT16 = 0xffff;
    var $u = +u;
    var $v = +v;
    var u0 = $u & UINT16;
    var v0 = $v & UINT16;
    var u1 = $u >> 16;
    var v1 = $v >> 16;
    var t = (u1 * v0 >>> 0) + (u0 * v0 >>> 16);
    return u1 * v1 + (t >> 16) + ((u0 * v1 >>> 0) + (t & UINT16) >> 16);
  }
});


/***/ }),
/* 325 */
/***/ (function(module, exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(0);

$export($export.S, 'Math', { RAD_PER_DEG: 180 / Math.PI });


/***/ }),
/* 326 */
/***/ (function(module, exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(0);
var DEG_PER_RAD = Math.PI / 180;

$export($export.S, 'Math', {
  radians: function radians(degrees) {
    return degrees * DEG_PER_RAD;
  }
});


/***/ }),
/* 327 */
/***/ (function(module, exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(0);

$export($export.S, 'Math', { scale: __webpack_require__(135) });


/***/ }),
/* 328 */
/***/ (function(module, exports, __webpack_require__) {

// https://gist.github.com/BrendanEich/4294d5c212a6d2254703
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  umulh: function umulh(u, v) {
    var UINT16 = 0xffff;
    var $u = +u;
    var $v = +v;
    var u0 = $u & UINT16;
    var v0 = $v & UINT16;
    var u1 = $u >>> 16;
    var v1 = $v >>> 16;
    var t = (u1 * v0 >>> 0) + (u0 * v0 >>> 16);
    return u1 * v1 + (t >>> 16) + ((u0 * v1 >>> 0) + (t & UINT16) >>> 16);
  }
});


/***/ }),
/* 329 */
/***/ (function(module, exports, __webpack_require__) {

// http://jfbastien.github.io/papers/Math.signbit.html
var $export = __webpack_require__(0);

$export($export.S, 'Math', { signbit: function signbit(x) {
  // eslint-disable-next-line no-self-compare
  return (x = +x) != x ? x : x == 0 ? 1 / x == Infinity : x > 0;
} });


/***/ }),
/* 330 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// https://github.com/tc39/proposal-promise-finally

var $export = __webpack_require__(0);
var core = __webpack_require__(26);
var global = __webpack_require__(4);
var speciesConstructor = __webpack_require__(64);
var promiseResolve = __webpack_require__(122);

$export($export.P + $export.R, 'Promise', { 'finally': function (onFinally) {
  var C = speciesConstructor(this, core.Promise || global.Promise);
  var isFunction = typeof onFinally == 'function';
  return this.then(
    isFunction ? function (x) {
      return promiseResolve(C, onFinally()).then(function () { return x; });
    } : onFinally,
    isFunction ? function (e) {
      return promiseResolve(C, onFinally()).then(function () { throw e; });
    } : onFinally
  );
} });


/***/ }),
/* 331 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/tc39/proposal-promise-try
var $export = __webpack_require__(0);
var newPromiseCapability = __webpack_require__(98);
var perform = __webpack_require__(121);

$export($export.S, 'Promise', { 'try': function (callbackfn) {
  var promiseCapability = newPromiseCapability.f(this);
  var result = perform(callbackfn);
  (result.e ? promiseCapability.reject : promiseCapability.resolve)(result.v);
  return promiseCapability.promise;
} });


/***/ }),
/* 332 */
/***/ (function(module, exports, __webpack_require__) {

var metadata = __webpack_require__(34);
var anObject = __webpack_require__(3);
var toMetaKey = metadata.key;
var ordinaryDefineOwnMetadata = metadata.set;

metadata.exp({ defineMetadata: function defineMetadata(metadataKey, metadataValue, target, targetKey) {
  ordinaryDefineOwnMetadata(metadataKey, metadataValue, anObject(target), toMetaKey(targetKey));
} });


/***/ }),
/* 333 */
/***/ (function(module, exports, __webpack_require__) {

var metadata = __webpack_require__(34);
var anObject = __webpack_require__(3);
var toMetaKey = metadata.key;
var getOrCreateMetadataMap = metadata.map;
var store = metadata.store;

metadata.exp({ deleteMetadata: function deleteMetadata(metadataKey, target /* , targetKey */) {
  var targetKey = arguments.length < 3 ? undefined : toMetaKey(arguments[2]);
  var metadataMap = getOrCreateMetadataMap(anObject(target), targetKey, false);
  if (metadataMap === undefined || !metadataMap['delete'](metadataKey)) return false;
  if (metadataMap.size) return true;
  var targetMetadata = store.get(target);
  targetMetadata['delete'](targetKey);
  return !!targetMetadata.size || store['delete'](target);
} });


/***/ }),
/* 334 */
/***/ (function(module, exports, __webpack_require__) {

var metadata = __webpack_require__(34);
var anObject = __webpack_require__(3);
var getPrototypeOf = __webpack_require__(22);
var ordinaryHasOwnMetadata = metadata.has;
var ordinaryGetOwnMetadata = metadata.get;
var toMetaKey = metadata.key;

var ordinaryGetMetadata = function (MetadataKey, O, P) {
  var hasOwn = ordinaryHasOwnMetadata(MetadataKey, O, P);
  if (hasOwn) return ordinaryGetOwnMetadata(MetadataKey, O, P);
  var parent = getPrototypeOf(O);
  return parent !== null ? ordinaryGetMetadata(MetadataKey, parent, P) : undefined;
};

metadata.exp({ getMetadata: function getMetadata(metadataKey, target /* , targetKey */) {
  return ordinaryGetMetadata(metadataKey, anObject(target), arguments.length < 3 ? undefined : toMetaKey(arguments[2]));
} });


/***/ }),
/* 335 */
/***/ (function(module, exports, __webpack_require__) {

var Set = __webpack_require__(125);
var from = __webpack_require__(134);
var metadata = __webpack_require__(34);
var anObject = __webpack_require__(3);
var getPrototypeOf = __webpack_require__(22);
var ordinaryOwnMetadataKeys = metadata.keys;
var toMetaKey = metadata.key;

var ordinaryMetadataKeys = function (O, P) {
  var oKeys = ordinaryOwnMetadataKeys(O, P);
  var parent = getPrototypeOf(O);
  if (parent === null) return oKeys;
  var pKeys = ordinaryMetadataKeys(parent, P);
  return pKeys.length ? oKeys.length ? from(new Set(oKeys.concat(pKeys))) : pKeys : oKeys;
};

metadata.exp({ getMetadataKeys: function getMetadataKeys(target /* , targetKey */) {
  return ordinaryMetadataKeys(anObject(target), arguments.length < 2 ? undefined : toMetaKey(arguments[1]));
} });


/***/ }),
/* 336 */
/***/ (function(module, exports, __webpack_require__) {

var metadata = __webpack_require__(34);
var anObject = __webpack_require__(3);
var ordinaryGetOwnMetadata = metadata.get;
var toMetaKey = metadata.key;

metadata.exp({ getOwnMetadata: function getOwnMetadata(metadataKey, target /* , targetKey */) {
  return ordinaryGetOwnMetadata(metadataKey, anObject(target)
    , arguments.length < 3 ? undefined : toMetaKey(arguments[2]));
} });


/***/ }),
/* 337 */
/***/ (function(module, exports, __webpack_require__) {

var metadata = __webpack_require__(34);
var anObject = __webpack_require__(3);
var ordinaryOwnMetadataKeys = metadata.keys;
var toMetaKey = metadata.key;

metadata.exp({ getOwnMetadataKeys: function getOwnMetadataKeys(target /* , targetKey */) {
  return ordinaryOwnMetadataKeys(anObject(target), arguments.length < 2 ? undefined : toMetaKey(arguments[1]));
} });


/***/ }),
/* 338 */
/***/ (function(module, exports, __webpack_require__) {

var metadata = __webpack_require__(34);
var anObject = __webpack_require__(3);
var getPrototypeOf = __webpack_require__(22);
var ordinaryHasOwnMetadata = metadata.has;
var toMetaKey = metadata.key;

var ordinaryHasMetadata = function (MetadataKey, O, P) {
  var hasOwn = ordinaryHasOwnMetadata(MetadataKey, O, P);
  if (hasOwn) return true;
  var parent = getPrototypeOf(O);
  return parent !== null ? ordinaryHasMetadata(MetadataKey, parent, P) : false;
};

metadata.exp({ hasMetadata: function hasMetadata(metadataKey, target /* , targetKey */) {
  return ordinaryHasMetadata(metadataKey, anObject(target), arguments.length < 3 ? undefined : toMetaKey(arguments[2]));
} });


/***/ }),
/* 339 */
/***/ (function(module, exports, __webpack_require__) {

var metadata = __webpack_require__(34);
var anObject = __webpack_require__(3);
var ordinaryHasOwnMetadata = metadata.has;
var toMetaKey = metadata.key;

metadata.exp({ hasOwnMetadata: function hasOwnMetadata(metadataKey, target /* , targetKey */) {
  return ordinaryHasOwnMetadata(metadataKey, anObject(target)
    , arguments.length < 3 ? undefined : toMetaKey(arguments[2]));
} });


/***/ }),
/* 340 */
/***/ (function(module, exports, __webpack_require__) {

var $metadata = __webpack_require__(34);
var anObject = __webpack_require__(3);
var aFunction = __webpack_require__(14);
var toMetaKey = $metadata.key;
var ordinaryDefineOwnMetadata = $metadata.set;

$metadata.exp({ metadata: function metadata(metadataKey, metadataValue) {
  return function decorator(target, targetKey) {
    ordinaryDefineOwnMetadata(
      metadataKey, metadataValue,
      (targetKey !== undefined ? anObject : aFunction)(target),
      toMetaKey(targetKey)
    );
  };
} });


/***/ }),
/* 341 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/rwaldron/tc39-notes/blob/master/es6/2014-09/sept-25.md#510-globalasap-for-enqueuing-a-microtask
var $export = __webpack_require__(0);
var microtask = __webpack_require__(97)();
var process = __webpack_require__(4).process;
var isNode = __webpack_require__(24)(process) == 'process';

$export($export.G, {
  asap: function asap(fn) {
    var domain = isNode && process.domain;
    microtask(domain ? domain.bind(fn) : fn);
  }
});


/***/ }),
/* 342 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/zenparsing/es-observable
var $export = __webpack_require__(0);
var global = __webpack_require__(4);
var core = __webpack_require__(26);
var microtask = __webpack_require__(97)();
var OBSERVABLE = __webpack_require__(8)('observable');
var aFunction = __webpack_require__(14);
var anObject = __webpack_require__(3);
var anInstance = __webpack_require__(45);
var redefineAll = __webpack_require__(47);
var hide = __webpack_require__(17);
var forOf = __webpack_require__(46);
var RETURN = forOf.RETURN;

var getMethod = function (fn) {
  return fn == null ? undefined : aFunction(fn);
};

var cleanupSubscription = function (subscription) {
  var cleanup = subscription._c;
  if (cleanup) {
    subscription._c = undefined;
    cleanup();
  }
};

var subscriptionClosed = function (subscription) {
  return subscription._o === undefined;
};

var closeSubscription = function (subscription) {
  if (!subscriptionClosed(subscription)) {
    subscription._o = undefined;
    cleanupSubscription(subscription);
  }
};

var Subscription = function (observer, subscriber) {
  anObject(observer);
  this._c = undefined;
  this._o = observer;
  observer = new SubscriptionObserver(this);
  try {
    var cleanup = subscriber(observer);
    var subscription = cleanup;
    if (cleanup != null) {
      if (typeof cleanup.unsubscribe === 'function') cleanup = function () { subscription.unsubscribe(); };
      else aFunction(cleanup);
      this._c = cleanup;
    }
  } catch (e) {
    observer.error(e);
    return;
  } if (subscriptionClosed(this)) cleanupSubscription(this);
};

Subscription.prototype = redefineAll({}, {
  unsubscribe: function unsubscribe() { closeSubscription(this); }
});

var SubscriptionObserver = function (subscription) {
  this._s = subscription;
};

SubscriptionObserver.prototype = redefineAll({}, {
  next: function next(value) {
    var subscription = this._s;
    if (!subscriptionClosed(subscription)) {
      var observer = subscription._o;
      try {
        var m = getMethod(observer.next);
        if (m) return m.call(observer, value);
      } catch (e) {
        try {
          closeSubscription(subscription);
        } finally {
          throw e;
        }
      }
    }
  },
  error: function error(value) {
    var subscription = this._s;
    if (subscriptionClosed(subscription)) throw value;
    var observer = subscription._o;
    subscription._o = undefined;
    try {
      var m = getMethod(observer.error);
      if (!m) throw value;
      value = m.call(observer, value);
    } catch (e) {
      try {
        cleanupSubscription(subscription);
      } finally {
        throw e;
      }
    } cleanupSubscription(subscription);
    return value;
  },
  complete: function complete(value) {
    var subscription = this._s;
    if (!subscriptionClosed(subscription)) {
      var observer = subscription._o;
      subscription._o = undefined;
      try {
        var m = getMethod(observer.complete);
        value = m ? m.call(observer, value) : undefined;
      } catch (e) {
        try {
          cleanupSubscription(subscription);
        } finally {
          throw e;
        }
      } cleanupSubscription(subscription);
      return value;
    }
  }
});

var $Observable = function Observable(subscriber) {
  anInstance(this, $Observable, 'Observable', '_f')._f = aFunction(subscriber);
};

redefineAll($Observable.prototype, {
  subscribe: function subscribe(observer) {
    return new Subscription(observer, this._f);
  },
  forEach: function forEach(fn) {
    var that = this;
    return new (core.Promise || global.Promise)(function (resolve, reject) {
      aFunction(fn);
      var subscription = that.subscribe({
        next: function (value) {
          try {
            return fn(value);
          } catch (e) {
            reject(e);
            subscription.unsubscribe();
          }
        },
        error: reject,
        complete: resolve
      });
    });
  }
});

redefineAll($Observable, {
  from: function from(x) {
    var C = typeof this === 'function' ? this : $Observable;
    var method = getMethod(anObject(x)[OBSERVABLE]);
    if (method) {
      var observable = anObject(method.call(x));
      return observable.constructor === C ? observable : new C(function (observer) {
        return observable.subscribe(observer);
      });
    }
    return new C(function (observer) {
      var done = false;
      microtask(function () {
        if (!done) {
          try {
            if (forOf(x, false, function (it) {
              observer.next(it);
              if (done) return RETURN;
            }) === RETURN) return;
          } catch (e) {
            if (done) throw e;
            observer.error(e);
            return;
          } observer.complete();
        }
      });
      return function () { done = true; };
    });
  },
  of: function of() {
    for (var i = 0, l = arguments.length, items = Array(l); i < l;) items[i] = arguments[i++];
    return new (typeof this === 'function' ? this : $Observable)(function (observer) {
      var done = false;
      microtask(function () {
        if (!done) {
          for (var j = 0; j < items.length; ++j) {
            observer.next(items[j]);
            if (done) return;
          } observer.complete();
        }
      });
      return function () { done = true; };
    });
  }
});

hide($Observable.prototype, OBSERVABLE, function () { return this; });

$export($export.G, { Observable: $Observable });

__webpack_require__(44)('Observable');


/***/ }),
/* 343 */
/***/ (function(module, exports, __webpack_require__) {

// ie9- setTimeout & setInterval additional parameters fix
var global = __webpack_require__(4);
var $export = __webpack_require__(0);
var navigator = global.navigator;
var slice = [].slice;
var MSIE = !!navigator && /MSIE .\./.test(navigator.userAgent); // <- dirty ie9- check
var wrap = function (set) {
  return function (fn, time /* , ...args */) {
    var boundArgs = arguments.length > 2;
    var args = boundArgs ? slice.call(arguments, 2) : false;
    return set(boundArgs ? function () {
      // eslint-disable-next-line no-new-func
      (typeof fn == 'function' ? fn : Function(fn)).apply(this, args);
    } : fn, time);
  };
};
$export($export.G + $export.B + $export.F * MSIE, {
  setTimeout: wrap(global.setTimeout),
  setInterval: wrap(global.setInterval)
});


/***/ }),
/* 344 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var $task = __webpack_require__(96);
$export($export.G + $export.B, {
  setImmediate: $task.set,
  clearImmediate: $task.clear
});


/***/ }),
/* 345 */
/***/ (function(module, exports, __webpack_require__) {

var $iterators = __webpack_require__(95);
var getKeys = __webpack_require__(40);
var redefine = __webpack_require__(18);
var global = __webpack_require__(4);
var hide = __webpack_require__(17);
var Iterators = __webpack_require__(51);
var wks = __webpack_require__(8);
var ITERATOR = wks('iterator');
var TO_STRING_TAG = wks('toStringTag');
var ArrayValues = Iterators.Array;

var DOMIterables = {
  CSSRuleList: true, // TODO: Not spec compliant, should be false.
  CSSStyleDeclaration: false,
  CSSValueList: false,
  ClientRectList: false,
  DOMRectList: false,
  DOMStringList: false,
  DOMTokenList: true,
  DataTransferItemList: false,
  FileList: false,
  HTMLAllCollection: false,
  HTMLCollection: false,
  HTMLFormElement: false,
  HTMLSelectElement: false,
  MediaList: true, // TODO: Not spec compliant, should be false.
  MimeTypeArray: false,
  NamedNodeMap: false,
  NodeList: true,
  PaintRequestList: false,
  Plugin: false,
  PluginArray: false,
  SVGLengthList: false,
  SVGNumberList: false,
  SVGPathSegList: false,
  SVGPointList: false,
  SVGStringList: false,
  SVGTransformList: false,
  SourceBufferList: false,
  StyleSheetList: true, // TODO: Not spec compliant, should be false.
  TextTrackCueList: false,
  TextTrackList: false,
  TouchList: false
};

for (var collections = getKeys(DOMIterables), i = 0; i < collections.length; i++) {
  var NAME = collections[i];
  var explicit = DOMIterables[NAME];
  var Collection = global[NAME];
  var proto = Collection && Collection.prototype;
  var key;
  if (proto) {
    if (!proto[ITERATOR]) hide(proto, ITERATOR, ArrayValues);
    if (!proto[TO_STRING_TAG]) hide(proto, TO_STRING_TAG, NAME);
    Iterators[NAME] = ArrayValues;
    if (explicit) for (key in $iterators) if (!proto[key]) redefine(proto, key, $iterators[key], true);
  }
}


/***/ }),
/* 346 */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(global) {/**
 * Copyright (c) 2014, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * https://raw.github.com/facebook/regenerator/master/LICENSE file. An
 * additional grant of patent rights can be found in the PATENTS file in
 * the same directory.
 */

!(function(global) {
  "use strict";

  var Op = Object.prototype;
  var hasOwn = Op.hasOwnProperty;
  var undefined; // More compressible than void 0.
  var $Symbol = typeof Symbol === "function" ? Symbol : {};
  var iteratorSymbol = $Symbol.iterator || "@@iterator";
  var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
  var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";

  var inModule = typeof module === "object";
  var runtime = global.regeneratorRuntime;
  if (runtime) {
    if (inModule) {
      // If regeneratorRuntime is defined globally and we're in a module,
      // make the exports object identical to regeneratorRuntime.
      module.exports = runtime;
    }
    // Don't bother evaluating the rest of this file if the runtime was
    // already defined globally.
    return;
  }

  // Define the runtime globally (as expected by generated code) as either
  // module.exports (if we're in a module) or a new, empty object.
  runtime = global.regeneratorRuntime = inModule ? module.exports : {};

  function wrap(innerFn, outerFn, self, tryLocsList) {
    // If outerFn provided and outerFn.prototype is a Generator, then outerFn.prototype instanceof Generator.
    var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
    var generator = Object.create(protoGenerator.prototype);
    var context = new Context(tryLocsList || []);

    // The ._invoke method unifies the implementations of the .next,
    // .throw, and .return methods.
    generator._invoke = makeInvokeMethod(innerFn, self, context);

    return generator;
  }
  runtime.wrap = wrap;

  // Try/catch helper to minimize deoptimizations. Returns a completion
  // record like context.tryEntries[i].completion. This interface could
  // have been (and was previously) designed to take a closure to be
  // invoked without arguments, but in all the cases we care about we
  // already have an existing method we want to call, so there's no need
  // to create a new function object. We can even get away with assuming
  // the method takes exactly one argument, since that happens to be true
  // in every case, so we don't have to touch the arguments object. The
  // only additional allocation required is the completion record, which
  // has a stable shape and so hopefully should be cheap to allocate.
  function tryCatch(fn, obj, arg) {
    try {
      return { type: "normal", arg: fn.call(obj, arg) };
    } catch (err) {
      return { type: "throw", arg: err };
    }
  }

  var GenStateSuspendedStart = "suspendedStart";
  var GenStateSuspendedYield = "suspendedYield";
  var GenStateExecuting = "executing";
  var GenStateCompleted = "completed";

  // Returning this object from the innerFn has the same effect as
  // breaking out of the dispatch switch statement.
  var ContinueSentinel = {};

  // Dummy constructor functions that we use as the .constructor and
  // .constructor.prototype properties for functions that return Generator
  // objects. For full spec compliance, you may wish to configure your
  // minifier not to mangle the names of these two functions.
  function Generator() {}
  function GeneratorFunction() {}
  function GeneratorFunctionPrototype() {}

  // This is a polyfill for %IteratorPrototype% for environments that
  // don't natively support it.
  var IteratorPrototype = {};
  IteratorPrototype[iteratorSymbol] = function () {
    return this;
  };

  var getProto = Object.getPrototypeOf;
  var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
  if (NativeIteratorPrototype &&
      NativeIteratorPrototype !== Op &&
      hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
    // This environment has a native %IteratorPrototype%; use it instead
    // of the polyfill.
    IteratorPrototype = NativeIteratorPrototype;
  }

  var Gp = GeneratorFunctionPrototype.prototype =
    Generator.prototype = Object.create(IteratorPrototype);
  GeneratorFunction.prototype = Gp.constructor = GeneratorFunctionPrototype;
  GeneratorFunctionPrototype.constructor = GeneratorFunction;
  GeneratorFunctionPrototype[toStringTagSymbol] =
    GeneratorFunction.displayName = "GeneratorFunction";

  // Helper for defining the .next, .throw, and .return methods of the
  // Iterator interface in terms of a single ._invoke method.
  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function(method) {
      prototype[method] = function(arg) {
        return this._invoke(method, arg);
      };
    });
  }

  runtime.isGeneratorFunction = function(genFun) {
    var ctor = typeof genFun === "function" && genFun.constructor;
    return ctor
      ? ctor === GeneratorFunction ||
        // For the native GeneratorFunction constructor, the best we can
        // do is to check its .name property.
        (ctor.displayName || ctor.name) === "GeneratorFunction"
      : false;
  };

  runtime.mark = function(genFun) {
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
    } else {
      genFun.__proto__ = GeneratorFunctionPrototype;
      if (!(toStringTagSymbol in genFun)) {
        genFun[toStringTagSymbol] = "GeneratorFunction";
      }
    }
    genFun.prototype = Object.create(Gp);
    return genFun;
  };

  // Within the body of any async function, `await x` is transformed to
  // `yield regeneratorRuntime.awrap(x)`, so that the runtime can test
  // `hasOwn.call(value, "__await")` to determine if the yielded value is
  // meant to be awaited.
  runtime.awrap = function(arg) {
    return { __await: arg };
  };

  function AsyncIterator(generator) {
    function invoke(method, arg, resolve, reject) {
      var record = tryCatch(generator[method], generator, arg);
      if (record.type === "throw") {
        reject(record.arg);
      } else {
        var result = record.arg;
        var value = result.value;
        if (value &&
            typeof value === "object" &&
            hasOwn.call(value, "__await")) {
          return Promise.resolve(value.__await).then(function(value) {
            invoke("next", value, resolve, reject);
          }, function(err) {
            invoke("throw", err, resolve, reject);
          });
        }

        return Promise.resolve(value).then(function(unwrapped) {
          // When a yielded Promise is resolved, its final value becomes
          // the .value of the Promise<{value,done}> result for the
          // current iteration. If the Promise is rejected, however, the
          // result for this iteration will be rejected with the same
          // reason. Note that rejections of yielded Promises are not
          // thrown back into the generator function, as is the case
          // when an awaited Promise is rejected. This difference in
          // behavior between yield and await is important, because it
          // allows the consumer to decide what to do with the yielded
          // rejection (swallow it and continue, manually .throw it back
          // into the generator, abandon iteration, whatever). With
          // await, by contrast, there is no opportunity to examine the
          // rejection reason outside the generator function, so the
          // only option is to throw it from the await expression, and
          // let the generator function handle the exception.
          result.value = unwrapped;
          resolve(result);
        }, reject);
      }
    }

    if (typeof global.process === "object" && global.process.domain) {
      invoke = global.process.domain.bind(invoke);
    }

    var previousPromise;

    function enqueue(method, arg) {
      function callInvokeWithMethodAndArg() {
        return new Promise(function(resolve, reject) {
          invoke(method, arg, resolve, reject);
        });
      }

      return previousPromise =
        // If enqueue has been called before, then we want to wait until
        // all previous Promises have been resolved before calling invoke,
        // so that results are always delivered in the correct order. If
        // enqueue has not been called before, then it is important to
        // call invoke immediately, without waiting on a callback to fire,
        // so that the async generator function has the opportunity to do
        // any necessary setup in a predictable way. This predictability
        // is why the Promise constructor synchronously invokes its
        // executor callback, and why async functions synchronously
        // execute code before the first await. Since we implement simple
        // async functions in terms of async generators, it is especially
        // important to get this right, even though it requires care.
        previousPromise ? previousPromise.then(
          callInvokeWithMethodAndArg,
          // Avoid propagating failures to Promises returned by later
          // invocations of the iterator.
          callInvokeWithMethodAndArg
        ) : callInvokeWithMethodAndArg();
    }

    // Define the unified helper method that is used to implement .next,
    // .throw, and .return (see defineIteratorMethods).
    this._invoke = enqueue;
  }

  defineIteratorMethods(AsyncIterator.prototype);
  AsyncIterator.prototype[asyncIteratorSymbol] = function () {
    return this;
  };
  runtime.AsyncIterator = AsyncIterator;

  // Note that simple async functions are implemented on top of
  // AsyncIterator objects; they just return a Promise for the value of
  // the final result produced by the iterator.
  runtime.async = function(innerFn, outerFn, self, tryLocsList) {
    var iter = new AsyncIterator(
      wrap(innerFn, outerFn, self, tryLocsList)
    );

    return runtime.isGeneratorFunction(outerFn)
      ? iter // If outerFn is a generator, return the full iterator.
      : iter.next().then(function(result) {
          return result.done ? result.value : iter.next();
        });
  };

  function makeInvokeMethod(innerFn, self, context) {
    var state = GenStateSuspendedStart;

    return function invoke(method, arg) {
      if (state === GenStateExecuting) {
        throw new Error("Generator is already running");
      }

      if (state === GenStateCompleted) {
        if (method === "throw") {
          throw arg;
        }

        // Be forgiving, per 25.3.3.3.3 of the spec:
        // https://people.mozilla.org/~jorendorff/es6-draft.html#sec-generatorresume
        return doneResult();
      }

      context.method = method;
      context.arg = arg;

      while (true) {
        var delegate = context.delegate;
        if (delegate) {
          var delegateResult = maybeInvokeDelegate(delegate, context);
          if (delegateResult) {
            if (delegateResult === ContinueSentinel) continue;
            return delegateResult;
          }
        }

        if (context.method === "next") {
          // Setting context._sent for legacy support of Babel's
          // function.sent implementation.
          context.sent = context._sent = context.arg;

        } else if (context.method === "throw") {
          if (state === GenStateSuspendedStart) {
            state = GenStateCompleted;
            throw context.arg;
          }

          context.dispatchException(context.arg);

        } else if (context.method === "return") {
          context.abrupt("return", context.arg);
        }

        state = GenStateExecuting;

        var record = tryCatch(innerFn, self, context);
        if (record.type === "normal") {
          // If an exception is thrown from innerFn, we leave state ===
          // GenStateExecuting and loop back for another invocation.
          state = context.done
            ? GenStateCompleted
            : GenStateSuspendedYield;

          if (record.arg === ContinueSentinel) {
            continue;
          }

          return {
            value: record.arg,
            done: context.done
          };

        } else if (record.type === "throw") {
          state = GenStateCompleted;
          // Dispatch the exception by looping back around to the
          // context.dispatchException(context.arg) call above.
          context.method = "throw";
          context.arg = record.arg;
        }
      }
    };
  }

  // Call delegate.iterator[context.method](context.arg) and handle the
  // result, either by returning a { value, done } result from the
  // delegate iterator, or by modifying context.method and context.arg,
  // setting context.delegate to null, and returning the ContinueSentinel.
  function maybeInvokeDelegate(delegate, context) {
    var method = delegate.iterator[context.method];
    if (method === undefined) {
      // A .throw or .return when the delegate iterator has no .throw
      // method always terminates the yield* loop.
      context.delegate = null;

      if (context.method === "throw") {
        if (delegate.iterator.return) {
          // If the delegate iterator has a return method, give it a
          // chance to clean up.
          context.method = "return";
          context.arg = undefined;
          maybeInvokeDelegate(delegate, context);

          if (context.method === "throw") {
            // If maybeInvokeDelegate(context) changed context.method from
            // "return" to "throw", let that override the TypeError below.
            return ContinueSentinel;
          }
        }

        context.method = "throw";
        context.arg = new TypeError(
          "The iterator does not provide a 'throw' method");
      }

      return ContinueSentinel;
    }

    var record = tryCatch(method, delegate.iterator, context.arg);

    if (record.type === "throw") {
      context.method = "throw";
      context.arg = record.arg;
      context.delegate = null;
      return ContinueSentinel;
    }

    var info = record.arg;

    if (! info) {
      context.method = "throw";
      context.arg = new TypeError("iterator result is not an object");
      context.delegate = null;
      return ContinueSentinel;
    }

    if (info.done) {
      // Assign the result of the finished delegate to the temporary
      // variable specified by delegate.resultName (see delegateYield).
      context[delegate.resultName] = info.value;

      // Resume execution at the desired location (see delegateYield).
      context.next = delegate.nextLoc;

      // If context.method was "throw" but the delegate handled the
      // exception, let the outer generator proceed normally. If
      // context.method was "next", forget context.arg since it has been
      // "consumed" by the delegate iterator. If context.method was
      // "return", allow the original .return call to continue in the
      // outer generator.
      if (context.method !== "return") {
        context.method = "next";
        context.arg = undefined;
      }

    } else {
      // Re-yield the result returned by the delegate method.
      return info;
    }

    // The delegate iterator is finished, so forget it and continue with
    // the outer generator.
    context.delegate = null;
    return ContinueSentinel;
  }

  // Define Generator.prototype.{next,throw,return} in terms of the
  // unified ._invoke helper method.
  defineIteratorMethods(Gp);

  Gp[toStringTagSymbol] = "Generator";

  // A Generator should always return itself as the iterator object when the
  // @@iterator function is called on it. Some browsers' implementations of the
  // iterator prototype chain incorrectly implement this, causing the Generator
  // object to not be returned from this call. This ensures that doesn't happen.
  // See https://github.com/facebook/regenerator/issues/274 for more details.
  Gp[iteratorSymbol] = function() {
    return this;
  };

  Gp.toString = function() {
    return "[object Generator]";
  };

  function pushTryEntry(locs) {
    var entry = { tryLoc: locs[0] };

    if (1 in locs) {
      entry.catchLoc = locs[1];
    }

    if (2 in locs) {
      entry.finallyLoc = locs[2];
      entry.afterLoc = locs[3];
    }

    this.tryEntries.push(entry);
  }

  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal";
    delete record.arg;
    entry.completion = record;
  }

  function Context(tryLocsList) {
    // The root entry object (effectively a try statement without a catch
    // or a finally block) gives us a place to store values thrown from
    // locations where there is no enclosing try statement.
    this.tryEntries = [{ tryLoc: "root" }];
    tryLocsList.forEach(pushTryEntry, this);
    this.reset(true);
  }

  runtime.keys = function(object) {
    var keys = [];
    for (var key in object) {
      keys.push(key);
    }
    keys.reverse();

    // Rather than returning an object with a next method, we keep
    // things simple and return the next function itself.
    return function next() {
      while (keys.length) {
        var key = keys.pop();
        if (key in object) {
          next.value = key;
          next.done = false;
          return next;
        }
      }

      // To avoid creating an additional object, we just hang the .value
      // and .done properties off the next function object itself. This
      // also ensures that the minifier will not anonymize the function.
      next.done = true;
      return next;
    };
  };

  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) {
        return iteratorMethod.call(iterable);
      }

      if (typeof iterable.next === "function") {
        return iterable;
      }

      if (!isNaN(iterable.length)) {
        var i = -1, next = function next() {
          while (++i < iterable.length) {
            if (hasOwn.call(iterable, i)) {
              next.value = iterable[i];
              next.done = false;
              return next;
            }
          }

          next.value = undefined;
          next.done = true;

          return next;
        };

        return next.next = next;
      }
    }

    // Return an iterator with no values.
    return { next: doneResult };
  }
  runtime.values = values;

  function doneResult() {
    return { value: undefined, done: true };
  }

  Context.prototype = {
    constructor: Context,

    reset: function(skipTempReset) {
      this.prev = 0;
      this.next = 0;
      // Resetting context._sent for legacy support of Babel's
      // function.sent implementation.
      this.sent = this._sent = undefined;
      this.done = false;
      this.delegate = null;

      this.method = "next";
      this.arg = undefined;

      this.tryEntries.forEach(resetTryEntry);

      if (!skipTempReset) {
        for (var name in this) {
          // Not sure about the optimal order of these conditions:
          if (name.charAt(0) === "t" &&
              hasOwn.call(this, name) &&
              !isNaN(+name.slice(1))) {
            this[name] = undefined;
          }
        }
      }
    },

    stop: function() {
      this.done = true;

      var rootEntry = this.tryEntries[0];
      var rootRecord = rootEntry.completion;
      if (rootRecord.type === "throw") {
        throw rootRecord.arg;
      }

      return this.rval;
    },

    dispatchException: function(exception) {
      if (this.done) {
        throw exception;
      }

      var context = this;
      function handle(loc, caught) {
        record.type = "throw";
        record.arg = exception;
        context.next = loc;

        if (caught) {
          // If the dispatched exception was caught by a catch block,
          // then let that catch block handle the exception normally.
          context.method = "next";
          context.arg = undefined;
        }

        return !! caught;
      }

      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        var record = entry.completion;

        if (entry.tryLoc === "root") {
          // Exception thrown outside of any try block that could handle
          // it, so set the completion value of the entire function to
          // throw the exception.
          return handle("end");
        }

        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc");
          var hasFinally = hasOwn.call(entry, "finallyLoc");

          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            } else if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            }

          } else if (hasFinally) {
            if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else {
            throw new Error("try statement without catch or finally");
          }
        }
      }
    },

    abrupt: function(type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc <= this.prev &&
            hasOwn.call(entry, "finallyLoc") &&
            this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }

      if (finallyEntry &&
          (type === "break" ||
           type === "continue") &&
          finallyEntry.tryLoc <= arg &&
          arg <= finallyEntry.finallyLoc) {
        // Ignore the finally entry if control is not jumping to a
        // location outside the try/catch block.
        finallyEntry = null;
      }

      var record = finallyEntry ? finallyEntry.completion : {};
      record.type = type;
      record.arg = arg;

      if (finallyEntry) {
        this.method = "next";
        this.next = finallyEntry.finallyLoc;
        return ContinueSentinel;
      }

      return this.complete(record);
    },

    complete: function(record, afterLoc) {
      if (record.type === "throw") {
        throw record.arg;
      }

      if (record.type === "break" ||
          record.type === "continue") {
        this.next = record.arg;
      } else if (record.type === "return") {
        this.rval = this.arg = record.arg;
        this.method = "return";
        this.next = "end";
      } else if (record.type === "normal" && afterLoc) {
        this.next = afterLoc;
      }

      return ContinueSentinel;
    },

    finish: function(finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) {
          this.complete(entry.completion, entry.afterLoc);
          resetTryEntry(entry);
          return ContinueSentinel;
        }
      }
    },

    "catch": function(tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;
          if (record.type === "throw") {
            var thrown = record.arg;
            resetTryEntry(entry);
          }
          return thrown;
        }
      }

      // The context.catch method must only be called with a location
      // argument that corresponds to a known catch block.
      throw new Error("illegal catch attempt");
    },

    delegateYield: function(iterable, resultName, nextLoc) {
      this.delegate = {
        iterator: values(iterable),
        resultName: resultName,
        nextLoc: nextLoc
      };

      if (this.method === "next") {
        // Deliberately forget the last sent value so that we don't
        // accidentally pass it on to the delegate.
        this.arg = undefined;
      }

      return ContinueSentinel;
    }
  };
})(
  // Among the various tricks for obtaining a reference to the global
  // object, this seems to be the most reliable technique that does not
  // use indirect eval (which violates Content Security Policy).
  typeof global === "object" ? global :
  typeof window === "object" ? window :
  typeof self === "object" ? self : this
);

/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(101)))

/***/ }),
/* 347 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(348);
module.exports = __webpack_require__(26).RegExp.escape;


/***/ }),
/* 348 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/benjamingr/RexExp.escape
var $export = __webpack_require__(0);
var $re = __webpack_require__(349)(/[\\^$*+?.()|[\]{}]/g, '\\$&');

$export($export.S, 'RegExp', { escape: function escape(it) { return $re(it); } });


/***/ }),
/* 349 */
/***/ (function(module, exports) {

module.exports = function (regExp, replace) {
  var replacer = replace === Object(replace) ? function (part) {
    return replace[part];
  } : replace;
  return function (it) {
    return String(it).replace(regExp, replacer);
  };
};


/***/ }),
/* 350 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.features = undefined;

var _adjustableColumnWidths = __webpack_require__(351);

var _autoDistributeSplits = __webpack_require__(357);

var _calendarFirstDay = __webpack_require__(358);

var _changeEnterBehavior = __webpack_require__(359);

var _clearSelection = __webpack_require__(360);

var _customFlagNames = __webpack_require__(361);

var _easyTransactionApproval = __webpack_require__(362);

var _emphasizedOutflows = __webpack_require__(363);

var _largerClearedIcons = __webpack_require__(366);

var _rightClickToEdit = __webpack_require__(369);

var _rowHeight = __webpack_require__(372);

var _showCategoryBalance = __webpack_require__(379);

var _spareChange = __webpack_require__(381);

var _splitKeyboardShortcut = __webpack_require__(384);

var _splitTransactionAutoAdjust = __webpack_require__(387);

var _stripedRows = __webpack_require__(388);

var _swapClearedFlagged = __webpack_require__(391);

var _toggleSplits = __webpack_require__(394);

var _toggleTransactionFilters = __webpack_require__(397);

var _transactionGridFeatures = __webpack_require__(400);

var _disableToolkit = __webpack_require__(418);

var _budgetProgressBars = __webpack_require__(419);

var _categoryActivityCopy = __webpack_require__(422);

var _categoryActivityPopupWidth = __webpack_require__(423);

var _checkCreditBalances = __webpack_require__(428);

var _creditCardEmoji = __webpack_require__(431);

var _daysOfBuffering = __webpack_require__(434);

var _displayGoalAmount = __webpack_require__(440);

var _enlargeCategoriesDropdown = __webpack_require__(441);

var _enterToMove = __webpack_require__(442);

var _goalWarningColor = __webpack_require__(443);

var _hideAgeOfMoney = __webpack_require__(446);

var _highlightCurrentMonth = __webpack_require__(449);

var _incomeFromLastMonth = __webpack_require__(452);

var _monthlyNotesPopupWidth = __webpack_require__(455);

var _quickBudgetWarning = __webpack_require__(460);

var _removePositiveHighlight = __webpack_require__(461);

var _removeZeroCategories = __webpack_require__(464);

var _resizeInspector = __webpack_require__(465);

var _rowsHeight = __webpack_require__(468);

var _seamlessBudgetHeader = __webpack_require__(475);

var _stealingFromFuture = __webpack_require__(478);

var _targetBalanceWarning = __webpack_require__(481);

var _toBeBudgetedWarning = __webpack_require__(482);

var _toggleMasterCategories = __webpack_require__(485);

var _accountsDisplayDensity = __webpack_require__(488);

var _betterScrollbars = __webpack_require__(493);

var _budgetQuickSwitch = __webpack_require__(500);

var _collapseSideMenu = __webpack_require__(501);

var _colourBlindMode = __webpack_require__(504);

var _editAccountButton = __webpack_require__(507);

var _googleFontsSelector = __webpack_require__(512);

var _hideAccountBalances = __webpack_require__(521);

var _hideHelp = __webpack_require__(524);

var _hideReferralBanner = __webpack_require__(527);

var _importNotification = __webpack_require__(530);

var _navDisplayDensity = __webpack_require__(533);

var _printingImprovements = __webpack_require__(538);

var _privacyMode = __webpack_require__(541);

var _showIntercom = __webpack_require__(546);

var _squareNegativeMode = __webpack_require__(547);

var _compactIncomeVsExpense = __webpack_require__(550);

/*
 ***********************************************************
 * Warning: This is a file generated by the build process. *
 *                                                         *
 * Any changes you make manually will be overwritten       *
 * the next time you run webpack!                          *
 ***********************************************************
*/
if (!_adjustableColumnWidths.AdjustableColumnWidths) {
  throw new Error('AdjustableColumnWidths feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_autoDistributeSplits.AutoDistributeSplits) {
  throw new Error('AutoDistributeSplits feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_calendarFirstDay.CalendarFirstDay) {
  throw new Error('CalendarFirstDay feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_changeEnterBehavior.ChangeEnterBehavior) {
  throw new Error('ChangeEnterBehavior feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_clearSelection.ClearSelection) {
  throw new Error('ClearSelection feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_customFlagNames.CustomFlagNames) {
  throw new Error('CustomFlagNames feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_easyTransactionApproval.EasyTransactionApproval) {
  throw new Error('EasyTransactionApproval feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_emphasizedOutflows.AccountsEmphasizedOutflows) {
  throw new Error('AccountsEmphasizedOutflows feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_largerClearedIcons.LargerClickableIcons) {
  throw new Error('LargerClickableIcons feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_rightClickToEdit.RightClickToEdit) {
  throw new Error('RightClickToEdit feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_rowHeight.RowHeight) {
  throw new Error('RowHeight feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_showCategoryBalance.ShowCategoryBalance) {
  throw new Error('ShowCategoryBalance feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_spareChange.SpareChange) {
  throw new Error('SpareChange feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_splitKeyboardShortcut.SplitKeyboardShortcut) {
  throw new Error('SplitKeyboardShortcut feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_splitTransactionAutoAdjust.SplitTransactionAutoAdjust) {
  throw new Error('SplitTransactionAutoAdjust feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_stripedRows.AccountsStripedRows) {
  throw new Error('AccountsStripedRows feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_swapClearedFlagged.SwapClearedFlagged) {
  throw new Error('SwapClearedFlagged feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_toggleSplits.ToggleSplits) {
  throw new Error('ToggleSplits feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_toggleTransactionFilters.ToggleTransactionFilters) {
  throw new Error('ToggleTransactionFilters feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_transactionGridFeatures.TransactionGridFeatures) {
  throw new Error('TransactionGridFeatures feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_disableToolkit.DisableToolkit) {
  throw new Error('DisableToolkit feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_budgetProgressBars.BudgetProgressBars) {
  throw new Error('BudgetProgressBars feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_categoryActivityCopy.CategoryActivityCopy) {
  throw new Error('CategoryActivityCopy feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_categoryActivityPopupWidth.CategoryActivityPopupWidth) {
  throw new Error('CategoryActivityPopupWidth feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_checkCreditBalances.CheckCreditBalances) {
  throw new Error('CheckCreditBalances feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_creditCardEmoji.CreditCardEmoji) {
  throw new Error('CreditCardEmoji feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_daysOfBuffering.DaysOfBuffering) {
  throw new Error('DaysOfBuffering feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_displayGoalAmount.DisplayTargetGoalAmount) {
  throw new Error('DisplayTargetGoalAmount feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_enlargeCategoriesDropdown.EnlargeCategoriesDropdown) {
  throw new Error('EnlargeCategoriesDropdown feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_enterToMove.EnterToMove) {
  throw new Error('EnterToMove feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_goalWarningColor.GoalWarningColor) {
  throw new Error('GoalWarningColor feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_hideAgeOfMoney.HideAgeOfMoney) {
  throw new Error('HideAgeOfMoney feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_highlightCurrentMonth.CurrentMonthIndicator) {
  throw new Error('CurrentMonthIndicator feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_incomeFromLastMonth.IncomeFromLastMonth) {
  throw new Error('IncomeFromLastMonth feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_monthlyNotesPopupWidth.MonthlyNotesPopupWidth) {
  throw new Error('MonthlyNotesPopupWidth feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_quickBudgetWarning.QuickBudgetWarning) {
  throw new Error('QuickBudgetWarning feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_removePositiveHighlight.RemovePositiveHighlight) {
  throw new Error('RemovePositiveHighlight feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_removeZeroCategories.RemoveZeroCategories) {
  throw new Error('RemoveZeroCategories feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_resizeInspector.ResizeInspector) {
  throw new Error('ResizeInspector feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_rowsHeight.RowsHeight) {
  throw new Error('RowsHeight feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_seamlessBudgetHeader.SeamlessBudgetHeader) {
  throw new Error('SeamlessBudgetHeader feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_stealingFromFuture.StealingFromFuture) {
  throw new Error('StealingFromFuture feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_targetBalanceWarning.TargetBalanceWarning) {
  throw new Error('TargetBalanceWarning feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_toBeBudgetedWarning.ToBeBudgetedWarning) {
  throw new Error('ToBeBudgetedWarning feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_toggleMasterCategories.ToggleMasterCategories) {
  throw new Error('ToggleMasterCategories feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_accountsDisplayDensity.AccountsDisplayDensity) {
  throw new Error('AccountsDisplayDensity feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_betterScrollbars.BetterScrollbars) {
  throw new Error('BetterScrollbars feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_budgetQuickSwitch.BudgetQuickSwitch) {
  throw new Error('BudgetQuickSwitch feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_collapseSideMenu.CollapseSideMenu) {
  throw new Error('CollapseSideMenu feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_colourBlindMode.ColourBlindMode) {
  throw new Error('ColourBlindMode feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_editAccountButton.EditAccountButton) {
  throw new Error('EditAccountButton feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_googleFontsSelector.GoogleFontsSelector) {
  throw new Error('GoogleFontsSelector feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_hideAccountBalances.HideAccountBalancesType) {
  throw new Error('HideAccountBalancesType feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_hideHelp.HideHelp) {
  throw new Error('HideHelp feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_hideReferralBanner.HideReferralBanner) {
  throw new Error('HideReferralBanner feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_importNotification.ImportNotification) {
  throw new Error('ImportNotification feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_navDisplayDensity.NavDisplayDensity) {
  throw new Error('NavDisplayDensity feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_printingImprovements.PrintingImprovements) {
  throw new Error('PrintingImprovements feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_privacyMode.PrivacyMode) {
  throw new Error('PrivacyMode feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_showIntercom.ShowIntercom) {
  throw new Error('ShowIntercom feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_squareNegativeMode.SquareNegativeMode) {
  throw new Error('SquareNegativeMode feature failed to import. Have you set the name in the settings.js file to match the class name?');
}
if (!_compactIncomeVsExpense.CompactIncomeVsExpense) {
  throw new Error('CompactIncomeVsExpense feature failed to import. Have you set the name in the settings.js file to match the class name?');
}

var features = exports.features = [_adjustableColumnWidths.AdjustableColumnWidths, _autoDistributeSplits.AutoDistributeSplits, _calendarFirstDay.CalendarFirstDay, _changeEnterBehavior.ChangeEnterBehavior, _clearSelection.ClearSelection, _customFlagNames.CustomFlagNames, _easyTransactionApproval.EasyTransactionApproval, _emphasizedOutflows.AccountsEmphasizedOutflows, _largerClearedIcons.LargerClickableIcons, _rightClickToEdit.RightClickToEdit, _rowHeight.RowHeight, _showCategoryBalance.ShowCategoryBalance, _spareChange.SpareChange, _splitKeyboardShortcut.SplitKeyboardShortcut, _splitTransactionAutoAdjust.SplitTransactionAutoAdjust, _stripedRows.AccountsStripedRows, _swapClearedFlagged.SwapClearedFlagged, _toggleSplits.ToggleSplits, _toggleTransactionFilters.ToggleTransactionFilters, _transactionGridFeatures.TransactionGridFeatures, _disableToolkit.DisableToolkit, _budgetProgressBars.BudgetProgressBars, _categoryActivityCopy.CategoryActivityCopy, _categoryActivityPopupWidth.CategoryActivityPopupWidth, _checkCreditBalances.CheckCreditBalances, _creditCardEmoji.CreditCardEmoji, _daysOfBuffering.DaysOfBuffering, _displayGoalAmount.DisplayTargetGoalAmount, _enlargeCategoriesDropdown.EnlargeCategoriesDropdown, _enterToMove.EnterToMove, _goalWarningColor.GoalWarningColor, _hideAgeOfMoney.HideAgeOfMoney, _highlightCurrentMonth.CurrentMonthIndicator, _incomeFromLastMonth.IncomeFromLastMonth, _monthlyNotesPopupWidth.MonthlyNotesPopupWidth, _quickBudgetWarning.QuickBudgetWarning, _removePositiveHighlight.RemovePositiveHighlight, _removeZeroCategories.RemoveZeroCategories, _resizeInspector.ResizeInspector, _rowsHeight.RowsHeight, _seamlessBudgetHeader.SeamlessBudgetHeader, _stealingFromFuture.StealingFromFuture, _targetBalanceWarning.TargetBalanceWarning, _toBeBudgetedWarning.ToBeBudgetedWarning, _toggleMasterCategories.ToggleMasterCategories, _accountsDisplayDensity.AccountsDisplayDensity, _betterScrollbars.BetterScrollbars, _budgetQuickSwitch.BudgetQuickSwitch, _collapseSideMenu.CollapseSideMenu, _colourBlindMode.ColourBlindMode, _editAccountButton.EditAccountButton, _googleFontsSelector.GoogleFontsSelector, _hideAccountBalances.HideAccountBalancesType, _hideHelp.HideHelp, _hideReferralBanner.HideReferralBanner, _importNotification.ImportNotification, _navDisplayDensity.NavDisplayDensity, _printingImprovements.PrintingImprovements, _privacyMode.PrivacyMode, _showIntercom.ShowIntercom, _squareNegativeMode.SquareNegativeMode, _compactIncomeVsExpense.CompactIncomeVsExpense];

/***/ }),
/* 351 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.AdjustableColumnWidths = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

var _toolkit = __webpack_require__(48);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var RESIZABLES = ['ynab-grid-cell-date', 'ynab-grid-cell-accountName', 'ynab-grid-cell-payeeName', 'ynab-grid-cell-subCategoryName', 'ynab-grid-cell-memo', 'ynab-grid-cell-toolkit-check-number', 'ynab-grid-cell-outflow', 'ynab-grid-cell-inflow', 'ynab-grid-cell-toolkit-running-balance'];

var AdjustableColumnWidths = exports.AdjustableColumnWidths = function (_Feature) {
  _inherits(AdjustableColumnWidths, _Feature);

  function AdjustableColumnWidths() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, AdjustableColumnWidths);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = AdjustableColumnWidths.__proto__ || Object.getPrototypeOf(AdjustableColumnWidths)).call.apply(_ref, [this].concat(args))), _this), _this.elementWasDragged = false, _this.isMouseDown = false, _this.currentX = null, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(AdjustableColumnWidths, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(355);
    }
  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('account') !== -1;
    }
  }, {
    key: 'onMouseMove',
    value: function onMouseMove(event) {
      var _this2 = this;

      if (!this.isMouseDown) {
        return;
      }

      event.preventDefault();
      event.stopPropagation();

      Ember.run.debounce(this, function () {
        if (_this2.offTarget && !event.target.classList.contains('toolkit-draggable')) {
          return;
        }

        _this2.offTarget = false;
        var invertedDifference = _this2.currentX - event.clientX;
        var difference = invertedDifference * -1;

        var _getNeighborOf = _this2.getNeighborOf(_this2.currentResizableClass),
            isNeighborResizable = _getNeighborOf.isNeighborResizable,
            neighborCellName = _getNeighborOf.neighborCellName;

        if (!isNeighborResizable) {
          return;
        }

        var $elementsOfTypeNeighbor = $('.' + neighborCellName);
        var neighborWidth = $elementsOfTypeNeighbor.width();
        var newNeighborWidth = neighborWidth - difference;

        var $elementsOfTypeCurrentResizable = $('.' + _this2.currentResizableClass);
        var currentResizableWidth = $elementsOfTypeCurrentResizable.width();
        var newCurrentResizableWidth = currentResizableWidth + difference;

        if (newNeighborWidth < 50 || newCurrentResizableWidth < 50) {
          _this2.offTarget = true;
          return;
        }

        _this2.currentX = event.clientX;
        $elementsOfTypeCurrentResizable.width(newCurrentResizableWidth);
        (0, _toolkit.setToolkitStorageKey)('column-width-' + _this2.currentResizableClass, newCurrentResizableWidth);

        $elementsOfTypeNeighbor.width(newNeighborWidth);
        (0, _toolkit.setToolkitStorageKey)('column-width-' + neighborCellName, newNeighborWidth);
      }, 100);
    }
  }, {
    key: 'onMouseUp',
    value: function onMouseUp() {
      $('body').off('mousemove', this.bindOnMouseMove);
      $('body').off('mouseup', this.bindOnMouseUp);

      if (this.isMouseDown) {
        this.isMouseDown = false;
        this.elementWasDragged = true;
      }
    }
  }, {
    key: 'getNeighborOf',
    value: function getNeighborOf(neighborOf) {
      var $rightNeighbor = $('.' + neighborOf, '.ynab-grid-header').next();

      if (!$rightNeighbor.length) {
        return { isNeighborResizable: false };
      }

      var neighborCellName = $rightNeighbor.prop('class').match(/ynab-grid-cell.*/)[0];
      return {
        neighborCellName: neighborCellName,
        isNeighborResizable: RESIZABLES.some(function (className) {
          return className === neighborCellName;
        })
      };
    }
  }, {
    key: 'resetWidths',
    value: function resetWidths() {
      RESIZABLES.forEach(function (resizableClass) {
        $('.' + resizableClass).width('');
        (0, _toolkit.removeToolkitStorageKey)('column-width-' + resizableClass);
      });
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      var _this3 = this;

      if (!$('.toolkit-reset-widths').length) {
        $('<button class="toolkit-reset-widths button">Reset Column Widths</button>').click(this.resetWidths).insertAfter($('.accounts-toolbar-all-dates', '.accounts-toolbar-right'));
      }

      RESIZABLES.forEach(function (resizableClass) {
        var width = (0, _toolkit.getToolkitStorageKey)('column-width-' + resizableClass, 'number');
        if (width) {
          $('.' + resizableClass).width(width);
        }

        if (!_this3.getNeighborOf(resizableClass).isNeighborResizable) {
          return;
        }

        if ($('.' + resizableClass + ' .toolkit-draggable', '.ynab-grid-header').length) {
          return;
        }

        $('.' + resizableClass, '.ynab-grid-header').click(function (event) {
          if (_this3.elementWasDragged) {
            event.preventDefault();
            event.stopPropagation();
            _this3.elementWasDragged = false;
          }
        }).css({ position: 'relative' }).append($('<div class="toolkit-draggable"></div>').click(function (event) {
          return event.stopPropagation();
        }).mousedown(function (event) {
          _this3.isMouseDown = true;
          _this3.currentX = event.clientX;
          _this3.currentResizableClass = resizableClass;

          _this3.bindOnMouseMove = _this3.onMouseMove.bind(_this3);
          _this3.bindOnMouseUp = _this3.onMouseUp.bind(_this3);
          $('body').on('mousemove', _this3.bindOnMouseMove);
          $('body').on('mouseup', _this3.bindOnMouseUp);
        }));
      });
    }
  }, {
    key: 'onRouteChanged',
    value: function onRouteChanged() {
      if (!this.shouldInvoke()) {
        return;
      }
      this.invoke();
    }
  }]);

  return AdjustableColumnWidths;
}(_feature.Feature);

/***/ }),
/* 352 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _observeListener = __webpack_require__(353);

Object.defineProperty(exports, 'ObserveListener', {
  enumerable: true,
  get: function get() {
    return _observeListener.ObserveListener;
  }
});

var _routeChangeListener = __webpack_require__(354);

Object.defineProperty(exports, 'RouteChangeListener', {
  enumerable: true,
  get: function get() {
    return _routeChangeListener.RouteChangeListener;
  }
});

/***/ }),
/* 353 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ObserveListener = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _withToolkitError = __webpack_require__(100);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var instance = null;

var ObserveListener = exports.ObserveListener = function () {
  function ObserveListener() {
    var _this = this;

    _classCallCheck(this, ObserveListener);

    if (instance) {
      return instance;
    }

    this.features = [];

    var _MutationObserver = window.MutationObserver || window.WebKitMutationObserver;
    var observer = new _MutationObserver(function (mutations) {
      _this.changedNodes = new Set();

      mutations.forEach(function (mutation) {
        var newNodes = mutation.target;
        var $nodes = $(newNodes);

        $nodes.each(function (index, element) {
          var nodeClass = $(element).attr('class');
          if (nodeClass) {
            _this.changedNodes.add(nodeClass.replace(/^ember-view /, ''));
          }
        });
      });

      // Now we are ready to feed the change digest to the
      // automatically setup feedChanges file/function
      if (_this.changedNodes.size > 0) {
        _this.emitChanges();
      }
    });

    // This finally says 'Watch for changes' and only needs to be called the one time
    observer.observe($('.ember-view.layout')[0], {
      subtree: true,
      childList: true,
      characterData: true,
      attributes: true,
      attributeFilter: ['class']
    });

    instance = this;
  }

  _createClass(ObserveListener, [{
    key: 'addFeature',
    value: function addFeature(feature) {
      if (this.features.indexOf(feature) === -1) {
        this.features.push(feature);
      }
    }
  }, {
    key: 'emitChanges',
    value: function emitChanges() {
      var _this2 = this;

      this.features.forEach(function (feature) {
        var observe = feature.observe.bind(feature, _this2.changedNodes);
        var wrapped = (0, _withToolkitError.withToolkitError)(observe, feature);
        Ember.run.later(wrapped, 0);
      });
    }
  }]);

  return ObserveListener;
}();

/***/ }),
/* 354 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.RouteChangeListener = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _ember = __webpack_require__(13);

var _withToolkitError = __webpack_require__(100);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var instance = null;

var RouteChangeListener = exports.RouteChangeListener = function () {
  function RouteChangeListener() {
    _classCallCheck(this, RouteChangeListener);

    if (instance) {
      return instance;
    }

    var routeChangeListener = this;
    routeChangeListener.features = [];

    var applicationController = (0, _ember.controllerLookup)('application');
    applicationController.reopen({
      onRouteChanged: Ember.observer('currentRouteName', // this will handle accounts -> budget and vise versa
      'budgetVersionId', // this will handle changing budgets
      'selectedAccountId', // this will handle switching around accounts
      'monthString', // this will handle changing which month of a budget you're looking at
      function (controller, changedProperty) {
        if (changedProperty === 'budgetVersionId') {
          Ember.run.scheduleOnce('afterRender', controller, 'emitBudgetRouteChange');
        } else {
          Ember.run.scheduleOnce('afterRender', controller, 'emitSameBudgetRouteChange');
        }
      }),

      emitSameBudgetRouteChange: function emitSameBudgetRouteChange() {
        var currentRoute = applicationController.get('currentRouteName');
        routeChangeListener.features.forEach(function (feature) {
          var observe = feature.onRouteChanged.bind(feature, currentRoute);
          var wrapped = (0, _withToolkitError.withToolkitError)(observe, feature);
          Ember.run.later(wrapped, 0);
        });
      },

      emitBudgetRouteChange: function emitBudgetRouteChange() {
        var currentRoute = applicationController.get('currentRouteName');
        routeChangeListener.features.forEach(function (feature) {
          var observe = feature.onBudgetChanged.bind(feature, currentRoute);
          var wrapped = (0, _withToolkitError.withToolkitError)(observe, feature);
          Ember.run.later(wrapped, 0);
        });
      }
    });

    instance = this;
  }

  _createClass(RouteChangeListener, [{
    key: 'addFeature',
    value: function addFeature(feature) {
      if (this.features.indexOf(feature) === -1) {
        this.features.push(feature);
      }
    }
  }]);

  return RouteChangeListener;
}();

/***/ }),
/* 355 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(356);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 356 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".toolkit-draggable {\n  display: inline-block;\n  right: 0;\n  position: absolute;\n  background: transparent;\n  width: 4px;\n  height: inherit;\n  cursor: col-resize;\n}\n\n.toolkit-reset-widths {\n  padding-top: .4em;\n}\n", ""]);

// exports


/***/ }),
/* 357 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.AutoDistributeSplits = undefined;

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ember = __webpack_require__(13);

function _toArray(arr) { return Array.isArray(arr) ? arr : Array.from(arr); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var DISTRIBUTE_BUTTON_ID = 'toolkit-auto-distribute-splits-button';

function actualNumber(n) {
  return typeof n === 'number' && !Number.isNaN(n);
}

var AutoDistributeSplits = exports.AutoDistributeSplits = function (_Feature) {
  _inherits(AutoDistributeSplits, _Feature);

  function AutoDistributeSplits() {
    _classCallCheck(this, AutoDistributeSplits);

    var _this = _possibleConstructorReturn(this, (AutoDistributeSplits.__proto__ || Object.getPrototypeOf(AutoDistributeSplits)).call(this));

    _this.button = document.createElement('button');
    _this.button.id = DISTRIBUTE_BUTTON_ID;
    _this.button.classList.add('button');
    _this.button.classList.add('button-primary');
    _this.button.innerHTML = 'Auto-Distribute';
    _this.button.onclick = function () {
      _this.distribute();
      _this.button.blur();
    };
    return _this;
  }

  _createClass(AutoDistributeSplits, [{
    key: 'observe',
    value: function observe(changedNodes) {
      if (this.buttonShouldBePresent(changedNodes)) {
        this.ensureButtonPresent();
      } else {
        this.ensureButtonNotPresent();
      }
    }
  }, {
    key: 'buttonShouldBePresent',
    value: function buttonShouldBePresent() {
      return $('.ynab-grid-split-add-sub-transaction').length > 0;
    }
  }, {
    key: 'ensureButtonPresent',
    value: function ensureButtonPresent() {
      if (!this.buttonPresent()) {
        $('.ynab-grid-actions-buttons .button-cancel').after(this.button);
      }
    }
  }, {
    key: 'ensureButtonNotPresent',
    value: function ensureButtonNotPresent() {
      if (this.buttonPresent()) {
        $('#' + DISTRIBUTE_BUTTON_ID).remove();
      }
    }
  }, {
    key: 'buttonPresent',
    value: function buttonPresent() {
      return $('#' + DISTRIBUTE_BUTTON_ID).length > 0;
    }
  }, {
    key: 'distribute',
    value: function distribute() {
      var _getCellsAndValues = this.getCellsAndValues(),
          _getCellsAndValues2 = _slicedToArray(_getCellsAndValues, 2),
          _getCellsAndValues2$ = _toArray(_getCellsAndValues2[0]),
          subCells = _getCellsAndValues2$.slice(1),
          _getCellsAndValues2$2 = _toArray(_getCellsAndValues2[1]),
          total = _getCellsAndValues2$2[0],
          subValues = _getCellsAndValues2$2.slice(1);

      if (!this.canDistribute(total, subValues)) {
        this.alertCannotDistribute();
        return;
      }

      var remaining = this.getRemainingValue(total, subValues);
      if (remaining < 0 && !this.confirmSubtraction()) {
        return;
      }

      this.adjustValues(subCells, subValues.map(this.proportionalValue(total, remaining)));
    }
  }, {
    key: 'getCellsAndValues',
    value: function getCellsAndValues() {
      var cells = $('.is-editing .ynab-grid-cell-outflow input').toArray();
      var values = cells.map(function (node) {
        return parseFloat(node.value.trim());
      });
      return [cells, values];
    }
  }, {
    key: 'canDistribute',
    value: function canDistribute(total, subValues) {
      return actualNumber(total) && subValues.any(actualNumber);
    }
  }, {
    key: 'alertCannotDistribute',
    value: function alertCannotDistribute() {
      // eslint-disable-next-line no-alert
      alert('Please fill in the transaction total and at least one ' + 'sub-transaction in order to auto-distribute the ' + 'remaining amount between sub-transactions');
    }
  }, {
    key: 'getRemainingValue',
    value: function getRemainingValue(total, subValues) {
      return total - subValues.filter(actualNumber).reduce(function (a, b) {
        return a + b;
      });
    }
  }, {
    key: 'confirmSubtraction',
    value: function confirmSubtraction() {
      // eslint-disable-next-line no-alert
      return window.confirm('Sub-transactions add up to more than the total, ' + 'are you sure you want to subtract from them?');
    }
  }, {
    key: 'proportionalValue',
    value: function proportionalValue(total, remaining) {
      return function (value) {
        return value + value / (total - remaining) * remaining;
      };
    }
  }, {
    key: 'adjustValues',
    value: function adjustValues(subCells, newSubValues) {
      subCells.forEach(function (cell, i) {
        $(cell).val(actualNumber(newSubValues[i]) ? (Math.round(newSubValues[i] * 100) / 100).toFixed(2) : '');
        $(cell).trigger('change');
      });

      (0, _ember.getEmberView)($('.ynab-grid-body-row.is-editing')[0].id).calculateSplitRemaining();
    }
  }]);

  return AutoDistributeSplits;
}(_feature.Feature);

/***/ }),
/* 358 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CalendarFirstDay = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var CalendarFirstDay = exports.CalendarFirstDay = function (_Feature) {
  _inherits(CalendarFirstDay, _Feature);

  function CalendarFirstDay() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, CalendarFirstDay);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = CalendarFirstDay.__proto__ || Object.getPrototypeOf(CalendarFirstDay)).call.apply(_ref, [this].concat(args))), _this), _this.isCalendarOpen = false, _this.isReRendering = false, _temp), _possibleConstructorReturn(_this, _ret);
  }
  // Variables for tracking specific states


  _createClass(CalendarFirstDay, [{
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return false;
    }
  }, {
    key: 'reRenderHeader',
    value: function reRenderHeader() {
      var shiftDays = this.shiftDays();
      // Shift the header items by number of days (only needs to happen once)
      for (var i = 0; i < shiftDays; i++) {
        var first = $('.accounts-calendar-weekdays').children().first();
        var last = $('.accounts-calendar-weekdays').children().last();
        first.insertAfter(last);
      }
      this.reRenderWeekdays();
    }
  }, {
    key: 'reRenderWeekdays',
    value: function reRenderWeekdays() {
      var shiftDays = this.shiftDays();

      // Remove all previously added shift elements
      $('.accounts-calendar-grid').find('.shift').remove();

      if ($('.accounts-calendar-empty').length >= shiftDays) {
        // Remove specific # of empty elements
        $('.accounts-calendar-empty').slice(-shiftDays).remove();
      } else {
        // Add 'shift' empty elements
        for (var j = 0; j < 7 - shiftDays; j++) {
          $('.accounts-calendar-grid').prepend('<li class="accounts-calendar-empty shift">&nbsp;</li>');
        }
      }
    }
  }, {
    key: 'shiftDays',
    value: function shiftDays() {
      return Number(this.settings.enabled);
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (changedNodes.has('ynab-u modal-account-calendar modal-account-dropdown ember-view modal-overlay active') || changedNodes.has('ynab-u modal-account-calendar ember-view modal-overlay active')) {
        this.isCalendarOpen = true;
        this.reRenderHeader();
      } else if (changedNodes.has('ynab-u modal-account-calendar ember-view modal-overlay active closing')) {
        this.isCalendarOpen = false;
      } else if (changedNodes.has('accounts-calendar-grid') && !changedNodes.has('accounts-calendar-weekdays') && this.isCalendarOpen && !this.isReRendering) {
        this.isReRendering = true;
        this.reRenderWeekdays();
      } else if (this.isReRendering) {
        // It's now safe to start listening for changes on the calendar node
        this.isReRendering = false;
      }
    }
  }]);

  return CalendarFirstDay;
}(_feature.Feature);

/***/ }),
/* 359 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ChangeEnterBehavior = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var ChangeEnterBehavior = exports.ChangeEnterBehavior = function (_Feature) {
  _inherits(ChangeEnterBehavior, _Feature);

  function ChangeEnterBehavior() {
    _classCallCheck(this, ChangeEnterBehavior);

    return _possibleConstructorReturn(this, (ChangeEnterBehavior.__proto__ || Object.getPrototypeOf(ChangeEnterBehavior)).apply(this, arguments));
  }

  _createClass(ChangeEnterBehavior, [{
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('account') !== -1 && $('.ynab-grid-body-row.is-adding').length;
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      var $addRow = $('.ynab-grid-body-row.is-adding');
      var $memoInput = $('.ynab-grid-cell-memo input', $addRow);
      var $outflowInput = $('.ynab-grid-cell-outflow input', $addRow);
      var $inflowInput = $('.ynab-grid-cell-inflow input', $addRow);

      if (!$memoInput[0].getAttribute('data-toolkit-save-behavior')) {
        $memoInput[0].setAttribute('data-toolkit-save-behavior', true);
        $memoInput.keydown(this.applyNewEnterBehavior);
      }

      if (!$outflowInput[0].getAttribute('data-toolkit-save-behavior')) {
        $outflowInput[0].setAttribute('data-toolkit-save-behavior', true);
        $outflowInput.keydown(this.applyNewEnterBehavior);
      }

      if (!$inflowInput[0].getAttribute('data-toolkit-save-behavior')) {
        $inflowInput[0].setAttribute('data-toolkit-save-behavior', true);
        $inflowInput.keydown(this.applyNewEnterBehavior);
      }
    }
  }, {
    key: 'applyNewEnterBehavior',
    value: function applyNewEnterBehavior(event) {
      if (event.keyCode === 13) {
        event.preventDefault();
        event.stopPropagation();

        var $saveButton = $('.ynab-grid-actions-buttons .button.button-primary:not(.button-another)');
        $saveButton.click();
      }
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (!changedNodes.has('ynab-grid-body')) return;

      if (this.shouldInvoke()) {
        this.invoke();
      }
    }
  }]);

  return ChangeEnterBehavior;
}(_feature.Feature);

/***/ }),
/* 360 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ClearSelection = undefined;

var _feature = __webpack_require__(2);

var _ember = __webpack_require__(13);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var ClearSelection = exports.ClearSelection = function (_Feature) {
  _inherits(ClearSelection, _Feature);

  function ClearSelection() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, ClearSelection);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = ClearSelection.__proto__ || Object.getPrototypeOf(ClearSelection)).call.apply(_ref, [this].concat(args))), _this), _this.uncheckTransactions = function () {
      var accountsController = (0, _ember.controllerLookup)('accounts');

      try {
        accountsController.get('areChecked').setEach('isChecked', 0);
        var gridHeader = (0, _ember.getEmberView)($('.ynab-grid-header').attr('id'));
        gridHeader.childViews[0].set('isChecked', false);
        accountsController.send('closeModal');
      } catch (e) {
        accountsController.send('closeModal');
        ynabToolKit.shared.showFeatureErrorModal('Clear Selection');
      }
    }, _this.observe = function (changedNodes) {
      if (changedNodes.has('ynab-u modal-popup modal-account-edit-transaction-list ember-view modal-overlay active')) {
        _this.invoke();
      }
    }, _this.invoke = function () {
      var menuText = ynabToolKit.l10nData && ynabToolKit.l10nData['toolkit.accountsClearSelection'] || 'Clear Selection';

      // Note that ${menuText} was intentionally placed on the same line as the <i> tag to
      // prevent the leading space that occurs as a result of using a multi-line string.
      // Using a dedent function would allow it to be placed on its own line which would be
      // more natural.
      //
      // The second <li> functions as a separator on the menu after the feature menu item.
      $('.modal-account-edit-transaction-list .modal-list').prepend($('<li>\n            <button class="button-list ynab-toolkit-clear-selection">\n              <i class="flaticon stroke minus-2"></i>' + menuText + '\n            </button>\n          </li>\n          <li><hr /><li>').click(function () {
        _this.uncheckTransactions();
      }));
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  return ClearSelection;
}(_feature.Feature);

/***/ }),
/* 361 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CustomFlagNames = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _toolkit = __webpack_require__(48);

var _ynab = __webpack_require__(6);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var flags = void 0;
var redFlagLabel = void 0;
var blueFlagLabel = void 0;
var orangeFlagLabel = void 0;
var yellowFlagLabel = void 0;
var greenFlagLabel = void 0;
var purpleFlagLabel = void 0;

var CustomFlagNames = exports.CustomFlagNames = function (_Feature) {
  _inherits(CustomFlagNames, _Feature);

  function CustomFlagNames() {
    _classCallCheck(this, CustomFlagNames);

    var _this = _possibleConstructorReturn(this, (CustomFlagNames.__proto__ || Object.getPrototypeOf(CustomFlagNames)).call(this));

    if (!(0, _toolkit.getToolkitStorageKey)('flags')) {
      _this.storeDefaultFlags();
    }
    if (typeof flags === 'undefined') {
      flags = JSON.parse((0, _toolkit.getToolkitStorageKey)('flags'));
      _this.updateFlagLabels();
    }
    return _this;
  }

  _createClass(CustomFlagNames, [{
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('account') !== -1;
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      $('.ynab-grid-cell-flag .ynab-flag-red').parent().attr('title', redFlagLabel);
      $('.ynab-grid-cell-flag .ynab-flag-blue').parent().attr('title', blueFlagLabel);
      $('.ynab-grid-cell-flag .ynab-flag-orange').parent().attr('title', orangeFlagLabel);
      $('.ynab-grid-cell-flag .ynab-flag-yellow').parent().attr('title', yellowFlagLabel);
      $('.ynab-grid-cell-flag .ynab-flag-green').parent().attr('title', greenFlagLabel);
      $('.ynab-grid-cell-flag .ynab-flag-purple').parent().attr('title', purpleFlagLabel);
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (!this.shouldInvoke()) return;

      if (changedNodes.has('layout user-logged-in') || changedNodes.has('ynab-grid-body')) {
        this.invoke();
      }

      if (changedNodes.has('ynab-u modal-popup modal-account-flags ember-view modal-overlay active')) {
        $('.ynab-flag-red .label, .ynab-flag-red .label-bg').text(redFlagLabel);
        $('.ynab-flag-blue .label, .ynab-flag-blue .label-bg').text(blueFlagLabel);
        $('.ynab-flag-orange .label, .ynab-flag-orange .label-bg').text(orangeFlagLabel);
        $('.ynab-flag-yellow .label, .ynab-flag-yellow .label-bg').text(yellowFlagLabel);
        $('.ynab-flag-green .label, .ynab-flag-green .label-bg').text(greenFlagLabel);
        $('.ynab-flag-purple .label, .ynab-flag-purple .label-bg').text(purpleFlagLabel);

        $('.modal-account-flags .modal').css({ height: '22em' }).append($('<div>', { id: 'account-flags-actions' }).css({ padding: '0 .3em' }).append($('<button>', { id: 'flags-edit', class: 'button button-primary' }).append('Edit ').append($('<i>', { class: 'flaticon stroke compose-3' }))));

        this.addEventListeners();
      }
    }
  }, {
    key: 'onRouteChanged',
    value: function onRouteChanged() {
      if (!this.shouldInvoke()) return;

      this.invoke();
    }
  }, {
    key: 'addEventListeners',
    value: function addEventListeners() {
      var $this = this;
      $('#flags-edit').click(function () {
        $('.modal-account-flags .modal-list').empty();

        for (var key in flags) {
          var flag = flags[key];

          $('.modal-account-flags .modal-list').append($('<li>').append($('<input>', {
            id: key, type: 'text', class: 'flag-input', value: flag.label, placeholder: flag.label
          }).css({
            color: '#fff', fill: flag.color, 'background-color': flag.color, height: 30, padding: '0 .7em', 'margin-bottom': '.3em', border: 'none'
          })));
        }

        $('#account-flags-actions').empty();

        $('#account-flags-actions').append($('<button>', { id: 'flags-close', class: 'button button-primary' }).append('Ok ').append($('<i>', { class: 'flaticon stroke checkmark-2' })));

        $('input.flag-input').focus(function () {
          $(this).css({
            color: '#000'
          });
        });

        $('input.flag-input').blur(function () {
          $(this).css({
            color: '#fff'
          });
          $this.saveFlag($(this));
        });

        $('#flags-close').click(function () {
          $('.modal-overlay').click();
        });
      });
    }
  }, {
    key: 'saveFlag',
    value: function saveFlag(flag) {
      if (flag.attr('placeholder') !== flag.val()) {
        var key = flag.attr('id');

        flags[key].label = flag.val();
        (0, _toolkit.setToolkitStorageKey)('flags', JSON.stringify(flags));

        this.updateFlagLabels();
        this.invoke();
      }
    }
  }, {
    key: 'updateFlagLabels',
    value: function updateFlagLabels() {
      redFlagLabel = flags.red.label;
      blueFlagLabel = flags.blue.label;
      orangeFlagLabel = flags.orange.label;
      yellowFlagLabel = flags.yellow.label;
      greenFlagLabel = flags.green.label;
      purpleFlagLabel = flags.purple.label;
    }
  }, {
    key: 'storeDefaultFlags',
    value: function storeDefaultFlags() {
      var flagsJSON = {
        red: {
          label: 'Red',
          color: '#d43d2e'
        },
        orange: {
          label: 'Orange',
          color: '#ff7b00'
        },
        yellow: {
          label: 'Yellow',
          color: '#f8e136'
        },
        green: {
          label: 'Green',
          color: '#9ac234'
        },
        blue: {
          label: 'Blue',
          color: '#0082cb'
        },
        purple: {
          label: 'Purple',
          color: '#9384b7'
        }
      };
      (0, _toolkit.setToolkitStorageKey)('flags', JSON.stringify(flagsJSON));
    }
  }]);

  return CustomFlagNames;
}(_feature.Feature);

/***/ }),
/* 362 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EasyTransactionApproval = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var EasyTransactionApproval = exports.EasyTransactionApproval = function (_Feature) {
  _inherits(EasyTransactionApproval, _Feature);

  function EasyTransactionApproval() {
    var _ref;

    var _temp, _this2, _ret;

    _classCallCheck(this, EasyTransactionApproval);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this2 = _possibleConstructorReturn(this, (_ref = EasyTransactionApproval.__proto__ || Object.getPrototypeOf(EasyTransactionApproval)).call.apply(_ref, [this].concat(args))), _this2), _this2.initBudgetVersion = true, _this2.initKeyLoop = true, _this2.initClickLoop = true, _this2.watchForKeys = false, _this2.selectedTransactions = undefined, _temp), _possibleConstructorReturn(_this2, _ret);
  }

  _createClass(EasyTransactionApproval, [{
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('account') !== -1;
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (!this.shouldInvoke()) return;

      // watch for the user potentially changing the budget
      if (this.initBudgetVersion) {
        this.addBudgetVersionIdObserver();
      }

      // watch for switch to Accounts section or selection change
      if (changedNodes.has('ynab-grid-body') || changedNodes.has('ynab-checkbox-button is-checked') || changedNodes.has('ynab-checkbox-button ')) {
        this.invoke();
      }

      // disable keydown watch on creation or editing of transactions
      if (changedNodes.has('accounts-toolbar-edit-transaction ember-view button button-disabled')) {
        this.watchForKeys = false;
      }
    }
  }, {
    key: 'addBudgetVersionIdObserver',
    value: function addBudgetVersionIdObserver() {
      var _this = this;

      var applicationController = ynabToolKit.shared.containerLookup('controller:application');
      applicationController.addObserver('budgetVersionId', function () {
        Ember.run.scheduleOnce('afterRender', this, function () {
          _this.initKeyLoop = true;
          _this.initClickLoop = true;
        });
      });
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      // get selected transactions
      this.selectedTransactions = undefined;
      var accountController = ynabToolKit.shared.containerLookup('controller:accounts');
      var visibleTransactionDisplayItems = accountController.get('visibleTransactionDisplayItems');
      this.selectedTransactions = visibleTransactionDisplayItems.filter(function (i) {
        return i.isChecked && i.get('accepted') === false;
      });

      // only watch for keydown if there are selected, unaccepted transactions
      if (this.selectedTransactions.length > 0) {
        this.watchForKeys = true;
      }

      // call watchForKeyInput() once
      if (this.initKeyLoop) {
        this.watchForKeyInput();
      }

      // call watchForRightClick() once
      if (this.initClickLoop) {
        this.watchForRightClick();
      }
    }
  }, {
    key: 'watchForKeyInput',
    value: function watchForKeyInput() {
      var _this = this;

      $('body').on('keydown', function (e) {
        if ((e.which === 13 || e.which === 65) && _this.watchForKeys) {
          // approve selected transactions when 'a' or 'enter is pressed'
          _this.approveTransactions();

          // disable keydown watch until selection is changed again
          _this.watchForKeys = false;
        }
      });

      // ensure that watchForKeyInput() is only called once
      this.initKeyLoop = false;
    }
  }, {
    key: 'watchForRightClick',
    value: function watchForRightClick() {
      var _this = this;

      // call approveTransactions if the notification 'i' icon is right clicked on
      Ember.run.next(function () {
        $('.ynab-grid').off('contextmenu', '.ynab-grid-body-row .ynab-grid-cell-notification button.transaction-notification-info', function (event) {
          // prevent defaults
          event.preventDefault();
          event.stopPropagation();

          // select row
          $(this).closest('.ynab-grid-body-row').find('.ynab-grid-cell-checkbox button:not(.is-checked)').click();

          // approve transactions
          _this.approveTransactions();
        });
        $('.ynab-grid').on('contextmenu', '.ynab-grid-body-row .ynab-grid-cell-notification button.transaction-notification-info', function (event) {
          // prevent defaults
          event.preventDefault();
          event.stopPropagation();

          // select row
          $(this).closest('.ynab-grid-body-row').find('.ynab-grid-cell-checkbox button:not(.is-checked)').click();

          // approve transactions
          _this.approveTransactions();
        });
      });

      // ensure that watchForRightClick() is only called once
      this.initClickLoop = false;
    }
  }, {
    key: 'approveTransactions',
    value: function approveTransactions() {
      // call 'c' keypress clearing and approving transaction using built in YNAB functionality
      var keycode = jQuery.Event('keydown'); // eslint-disable-line new-cap
      keycode.which = 67;
      keycode.keyCode = 67;
      $('body').trigger(keycode);

      // call 'c' keypress again, to reset clear state back to previous
      // completely separate event is needed, otherwise event doesn't fire properly the second time
      var keycode2 = jQuery.Event('keydown'); // eslint-disable-line new-cap
      keycode2.which = 67;
      keycode2.keyCode = 67;
      $('body').trigger(keycode2);

      // unselect transactions after approval
      $('.ynab-grid-body-row.is-checked').find('.ynab-grid-cell-checkbox button').click();
    }
  }]);

  return EasyTransactionApproval;
}(_feature.Feature);

/***/ }),
/* 363 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.AccountsEmphasizedOutflows = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var AccountsEmphasizedOutflows = exports.AccountsEmphasizedOutflows = function (_Feature) {
  _inherits(AccountsEmphasizedOutflows, _Feature);

  function AccountsEmphasizedOutflows() {
    _classCallCheck(this, AccountsEmphasizedOutflows);

    return _possibleConstructorReturn(this, (AccountsEmphasizedOutflows.__proto__ || Object.getPrototypeOf(AccountsEmphasizedOutflows)).apply(this, arguments));
  }

  _createClass(AccountsEmphasizedOutflows, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(364);
    }
  }]);

  return AccountsEmphasizedOutflows;
}(_feature.Feature);

/***/ }),
/* 364 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(365);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 365 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".ynab-grid-cell-outflow .currency::before {\n\tcontent: \"(\";\n}\n\n.ynab-grid-cell-outflow .currency::after {\n\tcontent: \")\";\n}\n\n.ynab-grid-cell-outflow .currency {\n\tcolor: #c00;\n}\n\n.ynab-grid-body-row.is-checked .ynab-grid-cell-outflow .currency {\n\tcolor: #ff4b2b;\n\tfont-weight: bold;\n}\n", ""]);

// exports


/***/ }),
/* 366 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.LargerClickableIcons = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var LargerClickableIcons = exports.LargerClickableIcons = function (_Feature) {
  _inherits(LargerClickableIcons, _Feature);

  function LargerClickableIcons() {
    _classCallCheck(this, LargerClickableIcons);

    return _possibleConstructorReturn(this, (LargerClickableIcons.__proto__ || Object.getPrototypeOf(LargerClickableIcons)).apply(this, arguments));
  }

  _createClass(LargerClickableIcons, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(367);
    }
  }]);

  return LargerClickableIcons;
}(_feature.Feature);

/***/ }),
/* 367 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(368);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 368 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".ynab-grid-body-row .ynab-grid-cell-cleared .flaticon {\n\twidth: 100%;\n\theight: 22px;\n}", ""]);

// exports


/***/ }),
/* 369 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.RightClickToEdit = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var RightClickToEdit = exports.RightClickToEdit = function (_Feature) {
  _inherits(RightClickToEdit, _Feature);

  function RightClickToEdit() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, RightClickToEdit);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = RightClickToEdit.__proto__ || Object.getPrototypeOf(RightClickToEdit)).call.apply(_ref, [this].concat(args))), _this), _this.isCurrentlyRunning = false, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(RightClickToEdit, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(370);
    }
  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('account') !== -1;
    }

    // Supporting functions,
    // or variables, etc

  }, {
    key: 'displayContextMenu',
    value: function displayContextMenu(event) {
      var $element = $(this);
      // check for a right click on a split transaction
      if ($element.hasClass('ynab-grid-body-sub')) {
        // select parent transaction
        $element = $element.prevAll('.ynab-grid-body-parent:first');
      }

      if (!$element.hasClass('is-checked')) {
        // clear existing, then check current
        $('.ynab-checkbox-button.is-checked').click();
        $element.find('.ynab-checkbox-button').click();
      }

      // make context menu appear
      $('.accounts-toolbar-edit-transaction').click();

      // determine if modal needs to be positioned above or below clicked element
      var height = $('.modal-account-edit-transaction-list .modal').outerHeight();
      var below = event.pageY + height > $(window).height() ? false : true; // eslint-disable-line no-unneeded-ternary
      var offset = $element.offset(); // move context menu

      if (below) {
        // position below
        $('.modal-account-edit-transaction-list .modal').addClass('modal-below').css('left', event.pageX - 115).css('top', offset.top + 41);
      } else {
        // position above
        $('.modal-account-edit-transaction-list .modal').addClass('modal-above').css('left', event.pageX - 115).css('top', offset.top - height - 8);
      }

      return false;
    }
  }, {
    key: 'hideContextMenu',
    value: function hideContextMenu() {
      return false; // ignore right clicks
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      this.isCurrentlyRunning = true;

      Ember.run.next(this, function () {
        $('.ynab-grid').off('contextmenu', '.ynab-grid-body-row', this.displayContextMenu);
        $('.ynab-grid').on('contextmenu', '.ynab-grid-body-row', this.displayContextMenu);

        $('body').off('contextmenu', '.modal-account-edit-transaction-list', this.hideContextMenu);
        $('body').on('contextmenu', '.modal-account-edit-transaction-list', this.hideContextMenu);

        this.isCurrentlyRunning = false;
      });
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (!this.shouldInvoke() || this.isCurrentlyRunning) return;

      if (changedNodes.has('ynab-grid-body')) {
        this.invoke();
      }
    }
  }]);

  return RightClickToEdit;
}(_feature.Feature);

/***/ }),
/* 370 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(371);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 371 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".modal-account-edit-transaction-list .modal-above .modal-arrow\n{\n\tbottom: auto !important;\n\ttop: 100% !important;\n\tborder-bottom-color: transparent !important;\n\tborder-top-color: #fff !important;\n}\n\n.modal-account-edit-transaction-list .modal-above li ul {\n\ttop: auto;\n\tbottom: -15px;\n}\n\n/* Fix arrow position in Firefox */\n.modal-account-edit-transaction-list .arrow-right-1,\n.modal-account-hide-column .arrow-right-1 {\n\tposition: absolute;\n\tright: 11px;\n\ttop: 4px;\n}\n", ""]);

// exports


/***/ }),
/* 372 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.RowHeight = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var RowHeight = exports.RowHeight = function (_Feature) {
  _inherits(RowHeight, _Feature);

  function RowHeight() {
    _classCallCheck(this, RowHeight);

    return _possibleConstructorReturn(this, (RowHeight.__proto__ || Object.getPrototypeOf(RowHeight)).apply(this, arguments));
  }

  _createClass(RowHeight, [{
    key: 'injectCSS',
    value: function injectCSS() {
      var css = __webpack_require__(373);

      if (this.settings.enabled === '1') {
        css += __webpack_require__(375);
      } else if (this.settings.enabled === '2') {
        css += __webpack_require__(377);
      }

      return css;
    }
  }]);

  return RowHeight;
}(_feature.Feature);

/***/ }),
/* 373 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(374);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 374 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".toolkit-modal-item-hide-image {\n    visibility: hidden;\n}\n\n.modal-adjust-row-height {\n    background-color: transparent;\n}\n\n.modal-adjust-row-height .modal {\n    padding:.3em 0;\n    width:10.5em;\n    font-size:.9em;\n}\n", ""]);

// exports


/***/ }),
/* 375 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(376);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 376 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".ynab-grid-header-cell {\n    height: 1.6em !important;\n\tpadding-top: 0.1em !important;\n}\n\n.ynab-grid-cell {\n\theight: 1.6em !important;\n\ttop: 0 !important;\n\tpadding-top: 0.1em !important;\n\tpadding-bottom: 0.1em !important;\n\t/*font-size: .850em !important;*/\n}\n\n.toolkit-ynab-grid-cell {\n\theight: 0px !important;\n}\n\n.ynab-grid-body-row {\n\theight: 1.8em !important;\n\ttop: 0 !important;\n\tpadding-top: 0.1em !important;\n}\n\n.ynab-grid-cell-checkbox\n.ynab-grid-cell-notification\n.ynab-grid-cell-flag\n.ynab-grid-cell-accountName\n.ynab-grid-cell-date\n.ynab-grid-cell-payeeName\n.ynab-grid-cell-subCategoryName\n.ynab-grid-cell-memo\n.ynab-grid-cell-outflow\n.ynab-grid-cell-inflow\n.ynab-grid-cell-cleared\n{\n\theight: 1.8em !important;\n\ttop: 0 !important;\n\tpadding-top: 0.1em !important;\n}\n\n.ynab-grid-actions {\n\theight: 2.2rem !important;\n}", ""]);

// exports


/***/ }),
/* 377 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(378);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 378 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".ynab-grid-header-cell {\n    height: 1.2em !important;\n\tpadding-top: 0.1em !important;\n}\n\n.ynab-grid-cell {\n\theight: 1.2em !important;\n\ttop: 0 !important;\n\tpadding-top: 0 !important;\n\tpadding-bottom: 0 !important;\n\tfont-size: .90em !important;\n}\n\n/*.ynab-grid-body-row-top.ynab-grid-cell {*/\n.toolkit-ynab-grid-cell {\n\theight: 0px !important;\n}\n\n.ynab-grid-body-row {\n\theight: 1.4em !important;\n\ttop: 0 !important;\n\tpadding-top: 0 !important;\n}\n\n.ynab-grid-cell-checkbox\n.ynab-grid-cell-notification\n.ynab-grid-cell-flag\n.ynab-grid-cell-accountName\n.ynab-grid-cell-date\n.ynab-grid-cell-payeeName\n.ynab-grid-cell-subCategoryName\n.ynab-grid-cell-memo\n.ynab-grid-cell-outflow\n.ynab-grid-cell-inflow\n.ynab-grid-cell-cleared\n{\n\theight: 1.4em !important;\n\ttop: 0 !important;\n\tpadding-top: 0.1em !important;\n}\n\n.ynab-grid-actions {\n\theight: 2.2rem !important;\n}", ""]);

// exports


/***/ }),
/* 379 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ShowCategoryBalance = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

var _date = __webpack_require__(380);

var _ember = __webpack_require__(13);

var _currency = __webpack_require__(136);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var ShowCategoryBalance = exports.ShowCategoryBalance = function (_Feature) {
  _inherits(ShowCategoryBalance, _Feature);

  function ShowCategoryBalance() {
    _classCallCheck(this, ShowCategoryBalance);

    return _possibleConstructorReturn(this, (ShowCategoryBalance.__proto__ || Object.getPrototypeOf(ShowCategoryBalance)).apply(this, arguments));
  }

  _createClass(ShowCategoryBalance, [{
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('account') !== -1;
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      (0, _ynab.getAllBudgetMonthsViewModel)().then(function (allBudgetMonthsViewModel) {
        var subCategoryCalculations = allBudgetMonthsViewModel.get('monthlySubCategoryBudgetCalculationsCollection');
        var categoryLookupPrefix = 'mcbc/' + (0, _date.getCurrentDate)('YYYY-MM');

        var GridSubComponent = (0, _ember.componentLookup)('register/grid-sub');
        GridSubComponent.constructor.reopen({
          didRender: function didRender() {
            _didRender.call(this, subCategoryCalculations, categoryLookupPrefix);
          }
        });

        var GridRowComponent = (0, _ember.componentLookup)('register/grid-row');
        GridRowComponent.constructor.reopen({
          didRender: function didRender() {
            _didRender.call(this, subCategoryCalculations, categoryLookupPrefix);
          }
        });

        var GridScheduledComponent = (0, _ember.componentLookup)('register/grid-scheduled');
        GridScheduledComponent.constructor.reopen({
          didRender: function didRender() {
            _didRender.call(this, subCategoryCalculations, categoryLookupPrefix);
          }
        });
      });
    }
  }, {
    key: 'onRouteChanged',
    value: function onRouteChanged() {
      if (!this.shouldInvoke()) return;

      this.invoke();
    }
  }]);

  return ShowCategoryBalance;
}(_feature.Feature);

function _didRender(subCategoryCalculations, categoryLookupPrefix) {
  var element = this.get('element');
  var subCategoryId = this.get('content.subCategoryId');
  var budgetData = subCategoryCalculations.findItemByEntityId(categoryLookupPrefix + '/' + subCategoryId);

  // if there's no budget data (could be an income/credit category) skip it.
  if (!budgetData) return;

  var title = $('.ynab-grid-cell-subCategoryName', element).attr('title');
  var newTitle = title + ' (Balance: ' + (0, _currency.formatCurrency)(budgetData.get('balance')) + ')';
  $('.ynab-grid-cell-subCategoryName', element).attr('title', newTitle);
}

/***/ }),
/* 380 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getCurrentDate = getCurrentDate;
function getCurrentDate(format) {
  return ynabDate(format, false);
}

function ynabDate(format) {
  if (typeof format !== 'string') {
    return ynab.YNABSharedLib.dateFormatter.formatDate();
  }

  return ynab.YNABSharedLib.dateFormatter.formatDate(moment(), format);
}

/***/ }),
/* 381 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SpareChange = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

var _ember = __webpack_require__(13);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var SpareChange = exports.SpareChange = function (_Feature) {
  _inherits(SpareChange, _Feature);

  function SpareChange() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, SpareChange);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = SpareChange.__proto__ || Object.getPrototypeOf(SpareChange)).call.apply(_ref, [this].concat(args))), _this), _this.currentlyRunning = false, _this.applicationController = null, _this.accountsController = null, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(SpareChange, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(382);
    }
  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('account') > -1;
    }

    // invoke has potential of being pretty processing heavy (needing to sort content, then update calculation for every row)
    // wrapping it in a debounce means that if the user continuously scrolls down we won't clog up the event loop.

  }, {
    key: 'invoke',
    value: function invoke() {
      if (!this.shouldInvoke()) {
        return;
      }

      this.currentlyRunning = true;

      if (this.applicationController === null) {
        this.applicationController = (0, _ember.controllerLookup)('application');
      }

      if (this.accountsController === null) {
        this.accountsController = (0, _ember.controllerLookup)('accounts');
      }

      Ember.run.debounce(this, function () {
        this.accountsController.addObserver('areChecked', this, 'onYnabSelectionChanged');

        if ((0, _ynab.getCurrentRouteName)().indexOf('accounts') > -1) {
          if (this.applicationController.get('selectedAccountId')) {
            this.onYnabGridyBodyChanged();
          } else {
            this.removeHeader();
          }
        }

        this.currentlyRunning = false;
      }, 250);
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (!this.shouldInvoke() || this.currentlyRunning) {
        return;
      }

      if (changedNodes.has('ynab-grid-body')) {
        this.invoke();
      }
    }
  }, {
    key: 'setSelectedTransactions',
    value: function setSelectedTransactions() {
      var visibleTransactionDisplayItems = this.accountsController.get('visibleTransactionDisplayItems');
      this.selectedTransactions = visibleTransactionDisplayItems.filter(function (i) {
        return i.isChecked && i.get('outflow');
      });
    }
  }, {
    key: 'getSelectedAccount',
    value: function getSelectedAccount() {
      var selectedAccountId = this.applicationController.get('selectedAccountId');

      if (selectedAccountId) {
        var selectedAccounts = this.accountsController.get('activeAccounts');
        var selectedAccount = selectedAccounts.find(function (a) {
          return a.itemId === selectedAccountId;
        });

        return selectedAccount;
      }

      return null;
    }
  }, {
    key: 'updateSpareChangeCalculation',
    value: function updateSpareChangeCalculation() {
      var i = void 0;
      var transaction = void 0;
      var runningSpareChange = 0;

      var selectedAccount = this.getSelectedAccount();
      if (selectedAccount) {
        for (i = 0; i < this.selectedTransactions.length; i++) {
          transaction = this.selectedTransactions[i];

          if (transaction.get('outflow')) {
            var amount = ynab.convertFromMilliDollars(transaction.get('outflow'));
            var nextDollar = Math.ceil(amount);
            var spareChangeForThisRow = nextDollar - amount;
            runningSpareChange += ynab.convertToMilliDollars(spareChangeForThisRow);
          }

          selectedAccount.__ynabToolKitSpareChange = runningSpareChange;
        }
      }
    }
  }, {
    key: 'updateSpareChangeHeader',
    value: function updateSpareChangeHeader() {
      if (this.selectedTransactions.length > 0) {
        this.insertHeader();
        this.updateValue();
      } else {
        this.removeHeader();
      }
    }
  }, {
    key: 'insertHeader',
    value: function insertHeader() {
      // remove existing
      $('.ynab-toolkit-accounts-header-balances-spare-change').remove();

      // build spare change div
      var spareChangeDiv = $('<div />').addClass('ynab-toolkit-accounts-header-balances-spare-change');
      var spareChangeAmount = $('<span />').addClass('user-data');
      var spareChangeTitle = $('<div />').addClass('accounts-header-balances-label').attr('title', 'The selected items "spare change" when rounded up to the nearest dollar.').text('Spare Change');
      var currencySpan = $('<span />').addClass('user-data currency');

      spareChangeAmount.append(currencySpan);
      spareChangeDiv.append(spareChangeTitle);
      spareChangeDiv.append(spareChangeAmount);

      // insert
      $('.accounts-header-balances-right').prepend(spareChangeDiv);
    }
  }, {
    key: 'removeHeader',
    value: function removeHeader() {
      $('.ynab-toolkit-accounts-header-balances-spare-change').remove();
    }
  }, {
    key: 'updateValue',
    value: function updateValue() {
      var selectedAccount = this.getSelectedAccount();
      if (selectedAccount) {
        var spareChange = selectedAccount.__ynabToolKitSpareChange;

        var spareChangeHeader = $('.ynab-toolkit-accounts-header-balances-spare-change');
        var spareChangeAmount = $('.user-data:not(.currency)', spareChangeHeader);
        var currencySpan = $('.user-data.currency', spareChangeHeader);

        currencySpan.removeClass('negative positive zero');

        if (spareChange < 0) {
          currencySpan.addClass('negative');
        } else if (spareChange > 0) {
          currencySpan.addClass('positive');
        } else {
          currencySpan.addClass('zero');
        }

        var formatted = ynabToolKit.shared.formatCurrency(spareChange);
        spareChangeAmount.attr('title', formatted.string);

        var formattedHtml = formatted.string.replace(/\$/g, '<bdi>$</bdi>');
        currencySpan.html(formattedHtml);
      }
    }
  }, {
    key: 'onYnabGridyBodyChanged',
    value: function onYnabGridyBodyChanged() {
      Ember.run.debounce(this, function () {
        this.setSelectedTransactions();
        this.updateSpareChangeCalculation();
        this.updateSpareChangeHeader();
      }, 250);
    }
  }, {
    key: 'onYnabSelectionChanged',
    value: function onYnabSelectionChanged() {
      this.selectedTransactions = undefined;
      this.onYnabGridyBodyChanged();
    }
  }]);

  return SpareChange;
}(_feature.Feature);

/***/ }),
/* 382 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(383);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 383 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".ynab-toolkit-accounts-header-balances-spare-change {\n\t-webkit-box-flex: 1;\n    -moz-box-flex: 1;\n    -o-box-flex: 1;\n    box-flex: 1;\n    -webkit-flex: 0 1 auto;\n    -ms-flex: 0 1 auto;\n    flex: 0 1 auto;\n\n    height: 3.75em;\n    padding-top: .75em;\n    padding-right: 1rem;\n    margin-right: 1rem;\n    border-right: 1px solid #0e414c;\n    overflow: hidden;\n\n    text-align: center;\n    color: #5bbe72;\n}\n", ""]);

// exports


/***/ }),
/* 384 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SplitKeyboardShortcut = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var BUDGET_CATEGORIES_DROPDOWN_NODE = 'ynab-u modal-popup modal-account-dropdown modal-account-categories ember-view modal-overlay active';

var SplitKeyboardShortcut = exports.SplitKeyboardShortcut = function (_Feature) {
  _inherits(SplitKeyboardShortcut, _Feature);

  function SplitKeyboardShortcut() {
    _classCallCheck(this, SplitKeyboardShortcut);

    return _possibleConstructorReturn(this, (SplitKeyboardShortcut.__proto__ || Object.getPrototypeOf(SplitKeyboardShortcut)).apply(this, arguments));
  }

  _createClass(SplitKeyboardShortcut, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(385);
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if ((0, _ynab.getCurrentRouteName)().indexOf('account') !== -1) {
        if (changedNodes.has(BUDGET_CATEGORIES_DROPDOWN_NODE)) {
          var splitButton = $('.button.button-primary.modal-account-categories-split-transaction');

          // return if we are already inside a split subtransaction
          if (splitButton.length < 1) return false;

          var splitIcon = splitButton.html();
          var categoryList = $('.modal-account-categories .modal-list');
          var liElement = $('<li class="user-data">\n                              <button class="button-list">\n                                <div class="modal-account-categories-category" title="Split Transaction">\n                                  <span class="modal-account-categories-category-name"></span>\n                                </div>\n                              </button>\n                            </li>');

          liElement.find('.modal-account-categories-category-name').html(splitIcon);
          categoryList.append('<li class="user-data"><strong class="modal-account-categories-section-item">Actions:</strong></li>');
          categoryList.append(liElement);

          $('.ynab-grid-cell-subCategoryName input').on('keydown', function (e) {
            if (e.which === 13 || e.which === 9) {
              // Enter or Tab
              if (liElement.find('.button-list').hasClass('is-highlighted')) {
                e.preventDefault();
                splitButton.click();
              }
            }
          }).on('keyup', function () {
            var categoryInputString = new RegExp('^' + $(this).val());
            if (categoryInputString.test('split') && categoryList.find('li').length === 3) {
              // highlight new split button if input contains part of
              // 'split' and there are no other categories available
              categoryList.addClass('toolkit-hide-firstchild');
              liElement.find('.button-list').addClass('is-highlighted');
            } else {
              categoryList.removeClass('toolkit-hide-firstchild');
              liElement.find('.button-list').removeClass('is-highlighted');
            }
          });

          liElement.on('click', function () {
            splitButton.click();
          });
        }
      }
    }
  }]);

  return SplitKeyboardShortcut;
}(_feature.Feature);

/***/ }),
/* 385 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(386);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 386 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".modal-list.toolkit-hide-firstchild li:first-child {\n\tdisplay: none !important;\n}", ""]);

// exports


/***/ }),
/* 387 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SplitTransactionAutoAdjust = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var SplitTransactionAutoAdjust = exports.SplitTransactionAutoAdjust = function (_Feature) {
  _inherits(SplitTransactionAutoAdjust, _Feature);

  function SplitTransactionAutoAdjust() {
    _classCallCheck(this, SplitTransactionAutoAdjust);

    return _possibleConstructorReturn(this, (SplitTransactionAutoAdjust.__proto__ || Object.getPrototypeOf(SplitTransactionAutoAdjust)).apply(this, arguments));
  }

  _createClass(SplitTransactionAutoAdjust, [{
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('account') !== -1;
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      this.addAnotherSplit = null;
      this.splitTransactionRow = null;
      this.isInitialized = false;
      this.addingAnotherSplit = false;
      this.deletingSplit = false;
    }
  }, {
    key: 'initialize',
    value: function initialize() {
      this.splitTransactionRow = $('.ynab-grid-add-rows');
      this.addAnotherSplit = $('.ynab-grid-split-add-sub-transaction');

      this.splitTransactionRow.on('keyup', '.currency-input .ember-text-field', this, this.onKeyPress);
      this.splitTransactionRow.on('click', '.ynab-grid-sub-remove', this.onDeleteSplit);
      this.addAnotherSplit.on('click', this.onAddAnotherSplit);
    }
  }, {
    key: 'onKeyPress',
    value: function onKeyPress(event) {
      var _this = event.data;
      var element = $(this);
      var currentInputClass = _this.getCurrentInputClass();

      if ($(element).parents(currentInputClass).length) {
        _this.autoFillNextRow(element);
      }
    }
  }, {
    key: 'getCurrentInputClass',
    value: function getCurrentInputClass() {
      var firstRow = $('.ynab-grid-body-row', this.splitTransactionRow).first();
      var outflowValue = ynab.unformat($('.ynab-grid-cell-outflow .ember-text-field', firstRow).val());
      var inflowValue = ynab.unformat($('.ynab-grid-cell-inflow .ember-text-field', firstRow).val());
      return outflowValue > 0 ? '.ynab-grid-cell-outflow' : inflowValue > 0 ? '.ynab-grid-cell-inflow' : false;
    }
  }, {
    key: 'onAddAnotherSplit',
    value: function onAddAnotherSplit() {
      this.addingAnotherSplit = true;
    }
  }, {
    key: 'onDeleteSplit',
    value: function onDeleteSplit() {
      this.deletingSplit = true;
    }
  }, {
    key: 'autoFillNextRow',
    value: function autoFillNextRow(currentInputElement) {
      var inputClass = this.getCurrentInputClass();
      var total = ynab.unformat($(inputClass + ' .ember-text-field', this.splitTransactionRow.children().eq(0)).val()) * 1000;
      // local version of the class variable to get around the 'this' issue in the .each() function below.
      var splitTransactionRow = this.splitTransactionRow;

      if (inputClass && total) {
        var currentRow = $(currentInputElement).parents('.ynab-grid-body-row');
        var currentRowIndex = splitTransactionRow.children().index(currentRow);
        var currentValue = ynab.unformat($(currentInputElement).val()) * 1000;

        splitTransactionRow.children().each(function (index, splitRow) {
          if (index === currentRowIndex) {
            var nextRow = splitTransactionRow.children().eq(currentRowIndex + 1);
            if (index === 0) {
              $(inputClass + ' .ember-text-field', nextRow).val(ynab.formatCurrency(total));
              $(inputClass + ' .ember-text-field', nextRow).trigger('change');
            } else {
              total -= currentValue;
              $(inputClass + ' .ember-text-field', nextRow).val(ynab.formatCurrency(total));
              $(inputClass + ' .ember-text-field', nextRow).trigger('change');
            }
          } else if (index < currentRowIndex) {
            if (index !== 0) {
              // don't decrement total if we're the total row, that's silly
              total -= ynab.unformat($(inputClass + ' .ember-text-field', splitRow).val()) * 1000;
            }
          }
        });
      }
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (!this.shouldInvoke()) return;

      var addTransactionSplit = changedNodes.has('button button-primary modal-account-categories-split-transaction');
      var editSplitTransaction = changedNodes.has('ynab-grid-body-row ynab-grid-body-split is-editing');
      var splitTransactionNodeChanged = addTransactionSplit && !editSplitTransaction;
      var splitTransactionButton = $('.ynab-grid-split-add-sub-transaction').length !== 0;

      if (this.addingAnotherSplit) {
        this.addingAnotherSplit = false;

        var inputClass = this.getCurrentInputClass();
        var currentLastSplitRow = $('.ynab-grid-body-sub', this.splitTransactionRow).eq(-2);
        var lastSplitInput = $(inputClass + ' .ember-text-field', currentLastSplitRow)[0];

        this.autoFillNextRow(lastSplitInput);
      } else if (this.deletingSplit) {
        this.deletingSplit = false;
      } else if (splitTransactionNodeChanged) {
        if (splitTransactionButton) {
          if (!this.isInitialized) {
            this.isInitialized = true;
            this.initialize();
          }
        } else {
          this.isInitialized = false;
        }
      }
    }
  }]);

  return SplitTransactionAutoAdjust;
}(_feature.Feature);

/***/ }),
/* 388 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.AccountsStripedRows = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var AccountsStripedRows = exports.AccountsStripedRows = function (_Feature) {
  _inherits(AccountsStripedRows, _Feature);

  function AccountsStripedRows() {
    _classCallCheck(this, AccountsStripedRows);

    return _possibleConstructorReturn(this, (AccountsStripedRows.__proto__ || Object.getPrototypeOf(AccountsStripedRows)).apply(this, arguments));
  }

  _createClass(AccountsStripedRows, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(389);
    }
  }]);

  return AccountsStripedRows;
}(_feature.Feature);

/***/ }),
/* 389 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(390);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 390 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, "/* Maybe this should play better with reconciled rows that don't have a background-color */\n.ynab-grid .ynab-grid-body-row:nth-of-type(even):not(.is-scheduled):not(.is-checked):not(.is-editing):not(.ynab-grid-body-empty):not(.ynab-grid-actions) {\n\tbackground-color: #fafafa;\n}\n", ""]);

// exports


/***/ }),
/* 391 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SwapClearedFlagged = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var SwapClearedFlagged = exports.SwapClearedFlagged = function (_Feature) {
  _inherits(SwapClearedFlagged, _Feature);

  function SwapClearedFlagged() {
    _classCallCheck(this, SwapClearedFlagged);

    return _possibleConstructorReturn(this, (SwapClearedFlagged.__proto__ || Object.getPrototypeOf(SwapClearedFlagged)).apply(this, arguments));
  }

  _createClass(SwapClearedFlagged, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(392);
    }
  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('account') > -1;
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      var flags = $('.ynab-grid-cell-flag');
      var cleared = $('.ynab-grid-cell-cleared');

      for (var i = 0; i < flags.length; i += 1) {
        // If not swapped
        if (this.getChildNumber(cleared[i]) - this.getChildNumber(flags[i]) > 0) {
          this.swapElements(flags[i], cleared[i]);
        }
      }
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (!this.shouldInvoke()) {
        return;
      }

      if (changedNodes.has('ynab-grid-body')) {
        this.invoke();
      }
    }
  }, {
    key: 'swapElements',
    value: function swapElements(elm1, elm2) {
      var parent1 = elm1.parentNode;
      var next1 = elm1.nextSibling;
      var parent2 = elm2.parentNode;
      var next2 = elm2.nextSibling;

      parent1.insertBefore(elm2, next1);
      parent2.insertBefore(elm1, next2);
    }
  }, {
    key: 'getChildNumber',
    value: function getChildNumber(node) {
      return Array.prototype.indexOf.call(node.parentNode.childNodes, node);
    }
  }]);

  return SwapClearedFlagged;
}(_feature.Feature);

/***/ }),
/* 392 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(393);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 393 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".ynab-grid-body-row.is-editing {\n\tbackground-color: #00596f !important;\n}\n\n.ynab-grid-cell.ynab-grid-cell-flag {\n\tposition: relative;\n}\n\n.ynab-grid-cell.ynab-grid-cell-flag .ynab-grid-actions {\n\tfont-size: .875em;\n}\n", ""]);

// exports


/***/ }),
/* 394 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ToggleSplits = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

var _ember = __webpack_require__(13);

var _toolkit = __webpack_require__(48);

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function isNotSubTransaction(transaction) {
  var displayItemType = transaction.get('displayItemType');
  return displayItemType !== ynab.constants.TransactionDisplayItemType.SubTransaction && displayItemType !== ynab.constants.TransactionDisplayItemType.ScheduledSubTransaction;
}

var ToggleSplits = exports.ToggleSplits = function (_Feature) {
  _inherits(ToggleSplits, _Feature);

  _createClass(ToggleSplits, [{
    key: 'idName',
    get: function get() {
      return 'toggle-splits';
    }
  }]);

  function ToggleSplits() {
    _classCallCheck(this, ToggleSplits);

    var _this = _possibleConstructorReturn(this, (ToggleSplits.__proto__ || Object.getPrototypeOf(ToggleSplits)).call(this));

    _this.expanded = false;
    return _this;
  }

  _createClass(ToggleSplits, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(395);
    }
  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('account') !== -1 && !$('#' + this.idName).length;
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      var _this2 = this;

      this.accountsController = (0, _ember.controllerLookup)('accounts');

      var buttonText = (0, _toolkit.i10n)('toolkit.toggleSplits', 'Toggle Splits');
      this.$button = $('<button>', { id: this.idName, class: 'ember-view button' }).append($('<i>', { class: 'ember-view flaticon stroke right' }).toggle(!this.expanded)).append($('<i>', { class: 'ember-view flaticon stroke down' }).toggle(this.expanded)).append(buttonText).insertAfter('.accounts-toolbar .undo-redo-container');

      $('.accounts-toolbar-left').addClass('toolkit-accounts-toolbar-left');

      this.$button.click(function () {
        return _this2.toggle();
      });

      // Only want to wrap contentResults once
      if (typeof this.accountsController.get('toolkitShowSubTransactions') === 'undefined') {
        var _Ember;

        var ynabContentResults = this.accountsController.contentResults;
        this.accountsController.reopen({
          toolkitShowSubTransactions: this.expanded,
          toolkitShowSubTransactionsChanged: Ember.observer('toolkitShowSubTransactions', function () {
            var _this3 = this;

            Ember.run.debounce(function () {
              _this3.notifyPropertyChange('contentResults');
            }, 25);
          }),
          contentResults: (_Ember = Ember).computed.apply(_Ember, _toConsumableArray(ynabContentResults._dependentKeys).concat([{
            get: function get() {
              var contentResults = ynabContentResults._getter.apply(this);
              if (!this.get('toolkitShowSubTransactions')) {
                contentResults = contentResults.filter(isNotSubTransaction);
              }
              return contentResults;
            },
            set: function set(_key, val) {
              return val;
            }
          }]))
        });
      }

      // Trigger default state
      this.accountsController.notifyPropertyChange('contentResults');
    }
  }, {
    key: 'onserve',
    value: function onserve(changedNodes) {
      if (changedNodes.has('ynab-grid-body') && this.shouldInvoke()) {
        this.invoke();
      }
    }
  }, {
    key: 'onRouteChanged',
    value: function onRouteChanged() {
      if (this.shouldInvoke()) {
        this.invoke();
      }
    }
  }, {
    key: 'toggle',
    value: function toggle() {
      this.accountsController.set('toolkitShowSubTransactions', this.expanded = !this.expanded);
      $('> i', this.$button).toggle();
    }
  }]);

  return ToggleSplits;
}(_feature.Feature);

/***/ }),
/* 395 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(396);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 396 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".toolkit-accounts-toolbar-left {\n\twidth: auto !important;\n}\n  ", ""]);

// exports


/***/ }),
/* 397 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ToggleTransactionFilters = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

var _ember = __webpack_require__(13);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var ToggleTransactionFilters = exports.ToggleTransactionFilters = function (_Feature) {
  _inherits(ToggleTransactionFilters, _Feature);

  function ToggleTransactionFilters() {
    _classCallCheck(this, ToggleTransactionFilters);

    return _possibleConstructorReturn(this, (ToggleTransactionFilters.__proto__ || Object.getPrototypeOf(ToggleTransactionFilters)).apply(this, arguments));
  }

  _createClass(ToggleTransactionFilters, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(398);
    }
  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('account') > -1;
    }
  }, {
    key: 'onRouteChanged',
    value: function onRouteChanged() {
      if (!this.shouldInvoke()) return;

      this.invoke();
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      // create or update buttons
      this.initToggleButtons();
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (!this.shouldInvoke()) return;

      // activate button styles if filters potentially change
      // activate if switch to individual account, or all accounts views
      if (changedNodes.has('modal-overlay ynab-u modal-generic modal-account-filters active closing') || changedNodes.has('ynab-grid-body')) {
        this.initToggleButtons();
      }
    }
  }, {
    key: 'toggleReconciled',
    value: function toggleReconciled() {
      var container = (0, _ember.controllerLookup)('accounts');
      var settingReconciled = !container.filters.get('reconciled');
      container.filters.get('propertiesToSet').setProperties({ reconciled: settingReconciled });
      container.filters.applyFilters();

      if (settingReconciled) {
        $('#toolkit-toggleReconciled').removeClass('toolkit-button-toggle-hidden').addClass('toolkit-button-toggle-visible');
      } else {
        $('#toolkit-toggleReconciled').addClass('toolkit-button-toggle-hidden').removeClass('toolkit-button-toggle-visible');
      }
    }
  }, {
    key: 'toggleScheduled',
    value: function toggleScheduled() {
      var container = (0, _ember.controllerLookup)('accounts');
      var settingScheduled = !container.filters.get('scheduled');
      container.filters.get('propertiesToSet').setProperties({ scheduled: settingScheduled });
      container.filters.applyFilters();

      if (settingScheduled) {
        $('#toolkit-toggleScheduled').removeClass('toolkit-button-toggle-hidden').addClass('toolkit-button-toggle-visible');
      } else {
        $('#toolkit-toggleScheduled').addClass('toolkit-button-toggle-hidden').removeClass('toolkit-button-toggle-visible');
      }
    }
  }, {
    key: 'updateToggleButtons',
    value: function updateToggleButtons(settingReconciled, settingScheduled) {
      // set button classes
      if (settingReconciled) {
        $('#toolkit-toggleReconciled').removeClass('toolkit-button-toggle-hidden').addClass('toolkit-button-toggle-visible');
      } else {
        $('#toolkit-toggleReconciled').addClass('toolkit-button-toggle-hidden').removeClass('toolkit-button-toggle-visible');
      }

      if (settingScheduled) {
        $('#toolkit-toggleScheduled').removeClass('toolkit-button-toggle-hidden').addClass('toolkit-button-toggle-visible');
      } else {
        $('#toolkit-toggleScheduled').addClass('toolkit-button-toggle-hidden').removeClass('toolkit-button-toggle-visible');
      }
    }
  }, {
    key: 'initToggleButtons',
    value: function initToggleButtons() {
      var _this2 = this;

      // get internal filters
      var container = (0, _ember.controllerLookup)('accounts');
      var settingReconciled = container.filters.get('reconciled');
      var settingScheduled = container.filters.get('scheduled');

      // insert or edit buttons
      if (!$('#toolkit-toggleReconciled').length) {
        // create buttons if they don't already exist
        $('.accounts-toolbar .accounts-toolbar-right').append($('<button>', { id: 'toolkit-toggleReconciled', class: 'button', title: 'Toggle Reconciled Transactions' }).append($('<i>', { class: 'flaticon solid lock-1 is-reconciled' })
        // show both text and icons or just the icon
        .append(this.settings.enabled === '2' ? ' Reconciled' : '').click(function () {
          _this2.toggleReconciled();
        })));
        $('.accounts-toolbar .accounts-toolbar-right').append($('<button>', { id: 'toolkit-toggleScheduled', class: 'button', title: 'Toggle Scheduled Transactions' }).append($('<i>', { class: 'flaticon solid clock-1 is-reconciled' })
        // show both text and icons or just the icon
        .append(this.settings.enabled === '2' ? ' Scheduled' : '').click(function () {
          _this2.toggleScheduled();
        })));

        this.updateToggleButtons(settingReconciled, settingScheduled);
      } else {
        // if buttons exist, double check visibility classes
        this.updateToggleButtons(settingReconciled, settingScheduled);
      }
    }
  }]);

  return ToggleTransactionFilters;
}(_feature.Feature);

/***/ }),
/* 398 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(399);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 399 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, "#toolkit-toggleReconciled.button-icononly {\n\tmargin-right: 1px;\n}\n#toolkit-toggleScheduled .flaticon {\n    margin-right: 1px;\n}\n\n/* label */\n.accounts-toolbar-right .toolkit-label {\n\tdisplay: block;\n\theight: 2.2em;\n\tpadding: .55em .6em;\n\tfloat: right;\n\n\tfont-size: 1em;\n\tline-height: normal;\n\tfont-weight: normal;\n\tfont-style: italic;\n\tcolor: #003540;\n}\n\n/* visible: mid blue */\n.accounts-toolbar .toolkit-button-toggle-visible,\n.accounts-toolbar .toolkit-button-toggle-visible:hover {\n\tfont-weight: bold;\n\tcolor: #009cc2 !important;\n}\n.accounts-toolbar .toolkit-button-toggle-visible .flaticon,\n.accounts-toolbar .toolkit-button-toggle-visible:hover .flaticon {\n\tcolor: #009cc2 !important;\n}\n\n/* hidden: gray */\n.accounts-toolbar .toolkit-button-toggle-hidden {\n\tfont-weight: bold;\n\tcolor: #c3cbce;\n}\n.toolkit-button-toggle-hidden .flaticon {\n\tcolor: #c3cbce;\n}\n.accounts-toolbar .toolkit-button-toggle-hidden:hover,\n.accounts-toolbar .toolkit-button-toggle-hidden:hover .flaticon {\n\tcolor: #c3cbce !important;\n}\n", ""]);

// exports


/***/ }),
/* 400 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.TransactionGridFeatures = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _feature2 = __webpack_require__(70);

var _runningBalance = __webpack_require__(401);

var _checkNumbers = __webpack_require__(406);

var _reconciledTextColor = __webpack_require__(409);

var _ember = __webpack_require__(13);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var TransactionGridFeatures = exports.TransactionGridFeatures = function (_Feature) {
  _inherits(TransactionGridFeatures, _Feature);

  function TransactionGridFeatures() {
    var _ref;

    var _temp, _this2, _ret;

    _classCallCheck(this, TransactionGridFeatures);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this2 = _possibleConstructorReturn(this, (_ref = TransactionGridFeatures.__proto__ || Object.getPrototypeOf(TransactionGridFeatures)).call.apply(_ref, [this].concat(args))), _this2), _this2.features = [ynabToolKit.options.CheckNumbers ? new _checkNumbers.CheckNumbers() : new _feature2.TransactionGridFeature(), ynabToolKit.options.RunningBalance !== '0' ? new _runningBalance.RunningBalance() : new _feature2.TransactionGridFeature(), ynabToolKit.options.ReconciledTextColor !== '0' ? new _reconciledTextColor.ReconciledTextColor() : new _feature2.TransactionGridFeature()], _temp), _possibleConstructorReturn(_this2, _ret);
  }

  _createClass(TransactionGridFeatures, [{
    key: 'injectCSS',
    value: function injectCSS() {
      var css = this.features.reduce(function (allCSS, feature) {
        allCSS += feature.injectCSS();
        return allCSS;
      }, '');

      return css;
    }
  }, {
    key: 'willInvoke',
    value: function willInvoke() {
      // any of the components added here must be loaded when YNAB loads. if they
      // are not available in the cache, this feature will crash. move them to
      // invoke function if that is the case.
      this.attachWillInsertHandler('register/grid-sub');
      this.attachWillInsertHandler('register/grid-row');
      this.attachWillInsertHandler('register/grid-scheduled');
      this.attachWillInsertHandler('register/grid-scheduled-sub');
      this.attachWillInsertHandler('register/grid-actions');
      this.attachWillInsertHandler('register/grid-split');

      var accountsController = (0, _ember.controllerLookup)('accounts');
      accountsController.notifyPropertyChange('contentResults');

      return Promise.all(this.features.map(function (feature) {
        return feature.willInvoke();
      }));
    }

    // we always want to invoke this feature if it's enabled because we want
    // to at least initialize running balance on all of the accounts

  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return this.features.some(function (feature) {
        return feature.shouldInvoke();
      });
    }
  }, {
    key: 'attachWillInsertHandler',
    value: function attachWillInsertHandler(componentName) {
      var _this = this;
      var GridComponent = (0, _ember.componentLookup)(componentName);

      if (GridComponent.__toolkitInitialized) {
        return;
      }

      try {
        GridComponent.constructor.reopen({
          didUpdate: function didUpdate() {
            var _this3 = this;

            _this.features.forEach(function (feature) {
              if (feature.shouldInvoke()) {
                feature.didUpdate.call(_this3);
              }
            });
          },
          willInsertElement: function willInsertElement() {
            var _this4 = this;

            _this.features.forEach(function (feature) {
              if (feature.shouldInvoke()) {
                feature.willInsertColumn.call(_this4);
              }
            });
          }
        });
      } catch (e) {
        GridComponent.reopen({
          didUpdate: function didUpdate() {
            var _this5 = this;

            _this.features.forEach(function (feature) {
              if (feature.shouldInvoke()) {
                feature.didUpdate.call(_this5);
              }
            });
          },
          willInsertElement: function willInsertElement() {
            var _this6 = this;

            _this.features.forEach(function (feature) {
              if (feature.shouldInvoke()) {
                feature.willInsertColumn.call(_this6);
              }
            });
          }
        });
      }

      // this is really hacky but I'm not sure what else to do, most of these components
      // double render so the `willInsertElement` works for those but the add rows
      // and footer are weird. add-rows doesn't double render and will work every time
      // after the component has been cached but footer is _always_ a new component WutFace
      var $appendToRows = void 0;
      switch (componentName) {
        case 'register/grid-add':
          $appendToRows = $('.ynab-grid-add-rows .ynab-grid-body-row.is-editing');
          break;
        case 'register/grid-sub-edit':
          $appendToRows = $('.ynab-grid-body-sub.is-editing');
          break;
        case 'register/grid-footer':
          $appendToRows = $('.ynab-grid-body-row.ynab-grid-footer');
          break;
      }

      if ($appendToRows) {
        this.features.forEach(function (feature) {
          if (feature.shouldInvoke()) {
            feature.handleSingleRenderColumn($appendToRows, componentName);
          }
        });
      }

      GridComponent.__toolkitInitialized = true;
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      this.features.forEach(function (feature) {
        if (feature.shouldInvoke()) {
          feature.insertHeader();
        }
      });

      ynabToolKit.invokeFeature('AdjustableColumnWidths');
    }

    // We're not querying the DOM here because we really want this observe to be as
    // cheap as possible. The four components we look for are not guaranteed to have ever
    // be created which means they won't be in the registry when we try to attach our listener
    // to them. Once one of them has been created, we'll attach a listener and `__toolkitInitialized`
    // should save us from any more processing. Once all four of them have been loaded, this
    // will continue to be a near noop observe.

  }, {
    key: 'observe',
    value: function observe() {
      if (!this.shouldInvoke()) {
        return;
      }

      var gridEditComponent = (0, _ember.componentLookup)('register/grid-edit');
      var gridAddComponent = (0, _ember.componentLookup)('register/grid-add');
      var gridSubEditComponent = (0, _ember.componentLookup)('register/grid-sub-edit');
      var gridGridFooterComponent = (0, _ember.componentLookup)('register/grid-footer');

      if (gridEditComponent && !gridEditComponent.__toolkitInitialized) {
        this.attachWillInsertHandler('register/grid-edit');
      }

      if (gridAddComponent && !gridAddComponent.__toolkitInitialized) {
        this.attachWillInsertHandler('register/grid-add');
      }

      if (gridSubEditComponent && !gridSubEditComponent.__toolkitInitialized) {
        this.attachWillInsertHandler('register/grid-sub-edit');
      }

      if (gridGridFooterComponent && !gridGridFooterComponent.__toolkitInitialized) {
        this.attachWillInsertHandler('register/grid-footer');
      }
    }
  }, {
    key: 'onRouteChanged',
    value: function onRouteChanged(route) {
      if (route.includes('account')) {
        var shouldAnyInvoke = false;
        this.features.forEach(function (feature) {
          if (!feature.shouldInvoke()) {
            feature.cleanup();
          } else {
            shouldAnyInvoke = true;
          }
        });

        if (shouldAnyInvoke) {
          this.invoke();
        }
      }
    }
  }]);

  return TransactionGridFeatures;
}(_feature.Feature);

/***/ }),
/* 401 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.RunningBalance = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(70);

var _ember = __webpack_require__(13);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var RunningBalance = exports.RunningBalance = function (_TransactionGridFeatu) {
  _inherits(RunningBalance, _TransactionGridFeatu);

  function RunningBalance() {
    _classCallCheck(this, RunningBalance);

    return _possibleConstructorReturn(this, (RunningBalance.__proto__ || Object.getPrototypeOf(RunningBalance)).apply(this, arguments));
  }

  _createClass(RunningBalance, [{
    key: 'injectCSS',
    value: function injectCSS() {
      var css = __webpack_require__(402);

      if (ynabToolKit.options.RunningBalance === '1') {
        css += __webpack_require__(404);
      }

      return css;
    }
  }, {
    key: 'willInvoke',
    value: function willInvoke() {
      return this.initializeRunningBalances();
    }
  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      var applicationController = (0, _ember.controllerLookup)('application');
      return applicationController.get('selectedAccountId') !== null;
    }
  }, {
    key: 'cleanup',
    value: function cleanup() {
      $('.ynab-grid-cell-toolkit-running-balance').remove();
    }
  }, {
    key: 'insertHeader',
    value: function insertHeader() {
      if ($('.ynab-grid-header .ynab-grid-cell-toolkit-running-balance').length) return;

      var $headerRow = $('.ynab-grid-header');
      var runningBalanceHeader = $('.ynab-grid-cell-inflow', $headerRow).clone();
      runningBalanceHeader.removeClass('ynab-grid-cell-inflow');
      runningBalanceHeader.addClass('ynab-grid-cell-toolkit-running-balance');
      runningBalanceHeader.text('RUNNING BALANCE').css('font-weight', 'normal');
      runningBalanceHeader.insertAfter($('.ynab-grid-cell-inflow', $headerRow));
      runningBalanceHeader.click(function (event) {
        event.preventDefault();
        event.stopPropagation();
        $('.ynab-grid-cell-date', $headerRow).click();
      });

      if ($('.ynab-grid-body .ynab-grid-body-row-top .ynab-grid-cell-toolkit-running-balance').length) return;
      var $topRow = $('.ynab-grid-body-row-top');
      var topRowRunningBalance = $('.ynab-grid-cell-inflow', $topRow).clone();
      topRowRunningBalance.removeClass('ynab-grid-cell-inflow');
      topRowRunningBalance.addClass('ynab-grid-cell-toolkit-running-balance');
      topRowRunningBalance.insertAfter($('.ynab-grid-cell-inflow', $topRow));
    }
  }, {
    key: 'handleSingleRenderColumn',
    value: function handleSingleRenderColumn($appendToRows) {
      $appendToRows.each(function (index, row) {
        if ($('.ynab-grid-cell-toolkit-running-balance', row).length === 0) {
          $('<div class="ynab-grid-cell ynab-grid-cell-toolkit-running-balance">').insertAfter($('.ynab-grid-cell-inflow', row));
        }
      });
    }
  }, {
    key: 'willInsertColumn',
    value: function willInsertColumn() {
      var isSub = this.get('_debugContainerKey') === 'component:register/grid-sub';
      var isRow = this.get('_debugContainerKey') === 'component:register/grid-row';
      var isActions = this.get('_debugContainerKey') === 'component:register/grid-actions';
      var isScheduled = this.get('_debugContainerKey') === 'component:register/grid-scheduled';
      var isRunningBalance = isSub || isRow || isScheduled;

      if (isRunningBalance) {
        var applicationController = (0, _ember.controllerLookup)('application');
        var selectedAccountId = applicationController.get('selectedAccountId');
        if (!selectedAccountId) {
          return;
        }

        var $currentRow = $(this.element);
        var currentRowRunningBalance = $('.ynab-grid-cell-inflow', $currentRow).clone();
        currentRowRunningBalance.removeClass('ynab-grid-cell-inflow');
        currentRowRunningBalance.addClass('ynab-grid-cell-toolkit-running-balance');

        var transaction = this.get('content');

        var runningBalance = transaction.__ynabToolKitRunningBalance;
        if (typeof runningBalance === 'undefined') {
          calculateRunningBalance(selectedAccountId);
          runningBalance = transaction.__ynabToolKitRunningBalance;
        }

        var currencySpan = $('.user-data', currentRowRunningBalance);
        if (runningBalance < 0) {
          currencySpan.addClass('user-data currency negative');
        } else if (runningBalance > 0) {
          currencySpan.addClass('user-data currency positive');
        } else {
          currencySpan.addClass('user-data currency zero');
        }

        if (transaction.get('parentEntityId') !== null) {
          currencySpan.text('');
        } else {
          currencySpan.text(ynabToolKit.shared.formatCurrency(runningBalance));
        }

        currentRowRunningBalance.insertAfter($('.ynab-grid-cell-inflow', $currentRow));
      } else if (!isActions && !$('.ynab-grid-cell-toolkit-running-balance', this.element).length) {
        $('<div class="ynab-grid-cell ynab-grid-cell-toolkit-running-balance">').insertAfter($('.ynab-grid-cell-inflow', this.element));
      }
    }
  }, {
    key: 'initializeRunningBalances',
    value: function initializeRunningBalances() {
      return ynab.YNABSharedLib.defaultInstance.entityManager.accountsCollection.forEach(function (account) {
        // we call this now so it's guaranteed to be resolved later
        return ynab.YNABSharedLib.defaultInstance.getBudgetViewModel_AccountTransactionsViewModel(account.entityId).then(function () {
          calculateRunningBalance(account.entityId);
        });
      });
    }
  }]);

  return RunningBalance;
}(_feature.TransactionGridFeature);

function attachAnyItemChangedListener(accountId, accountViewModel) {
  accountViewModel.__ynabToolKitAnyItemChangedListener = true;
  accountViewModel.get('visibleTransactionDisplayItems').addObserver('anyItemChangedCounter', function () {
    calculateRunningBalance(accountId);
  });
}

// Using ._result here bcause we can guarantee that we've already invoked the
// getBudgetViewModel_AccountTransactionsViewModel() function when we initialized
function calculateRunningBalance(accountId) {
  var accountsController = (0, _ember.controllerLookup)('accounts');
  var accountViewModel = ynab.YNABSharedLib.defaultInstance.getBudgetViewModel_AccountTransactionsViewModel(accountId)._result;

  if (!accountViewModel.__ynabToolKitAnyItemChangedListener) {
    attachAnyItemChangedListener(accountId, accountViewModel);
  }

  var transactions = accountViewModel.get('visibleTransactionDisplayItems');
  var sorted = transactions.slice().sort(function (a, b) {
    var propA = a.get('date');
    var propB = b.get('date');

    if (propA instanceof ynab.utilities.DateWithoutTime) propA = propA.getUTCTime();
    if (propB instanceof ynab.utilities.DateWithoutTime) propB = propB.getUTCTime();

    var res = Ember.compare(propA, propB);

    if (res === 0) {
      res = Ember.compare(a.getAmount(), b.getAmount());
      if (accountsController.get('sortAscending')) {
        return res;
      }

      return -res;
    }

    return res;
  });

  var runningBalance = 0;
  sorted.forEach(function (transaction) {
    if (transaction.get('parentEntityId') !== null) {
      transaction.__ynabToolKitRunningBalance = runningBalance;
      return;
    }

    if (transaction.get('inflow')) {
      runningBalance += transaction.get('inflow');
    } else if (transaction.get('outflow')) {
      runningBalance -= transaction.get('outflow');
    }

    transaction.__ynabToolKitRunningBalance = runningBalance;
  });
}

/***/ }),
/* 402 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(403);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 403 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".ynab-grid-cell-toolkit-running-balance {\n\ttext-align: right;\n\twidth: 10%;\n}\n", ""]);

// exports


/***/ }),
/* 404 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(405);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 405 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".ynab-grid-cell-toolkit-running-balance span.negative {\n\tcolor: #d33c2d;\n\tfont-weight: bold;\n}", ""]);

// exports


/***/ }),
/* 406 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CheckNumbers = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(70);

var _ynab = __webpack_require__(6);

var _ember = __webpack_require__(13);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var CheckNumbers = exports.CheckNumbers = function (_TransactionGridFeatu) {
  _inherits(CheckNumbers, _TransactionGridFeatu);

  function CheckNumbers() {
    _classCallCheck(this, CheckNumbers);

    return _possibleConstructorReturn(this, (CheckNumbers.__proto__ || Object.getPrototypeOf(CheckNumbers)).apply(this, arguments));
  }

  _createClass(CheckNumbers, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(407);
    }
  }, {
    key: 'insertHeader',
    value: function insertHeader() {
      if ($('.ynab-grid-header .ynab-grid-cell-toolkit-check-number').length) return;

      var $headerRow = $('.ynab-grid-header');
      var checkNumberHeader = $('.ynab-grid-cell-inflow', $headerRow).clone();
      checkNumberHeader.removeClass('ynab-grid-cell-inflow');
      checkNumberHeader.addClass('ynab-grid-cell-toolkit-check-number');
      checkNumberHeader.text('CHECK NUMBER').css('font-weight', 'normal');
      checkNumberHeader.insertAfter($('.ynab-grid-cell-memo', $headerRow));
      checkNumberHeader.click(function (event) {
        event.preventDefault();
        event.stopPropagation();
      });

      if ($('.ynab-grid-body .ynab-grid-body-row-top .ynab-grid-cell-toolkit-check-number').length) return;
      var $topRow = $('.ynab-grid-body-row-top');
      var topRowCheckNumber = $('.ynab-grid-cell-inflow', $topRow).clone();
      topRowCheckNumber.removeClass('ynab-grid-cell-inflow');
      topRowCheckNumber.addClass('ynab-grid-cell-toolkit-check-number');
      topRowCheckNumber.insertAfter($('.ynab-grid-cell-memo', $topRow));
    }
  }, {
    key: 'cleanup',
    value: function cleanup() {
      $('.ynab-grid-cell-toolkit-check-number').remove();
    }

    // Should return a boolean that informs AdditionalColumns feature that it
    // is on a page that should recevie the new column.

  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('account') !== -1;
    }

    // Called when one of the grid rows is getting inserted into the dom but
    // before it actually makes it into the dom. This should be doing the grunt
    // of the work.

  }, {
    key: 'willInsertColumn',
    value: function willInsertColumn() {
      var isAddRow = this.get('_debugContainerKey') === 'component:register/grid-add';
      var isEditRow = this.get('_debugContainerKey') === 'component:register/grid-edit';
      var isGridRow = this.get('_debugContainerKey') === 'component:register/grid-row';
      if (isAddRow || isEditRow) {
        var $editingRow = $(this.element);
        var editingTransaction = this.get('content');
        var $inputBox = $('<input placeholder="check number">').addClass('accounts-text-field').addClass('ynab-grid-cell-toolkit-check-number-input').blur(function () {
          editingTransaction.set('checkNumber', $(this).val());
        });

        $inputBox.val(editingTransaction.get('checkNumber'));
        $('<div class="ynab-grid-cell ynab-grid-cell-toolkit-check-number"><div>').append($inputBox).insertAfter($('.ynab-grid-cell-memo', $editingRow));
      } else if (isGridRow) {
        // view only column
        var $currentRow = $(this.element);
        var checkNumberCell = $('.ynab-grid-cell-memo', $currentRow).clone();
        checkNumberCell.removeClass('ynab-grid-cell-memo');
        checkNumberCell.addClass('ynab-grid-cell-toolkit-check-number');

        var transaction = this.get('content');
        checkNumberCell.text(transaction.get('checkNumber') || '');
        checkNumberCell.insertAfter($('.ynab-grid-cell-memo', $currentRow));
      } else {
        // dead column
        var _checkNumberCell = $('.ynab-grid-cell-memo', this.element).clone();
        _checkNumberCell.removeClass('ynab-grid-cell-memo');
        _checkNumberCell.addClass('ynab-grid-cell-toolkit-check-number');
        _checkNumberCell.insertAfter($('.ynab-grid-cell-memo', this.element));
        _checkNumberCell.empty();
      }
    }

    // this is really hacky but I'm not sure what else to do, most of these components
    // double render so the `willInsertElement` works for those but the add rows
    // and footer are weird. add-rows doesn't double render and will work every time
    // after the component has been cached but footer is _always_ a new component WutFace

  }, {
    key: 'handleSingleRenderColumn',
    value: function handleSingleRenderColumn($appendToRows, componentName) {
      if (componentName === 'register/grid-add') {
        var accountsController = (0, _ember.controllerLookup)('accounts');
        var editingTransaction = accountsController.get('editingTransaction');
        var $inputBox = $('<input placeholder="check number">').addClass('accounts-text-field').addClass('ynab-grid-cell-toolkit-check-number-input').blur(function () {
          editingTransaction.set('checkNumber', $(this).val());
        });

        $inputBox.val(editingTransaction.get('checkNumber'));
        $('<div class="ynab-grid-cell ynab-grid-cell-toolkit-check-number"><div>').append($inputBox).insertAfter($('.ynab-grid-cell-memo', $appendToRows));

        return;
      }

      $appendToRows.each(function (index, row) {
        if ($('.ynab-grid-cell-toolkit-check-number', row).length === 0) {
          var checkNumberCell = $('.ynab-grid-cell-memo', row).clone();
          checkNumberCell.removeClass('ynab-grid-cell-memo');
          checkNumberCell.addClass('ynab-grid-cell-toolkit-check-number');
          checkNumberCell.insertAfter($('.ynab-grid-cell-memo', row));
          checkNumberCell.empty();
        }
      });
    }
  }]);

  return CheckNumbers;
}(_feature.TransactionGridFeature);

/***/ }),
/* 407 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(408);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 408 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".ynab-grid-cell-toolkit-check-number {\n\ttext-align: right;\n\twidth: 10%;\n}\n", ""]);

// exports


/***/ }),
/* 409 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ReconciledTextColor = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(70);

var _ynab = __webpack_require__(6);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var TOOLKIT_RECONCILED_CLASS = 'toolkit-is-reconciled';
var YNAB_IS_CHECKED_CLASS = 'is-checked';
var YNAB_GRID_BODY_ROW_CLASS = 'ynab-grid-body-row';
var YNAB_GRID_BODY_SUB_CLASS = 'ynab-grid-body-sub';

var ReconciledTextColor = exports.ReconciledTextColor = function (_TransactionGridFeatu) {
  _inherits(ReconciledTextColor, _TransactionGridFeatu);

  function ReconciledTextColor() {
    _classCallCheck(this, ReconciledTextColor);

    return _possibleConstructorReturn(this, (ReconciledTextColor.__proto__ || Object.getPrototypeOf(ReconciledTextColor)).apply(this, arguments));
  }

  _createClass(ReconciledTextColor, [{
    key: 'injectCSS',
    value: function injectCSS() {
      if (ynabToolKit.options.ReconciledTextColor === '1') {
        return __webpack_require__(410);
      } else if (ynabToolKit.options.ReconciledTextColor === '2') {
        return __webpack_require__(412);
      } else if (ynabToolKit.options.ReconciledTextColor === '3') {
        return __webpack_require__(414);
      } else if (ynabToolKit.options.ReconciledTextColor === '4') {
        return __webpack_require__(416);
      }
    }
  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('account') !== -1;
    }
  }, {
    key: 'didUpdate',
    value: function didUpdate() {
      var isSubGridRow = this.get('_debugContainerKey') === 'component:register/grid-sub';
      var isGridRow = this.get('_debugContainerKey') === 'component:register/grid-row';

      // We only care about transaction and sub transaction rows
      if (isGridRow || isSubGridRow) {
        var content = this.get('content');
        var $element = $(this.element);
        var isChecked = $element.hasClass(YNAB_IS_CHECKED_CLASS);
        var isReconciled = content.get('cleared') === ynab.constants.TransactionState.Reconciled;

        if (isChecked) {
          $element.removeClass(TOOLKIT_RECONCILED_CLASS);
        } else if (!isChecked && isReconciled) {
          $element.addClass(TOOLKIT_RECONCILED_CLASS);
        }

        // I'm not sure how intensive it would be to go find the IDs of sub transactions in a
        // split so rather than do that, just continue down the line of sub transactions after
        // a split and update the classes accordingly
        if (content.get('isSplit')) {
          var $nextTransaction = $element.next();
          while ($nextTransaction.hasClass(YNAB_GRID_BODY_SUB_CLASS)) {
            if (isChecked) {
              $nextTransaction.removeClass(TOOLKIT_RECONCILED_CLASS);
            } else if (!isChecked && isReconciled) {
              $nextTransaction.addClass(TOOLKIT_RECONCILED_CLASS);
            }

            $nextTransaction = $nextTransaction.next();
          }
        }
      }
    }

    // Welcome to the City of Edge Case. Population: this feature.

  }, {
    key: 'willInsertColumn',
    value: function willInsertColumn() {
      var isSubGridRow = this.get('_debugContainerKey') === 'component:register/grid-sub';
      var isGridRow = this.get('_debugContainerKey') === 'component:register/grid-row';

      // We only care about transaction and sub transaction rows
      if (isGridRow || isSubGridRow) {
        var $element = $(this.element);
        var content = this.get('content');
        var isChecked = $element.hasClass(YNAB_IS_CHECKED_CLASS);

        // if we're looking at a sub transaction, we need to find the data for it's parent to
        // determine if it's been reconciled. we also need to use it's parent's element to
        // determine if it's been checked since sub transactions don't have check boxes. The
        // only reason we actually care about "checked" in `willInsertColumn` is because it's
        // possible the user toggles splits while having multiple things selected and we want
        // to make sure to handle the newly inserted rows properly. `willUpdate` won't catch this
        if (content.get('isSubTransaction')) {
          var parentEntityId = content.get('parentEntityId');

          content = content.getEntityManager().transactionsCollection.findItemByEntityId(parentEntityId);
          isChecked = $('.' + YNAB_GRID_BODY_ROW_CLASS + '[data-row-id="' + parentEntityId + '"]').hasClass(YNAB_IS_CHECKED_CLASS);
        }

        var isReconciled = content.get('cleared') === ynab.constants.TransactionState.Reconciled;
        if (isChecked) {
          $element.removeClass(TOOLKIT_RECONCILED_CLASS);
        } else if (!isChecked && isReconciled) {
          $element.addClass(TOOLKIT_RECONCILED_CLASS);
        }
      }
    }
  }]);

  return ReconciledTextColor;
}(_feature.TransactionGridFeature);

/***/ }),
/* 410 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(411);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 411 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".toolkit-is-reconciled {\n\tcolor: #00661d;\n}\n.toolkit-is-reconciled .ynab-grid-cell-payeeName svg path,\n.toolkit-is-reconciled .ynab-grid-cell-payeeName svg rect {\n\tfill: #00661d;\n}\n", ""]);

// exports


/***/ }),
/* 412 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(413);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 413 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".toolkit-is-reconciled {\n\tcolor: #cfd5d7;\n}\n.toolkit-is-reconciled .ynab-grid-cell-payeeName svg path,\n.toolkit-is-reconciled .ynab-grid-cell-payeeName svg rect {\n\tfill: #cfd5d7;\n}", ""]);

// exports


/***/ }),
/* 414 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(415);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 415 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".toolkit-is-reconciled {\n\tcolor: #8e9fb0;\n}\n.toolkit-is-reconciled .ynab-grid-cell-payeeName svg path,\n.toolkit-is-reconciled .ynab-grid-cell-payeeName svg rect {\n\tfill: #8e9fb0;\n}\n", ""]);

// exports


/***/ }),
/* 416 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(417);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 417 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".toolkit-is-reconciled {\n\tcolor: #8e9fb0;\n\tbackground-color: #e7faeb !important;\n}\n.toolkit-is-reconciled .ynab-grid-cell-payeeName svg path,\n.toolkit-is-reconciled .ynab-grid-cell-payeeName svg rect {\n\tfill: #8e9fb0;\n}\n", ""]);

// exports


/***/ }),
/* 418 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DisableToolkit = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var DisableToolkit = exports.DisableToolkit = function (_Feature) {
  _inherits(DisableToolkit, _Feature);

  function DisableToolkit() {
    _classCallCheck(this, DisableToolkit);

    return _possibleConstructorReturn(this, (DisableToolkit.__proto__ || Object.getPrototypeOf(DisableToolkit)).apply(this, arguments));
  }

  _createClass(DisableToolkit, [{
    key: 'invoke',
    value: function invoke() {
      // this is a empty class to make use of the Feature setting for localStorage.
    }
  }]);

  return DisableToolkit;
}(_feature.Feature);

/***/ }),
/* 419 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.BudgetProgressBars = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var progressIndicatorWidth = 0.005; // Current month progress indicator width

var BudgetProgressBars = exports.BudgetProgressBars = function (_Feature) {
  _inherits(BudgetProgressBars, _Feature);

  function BudgetProgressBars() {
    var _ref;

    var _temp, _this2, _ret;

    _classCallCheck(this, BudgetProgressBars);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this2 = _possibleConstructorReturn(this, (_ref = BudgetProgressBars.__proto__ || Object.getPrototypeOf(BudgetProgressBars)).call.apply(_ref, [this].concat(args))), _this2), _this2.loadCategories = true, _this2.subCats = [], _temp), _possibleConstructorReturn(_this2, _ret);
  }
  // Supporting functions, or variables, etc


  _createClass(BudgetProgressBars, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(420);
    }
  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('budget') > -1;
    }

    // Takes N colors and N-1 sorted points from (0, 1) to make color1|color2|color3 bg style.

  }, {
    key: 'generateProgressBarStyle',
    value: function generateProgressBarStyle(colors, points) {
      points.unshift(0);
      points.push(1);
      var pointsPercent = Array.from(points, function (p) {
        return p * 100;
      });

      var style = 'linear-gradient(to right, ';
      for (var i = 0; i < colors.length; i++) {
        style += colors[i] + ' ' + pointsPercent[i] + '%, ';
        style += colors[i] + ' ' + pointsPercent[i + 1] + '%';
        style += i + 1 === colors.length ? ')' : ', ';
      }

      return style;
    }
  }, {
    key: 'getCalculation',
    value: function getCalculation(subCategoryName) {
      var subCat = this.subCats.find(function (ele) {
        return ele.toolkitName === subCategoryName;
      });
      var calculation = null;
      if (subCat) {
        var crazyInternalId = this.internalIdBase + subCat.entityId;
        calculation = (0, _ynab.getEntityManager)().getMonthlySubCategoryBudgetCalculationById(crazyInternalId);
        /**
         * Add a few values from the subCat object to the calculation object.
         */
        calculation.targetBalance = subCat.getTargetBalance();
        calculation.goalType = subCat.getGoalType();
        calculation.goalCreationMonth = subCat.goalCreationMonth ? subCat.goalCreationMonth.toString().substr(0, 7) : '';
        /**
         * If the month the goal was created in is greater than the selected month, null the goal type to prevent further
         * processing.
         */
        if (calculation.goalCreationMonth && calculation.goalCreationMonth > this.selMonth) {
          calculation.goalType = null;
        }
      }

      return calculation;
    }
  }, {
    key: 'addGoalProgress',
    value: function addGoalProgress(subCategoryName, target) {
      var calculation = this.getCalculation(subCategoryName);

      var status = 0;
      var hasGoal = false;

      if (calculation !== null) {
        switch (calculation.goalType) {
          case 'TB':
          case 'TBD':
          case 'MF':
            hasGoal = true;
            status = calculation.goalPercentageComplete;

            break;
          default:
        }
      }

      if (hasGoal) {
        var percent = Math.round(parseFloat(status));
        $(target).css('background', 'linear-gradient(to right, rgba(22, 163, 54, 0.3) ' + percent + '%, white ' + percent + '%)');
      } else {
        $(target).css('background', '');
      }
    }
  }, {
    key: 'addPacingProgress',
    value: function addPacingProgress(subCategoryName, target) {
      var deEmphasizedCategories = JSON.parse(localStorage.getItem('ynab_toolkit_pacing_deemphasized_categories')) || [];

      if (deEmphasizedCategories.indexOf(subCategoryName) === -1) {
        var calculation = this.getCalculation(subCategoryName);

        var budgeted = calculation.balance - calculation.budgetedCashOutflows - calculation.budgetedCreditOutflows;
        var available = calculation.balance;

        if (budgeted > 0) {
          var pacing = (budgeted - available) / budgeted;
          if (this.monthProgress > pacing) {
            $(target).css('background', this.generateProgressBarStyle(['#c0e2e9', 'white', '#CFD5D8', 'white'], [pacing, this.monthProgress - progressIndicatorWidth, this.monthProgress]));
          } else {
            $(target).css('background', this.generateProgressBarStyle(['#c0e2e9', '#CFD5D8', '#c0e2e9', 'white'], [this.monthProgress - progressIndicatorWidth, this.monthProgress, pacing]));
          }
        } else {
          $(target).css('background', this.generateProgressBarStyle(['white', '#CFD5D8', 'white'], [this.monthProgress - progressIndicatorWidth, this.monthProgress]));
        }
      } else {
        $(target).css('background', '');
      }
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      var _this = this;
      var date = new Date();
      this.monthProgress = new Date().getDate() / new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();

      var categories = $('.budget-table ul').not('.budget-table-uncategorized-transactions').not('.is-debt-payment-category');
      var masterCategoryName = '';

      if (this.subCats === null || this.subCats.length === 0 || this.loadCategories) {
        this.subCats = ynabToolKit.shared.getMergedCategories();
        this.loadCategories = false;
      }

      this.selMonth = ynabToolKit.shared.parseSelectedMonth();

      // will be null on YNAB load when the user is not on the budget screen
      if (this.selMonth !== null) {
        this.selMonth = ynabToolKit.shared.yyyymm(this.selMonth);
        this.internalIdBase = 'mcbc/' + this.selMonth + '/';
      }

      $(categories).each(function () {
        var nameCell = void 0;
        var budgetedCell = void 0;
        if ($(this).hasClass('is-master-category')) {
          masterCategoryName = $(this).find('div.budget-table-cell-name-row-label-item>div>div[title]');
          masterCategoryName = masterCategoryName !== 'undefined' ? $(masterCategoryName).attr('title') + '_' : '';
        }

        if ($(this).hasClass('is-sub-category')) {
          var subCategoryName = $(this).find('li.budget-table-cell-name>div>div')[0].title.match(/.[^\n]*/);

          subCategoryName = masterCategoryName + subCategoryName;

          switch (_this.settings.enabled) {
            case 'goals':
              $(this).addClass('goal-progress');
              _this.addGoalProgress(subCategoryName, $(this));
              break;
            case 'pacing':
              $(this).addClass('goal-progress');
              _this.addPacingProgress(subCategoryName, $(this));
              break;
            case 'both':
              $(this).addClass('goal-progress-both');
              budgetedCell = $(this).find('li.budget-table-cell-budgeted')[0];
              nameCell = $(this).find('li.budget-table-cell-name')[0];
              _this.addGoalProgress(subCategoryName, budgetedCell);
              _this.addPacingProgress(subCategoryName, nameCell);
              break;
          }
        }

        if ($(this).hasClass('is-master-category')) {
          switch (_this.settings.enabled) {
            case 'pacing':
              $(this).css('background', _this.generateProgressBarStyle(['#E5F5F9', '#CFD5D8', '#E5F5F9'], [_this.monthProgress - progressIndicatorWidth, _this.monthProgress]));
              break;
            case 'both':
              nameCell = $(this).find('li.budget-table-cell-name'); // [0];
              $(nameCell).css('background', _this.generateProgressBarStyle(['#E5F5F9', '#CFD5D8', '#E5F5F9'], [_this.monthProgress - progressIndicatorWidth, _this.monthProgress]));
              break;
          }
        }
      });
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      /**
       * Check for this node seperately from the other checks to ensure the flag to load
       * categories gets set just in case there is another changed node that drives invoke().
       */
      if (changedNodes.has('onboarding-steps')) {
        this.loadCategories = true;
      }

      if (changedNodes.has('budget-table-row') || changedNodes.has('budget-table-cell-available-div user-data') || changedNodes.has('budget-table-cell-budgeted') || changedNodes.has('navlink-budget active') || changedNodes.has('budget-inspector')) {
        this.invoke();
      } else if (changedNodes.has('modal-overlay ynab-u modal-popup modal-budget-edit-category active') || changedNodes.has('modal-overlay ynab-u modal-popup modal-add-master-category active') || changedNodes.has('modal-overlay ynab-u modal-popup modal-add-sub-category active')) {
        /**
         * Seems there should be a more 'Embery' way to know when the categories have been
         * updated, added, or deleted but this'll have to do for now. Note that the flag is
         * set to true here so that next time invoke() is called the categories array will
         * be rebuilt. Rebuilding at this point won't work becuase the user hasn't completed
         * the update activity at this point.
         */
        this.loadCategories = true;
      }
    }
  }, {
    key: 'onRouteChanged',
    value: function onRouteChanged() {
      if (this.shouldInvoke()) {
        this.loadCategories = true;
        this.invoke();
      }
    }
  }]);

  return BudgetProgressBars;
}(_feature.Feature);

/***/ }),
/* 420 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(421);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 421 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".budget-table-row.is-checked,\n.budget-table-row.is-checked .budget-table-cell-name,\n.budget-table-row.is-checked .budget-table-cell-budgeted {\n  background: #005a6e !important;\n}\n", ""]);

// exports


/***/ }),
/* 422 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CategoryActivityCopy = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

var _ember = __webpack_require__(13);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var CategoryActivityCopy = exports.CategoryActivityCopy = function (_Feature) {
  _inherits(CategoryActivityCopy, _Feature);

  function CategoryActivityCopy() {
    _classCallCheck(this, CategoryActivityCopy);

    return _possibleConstructorReturn(this, (CategoryActivityCopy.__proto__ || Object.getPrototypeOf(CategoryActivityCopy)).apply(this, arguments));
  }

  _createClass(CategoryActivityCopy, [{
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('budget') !== -1;
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      $('.modal-actions > .button-primary').clone().attr('id', 'toolkit-copy-button').insertAfter('.modal-actions > .button-primary').on('click', this.categoryActivityCopy);

      var childCache = $('#toolkit-copy-button').children();
      $('#toolkit-copy-button').text('Copy Transactions').append(childCache);
      $('#toolkit-copy-button > .flaticon').toggleClass('checkmark-2 copy').css('margin-left', '3px');
    }
  }, {
    key: 'categoryActivityCopy',
    value: function categoryActivityCopy() {
      var budgetController = (0, _ember.controllerLookup)('budget');
      var activityTransactions = budgetController.get('selectedActivityTransactions');
      var activities = activityTransactions.map(function (transaction) {
        return {
          Account: transaction.get('accountName'),
          Date: ynab.formatDateLong(transaction.get('date')),
          Category: transaction.get('subCategoryNameWrapped'),
          Memo: transaction.get('memo'),
          Amount: ynab.formatCurrency(transaction.get('amount'))
        };
      });

      var replacer = function replacer(key, value) {
        return value === null ? '' : value;
      };
      var header = Object.keys(activities[0]);
      var csv = activities.map(function (row) {
        return header.map(function (fieldName) {
          return JSON.stringify(row[fieldName], replacer);
        }).join('\t');
      });
      csv.unshift(header.join('\t'));
      csv = csv.join('\r\n');
      var $temp = $('<textarea style="position:absolute; left: -9999px; top: 50px;"/>');
      $('body').append($temp);
      $temp.val(csv).select();
      document.execCommand('copy');
      $temp.remove();
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (!this.shouldInvoke()) return;
      if (changedNodes.has('ynab-u modal-popup modal-budget-activity ember-view modal-overlay active')) {
        this.invoke();
      }
    }
  }, {
    key: 'onRouteChanged',
    value: function onRouteChanged() {
      if (!this.shouldInvoke()) return;
      this.invoke();
    }
  }]);

  return CategoryActivityCopy;
}(_feature.Feature);

/***/ }),
/* 423 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CategoryActivityPopupWidth = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var CategoryActivityPopupWidth = exports.CategoryActivityPopupWidth = function (_Feature) {
  _inherits(CategoryActivityPopupWidth, _Feature);

  function CategoryActivityPopupWidth() {
    _classCallCheck(this, CategoryActivityPopupWidth);

    return _possibleConstructorReturn(this, (CategoryActivityPopupWidth.__proto__ || Object.getPrototypeOf(CategoryActivityPopupWidth)).apply(this, arguments));
  }

  _createClass(CategoryActivityPopupWidth, [{
    key: 'injectCSS',
    value: function injectCSS() {
      if (this.settings.enabled === '1') {
        return __webpack_require__(424);
      } else if (this.settings.enabled === '2') {
        return __webpack_require__(426);
      }
    }
  }]);

  return CategoryActivityPopupWidth;
}(_feature.Feature);

/***/ }),
/* 424 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(425);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 425 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".modal-budget-activity .modal {\n\twidth: 48em !important;\n}\n\n/* There are 5 columns all 20% width by default */\n/* Date column */\n.modal-budget-activity ul.budget-activity li:nth-child(2) {\n\twidth: 15%;\n}\n/* Memo column */\n.modal-budget-activity ul.budget-activity li:nth-child(4) {\n\twidth: 30%;\n}\n/* Amount column */\n.modal-budget-activity ul.budget-activity li:nth-child(5) {\n\twidth: 15%;\n}\n", ""]);

// exports


/***/ }),
/* 426 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(427);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 427 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".modal-budget-activity .modal {\n\twidth: 64em !important;\n}\n\n/* There are 5 columns all 20% width by default */\n/* Date column */\n.modal-budget-activity ul.budget-activity li:nth-child(2) {\n\twidth: 10%;\n}\n/* Memo column */\n.modal-budget-activity ul.budget-activity li:nth-child(4) {\n\twidth: 40%;\n}\n/* Amount column */\n.modal-budget-activity ul.budget-activity li:nth-child(5) {\n\twidth: 10%;\n}", ""]);

// exports


/***/ }),
/* 428 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CheckCreditBalances = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var CheckCreditBalances = exports.CheckCreditBalances = function (_Feature) {
  _inherits(CheckCreditBalances, _Feature);

  function CheckCreditBalances() {
    var _ref;

    var _temp, _this2, _ret;

    _classCallCheck(this, CheckCreditBalances);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this2 = _possibleConstructorReturn(this, (_ref = CheckCreditBalances.__proto__ || Object.getPrototypeOf(CheckCreditBalances)).call.apply(_ref, [this].concat(args))), _this2), _this2.budgetView = null, _temp), _possibleConstructorReturn(_this2, _ret);
  }

  _createClass(CheckCreditBalances, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(429);
    }
  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('budget') !== -1;
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      if (this.currentYear === 0 || this.currentMonth === 0) {
        this.onMonthChanged((0, _ynab.getCurrentBudgetMonth)());
      }

      if (this.inCurrentMonth()) {
        var debtAccounts = this.getDebtAccounts();

        if (debtAccounts !== null) {
          this.processDebtAccounts(debtAccounts);
        }
      } else {
        $('.toolkit-rectify-difference').remove();
      }
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (!this.shouldInvoke()) return;

      if (changedNodes.has('navlink-budget active') || changedNodes.has('budget-table-cell-available-div user-data') || changedNodes.has('budget-inspector') || changedNodes.has('budget-table-row is-sub-category is-debt-payment-category is-checked') || changedNodes.has('budget-header-totals-cell-value user-data')) {
        this.invoke();
      }
    }
  }, {
    key: 'onBudgetChanged',
    value: function onBudgetChanged() {
      this.budgetView = null;
    }
  }, {
    key: 'onRouteChanged',
    value: function onRouteChanged() {
      if (!this.shouldInvoke()) return;

      this.invoke();
    }
  }, {
    key: 'inCurrentMonth',
    value: function inCurrentMonth() {
      // check for current month or future month
      var today = new Date();
      var budgetDate = (0, _ynab.getCurrentBudgetDate)();

      // check for current month or future month
      // must subtract 1 from budget month because the Date object is zero based.
      return budgetDate.month - 1 >= today.getMonth() && budgetDate.year >= today.getYear();
    }
  }, {
    key: 'getDebtAccounts',
    value: function getDebtAccounts() {
      // After using Budget Quick Switch, budgetView needs to be reset to the new budget. The try catch construct is necessary
      // because this function can be called several times during the budget switch process.
      if (this.budgetView === null || this.budgetView.categoriesViewModel === null) {
        try {
          this.budgetView = (0, _ynab.getAllBudgetMonthsViewModelResult)();
        } catch (e) {
          return null;
        }
      }

      var categoryEntityId = this.budgetView.categoriesViewModel.debtPaymentMasterCategory.entityId;

      var debtAccounts = this.budgetView.categoriesViewModel.subCategoriesCollection.findItemsByMasterCategoryId(categoryEntityId);

      return debtAccounts || [];
    }
  }, {
    key: 'processDebtAccounts',
    value: function processDebtAccounts(debtAccounts) {
      var foundButton = false;
      var _this = this;
      debtAccounts.forEach(function (a) {
        // Not sure why but sometimes on a reload (F5 or CTRL-R) of YNAB, the accountId field is null which if not handled
        // throws an error and kills the feature.
        if (a.accountId !== null) {
          var account = _this.budgetView.sidebarViewModel.accountCalculationsCollection.findItemByAccountId(a.accountId);
          var currentMonth = moment(ynabToolKit.shared.parseSelectedMonth()).format('YYYY-MM');
          var balance = account.clearedBalance + account.unclearedBalance;
          var monthlyBudget = _this.budgetView.monthlySubCategoryBudgetCalculationsCollection.findItemByEntityId('mcbc/' + currentMonth + '/' + a.entityId);

          var available = 0;
          if (monthlyBudget) {
            available = monthlyBudget.balance;
          }

          // ensure that available is >= zero, otherwise don't update
          if (available >= 0) {
            // If cleared balance is positive, bring available to 0, otherwise
            // offset by the correct amount
            var difference = 0;
            if (balance > 0) {
              difference = available * -1;
            } else {
              difference = (available + balance) * -1;
            }

            if (!foundButton) {
              foundButton = _this.updateInspectorButton(a.name, difference);
            }

            if (available !== balance * -1) {
              _this.updateRow(a.name);
              _this.updateInspectorStyle(a.name);
            }
          }
        }
      });

      if (!foundButton) {
        $('.toolkit-rectify-difference').remove();
      }
    }
  }, {
    key: 'updateRow',
    value: function updateRow(name) {
      var rows = $('.is-sub-category.is-debt-payment-category');
      rows.each(function () {
        var accountName = $(this).find('.budget-table-cell-name div.button-truncate').prop('title').match(/.[^\n]*/)[0]; // strip the Note string

        if (name === accountName) {
          var categoryBalance = $(this).find('.budget-table-cell-available-div .user-data.currency');
          categoryBalance.removeClass('positive zero');
          if (!categoryBalance.hasClass('negative')) {
            $(this).find('.budget-table-cell-available-div .user-data.currency').addClass('cautious toolkit-pif-cautious');
          }
        }
      });
    }
  }, {
    key: 'updateInspectorStyle',
    value: function updateInspectorStyle(name) {
      var inspectorName = $('.inspector-category-name.user-data').text().trim();
      if (name === inspectorName) {
        var inspectorBalance = $('.inspector-overview-available .user-data .user-data.currency');
        inspectorBalance.removeClass('positive zero');
        if (!inspectorBalance.hasClass('negative')) {
          $('.inspector-overview-available .user-data .user-data.currency, .inspector-overview-available dt').addClass('cautious toolkit-pif-cautious');
        }
      }
    }
  }, {
    key: 'updateInspectorButton',
    value: function updateInspectorButton(name, difference) {
      var inspectorName = $('.inspector-category-name.user-data').text().trim();

      if (name && name === inspectorName) {
        var fDifference = ynabToolKit.shared.formatCurrency(difference);
        var positive = '';
        if (ynab.unformat(difference) >= 0) {
          positive = '+';
        }

        var button = $('.toolkit-rectify-difference');
        if (!button.length) {
          button = $('<a>', {
            class: 'budget-inspector-button toolkit-rectify-difference'
          }).css({
            'text-align': 'center',
            'line-height': '30px',
            display: 'block',
            cursor: 'pointer'
          }).click(this.updateCreditBalances);

          $('.inspector-quick-budget').append(button);
        }

        button.data('name', name).data('difference', difference).empty().append(ynabToolKit.l10nData && ynabToolKit.l10nData['toolkit.checkCreditBalances'] || 'Rectify Difference:').append(' ' + positive).append($('<strong>', { class: 'user-data', title: fDifference }).append(ynabToolKit.shared.appendFormattedCurrencyHtml($('<span>', { class: 'user-data currency zero' }), difference)));

        if (difference !== 0) {
          button.removeAttr('disabled');
        } else {
          button.attr('disabled', true);
        }

        return true;
      }
      return false;
    }
  }, {
    key: 'updateCreditBalances',
    value: function updateCreditBalances() {
      if (ynabToolKit.options.QuickBudgetWarning) {
        // no need to confirm quick budget if zero budgeted
        if (!$('div.budget-table ul.budget-table-row.is-checked li.budget-table-cell-budgeted .currency').hasClass('zero')) {
          if (!window.confirm('Are you sure you want to budget this amount?')) {
            // eslint-disable-line no-alert
            return;
          }
        }
      }

      var name = $(this).data('name');
      var difference = $(this).data('difference');
      var debtPaymentCategories = $('.is-debt-payment-category.is-sub-category');

      $(debtPaymentCategories).each(function () {
        var accountName = $(this).find('.budget-table-cell-name div.button-truncate').prop('title').match(/.[^\n]*/)[0];
        if (accountName === name) {
          var input = $(this).find('.budget-table-cell-budgeted div.currency-input').click().find('input');

          var oldValue = input.val();

          // If nothing is budgeted, the input will be empty
          oldValue = oldValue || 0;

          // YNAB stores values *1000 for decimal places, so just
          // multiple by 1000 to get the actual amount.
          var newValue = ynab.unformat(oldValue) * 1000 + difference;

          // format the calculated value back to selected number format
          input.val(ynab.formatCurrency(newValue));

          if (ynabToolKit.options.QuickBudgetWarning === 0) {
            // only seems to work if the confirmation doesn't pop up?
            // haven't figured out a way to properly blur otherwise
            input.blur();
          }
        }
      });
    }
  }]);

  return CheckCreditBalances;
}(_feature.Feature);

/***/ }),
/* 429 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(430);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 430 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, "/* row */\nbody .budget-table .budget-table-row.is-sub-category.is-debt-payment-category .budget-table-cell-available .toolkit-pif-cautious {\n  background-color: #e59100;\n}\nbody .budget-table .budget-table-row.is-sub-category.is-debt-payment-category .budget-table-cell-available .toolkit-pif-cautious:hover {\n  background-color: #c37b00;\n}\n\n/* inspector */\nbody .budget-inspector .budget-inspector-category-overview .inspector-overview-available.toolkit-row-debt-category dt.toolkit-pif-cautious {\n  color: #e59100 !important;\n}\nbody .budget-inspector .budget-inspector-category-overview .inspector-overview-available.toolkit-row-debt-category dd .toolkit-pif-cautious {\n  background: #e59100 !important;\n}\n", ""]);

// exports


/***/ }),
/* 431 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CreditCardEmoji = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var CreditCardEmoji = exports.CreditCardEmoji = function (_Feature) {
  _inherits(CreditCardEmoji, _Feature);

  function CreditCardEmoji() {
    _classCallCheck(this, CreditCardEmoji);

    return _possibleConstructorReturn(this, (CreditCardEmoji.__proto__ || Object.getPrototypeOf(CreditCardEmoji)).apply(this, arguments));
  }

  _createClass(CreditCardEmoji, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(432);
    }
  }]);

  return CreditCardEmoji;
}(_feature.Feature);

/***/ }),
/* 432 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(433);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 433 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, "[title=\"Credit Card Payments\"] .user-entered-text::before {\n  content: \"\\1F4B3   \";\n}\n", ""]);

// exports


/***/ }),
/* 434 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DaysOfBuffering = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _ynab = __webpack_require__(6);

var _feature = __webpack_require__(2);

var _helpers = __webpack_require__(435);

var _render2 = __webpack_require__(437);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var DaysOfBuffering = exports.DaysOfBuffering = function (_Feature) {
  _inherits(DaysOfBuffering, _Feature);

  _createClass(DaysOfBuffering, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(438);
    }
  }]);

  function DaysOfBuffering() {
    _classCallCheck(this, DaysOfBuffering);

    var _this = _possibleConstructorReturn(this, (DaysOfBuffering.__proto__ || Object.getPrototypeOf(DaysOfBuffering)).call(this));

    _this.transactionFilter = null;

    _this.historyLookup = parseInt(ynabToolKit.options.DaysOfBufferingHistoryLookup);
    _this.lastRenderTime = 0;
    _this.observe = _this.invoke;
    return _this;
  }

  _createClass(DaysOfBuffering, [{
    key: 'invoke',
    value: function invoke() {
      if (!this.shouldInvoke() || !(0, _render2.shouldRender)(this.lastRenderTime)) return;

      if (this.transactionFilter === null) {
        this.transactionFilter = (0, _helpers.outflowTransactionFilter)(this.historyLookup);
      }

      var transactions = (0, _ynab.getEntityManager)().getAllTransactions().filter(this.transactionFilter);
      var report = { ableToGenerate: true };

      try {
        report = (0, _helpers.generateReport)(transactions, this.accountBalance());
      } catch (e) {
        report = { ableToGenerate: false };
      }

      this.render(report);
    }
  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('budget') > -1;
    }
  }, {
    key: 'render',
    value: function render(report) {
      (0, _render2.render)(report);
      this.lastRenderTime = Date.now();
    }
  }, {
    key: 'accountBalance',
    value: function accountBalance() {
      return ynab.YNABSharedLib.getBudgetViewModel_SidebarViewModel()._result.getOnBudgetAccountsBalance();
    }
  }]);

  return DaysOfBuffering;
}(_feature.Feature);

/***/ }),
/* 435 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.outflowTransactionFilter = outflowTransactionFilter;
exports.generateReport = generateReport;

var _transaction = __webpack_require__(436);

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

var isValidPayee = function isValidPayee(payee) {
  if (payee === null) {
    return true;
  }

  return payee.internalName !== 'StartingBalancePayee';
};

var isValidDate = function isValidDate(transactionTime, currentTime, historyLookupMonths) {
  if (historyLookupMonths !== 0) {
    return (currentTime - transactionTime) / 3600 / 24 / 1000 / (365 / 12) < historyLookupMonths;
  }
  return true;
};

function outflowTransactionFilter(historyLookupMonths) {
  var dateNow = Date.now();

  return function (transaction) {
    return !transaction.isTombstone && transaction.transferAccountId === null && transaction.amount < 0 && isValidPayee(transaction.getPayee()) && transaction.getAccount().onBudget && !(0, _transaction.isTransfer)(transaction) && isValidDate(transaction.getDate().getUTCTime(), dateNow, historyLookupMonths);
  };
}

function generateReport(transactions, totalBudget) {
  var transactionDates = transactions.map(function (t) {
    return t.getDate().getUTCTime();
  });
  var firstTransactionDate = Math.min.apply(Math, _toConsumableArray(transactionDates));
  var lastTransactionDate = Math.max.apply(Math, _toConsumableArray(transactionDates));
  var totalDays = (lastTransactionDate - firstTransactionDate) / 3600 / 24 / 1000;
  var totalOutflow = transactions.map(function (t) {
    return -t.amount;
  }).reduce(function (outflow, amount) {
    return outflow + amount;
  }, 0);
  var avgDailyOutflow = totalOutflow / totalDays;
  var avgDailyTransactions = transactions.length / totalDays;

  var daysOfBuffering = Math.floor(totalBudget / avgDailyOutflow);
  if (daysOfBuffering < 10) {
    daysOfBuffering = (totalBudget / avgDailyOutflow).toFixed(1);
  }

  if (totalDays < 15) {
    return { ableToGenerate: false };
  }

  return {
    daysOfBuffering: daysOfBuffering,
    totalOutflow: totalOutflow,
    totalDays: totalDays,
    avgDailyOutflow: avgDailyOutflow,
    avgDailyTransactions: avgDailyTransactions,
    ableToGenerate: true
  };
}

/***/ }),
/* 436 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.isTransfer = isTransfer;
function isTransfer(transaction) {
  var masterCategoryId = transaction.get('masterCategoryId');
  var subCategoryId = transaction.get('subCategoryId');

  return masterCategoryId === null || subCategoryId === null;
}

/***/ }),
/* 437 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.shouldRender = exports.render = undefined;

var _toolkit = __webpack_require__(48);

var format = function format() {
  var _ynab$YNABSharedLib$c;

  return (_ynab$YNABSharedLib$c = ynab.YNABSharedLib.currencyFormatter).format.apply(_ynab$YNABSharedLib$c, arguments);
};

var getDobEl = function getDobEl() {
  return document.getElementsByClassName('days-of-buffering')[0];
};

var createDobEl = function createDobEl() {
  var label = (0, _toolkit.i10n)('budget.dob.title', 'Days of Buffering');
  var labelTooltip = (0, _toolkit.i10n)('budget.dob.tooltip', 'Don\'t like AoM? Try this out instead!');
  var elementForDoB = $('<div>', { class: 'budget-header-item budget-header-days days-of-buffering' }).append($('<div>', { class: 'budget-header-days-age' })).append($('<div>', { class: 'budget-header-days-label' }).text(label).prop('title', labelTooltip))[0];

  document.getElementsByClassName('budget-header-flexbox')[0].appendChild(elementForDoB);

  return elementForDoB;
};

var render = function render(_ref) {
  var daysOfBuffering = _ref.daysOfBuffering,
      totalOutflow = _ref.totalOutflow,
      totalDays = _ref.totalDays,
      avgDailyOutflow = _ref.avgDailyOutflow,
      avgDailyTransactions = _ref.avgDailyTransactions,
      ableToGenerate = _ref.ableToGenerate;

  var dobEl = getDobEl() || createDobEl();

  if (ableToGenerate) {
    var dayText = daysOfBuffering === 1.0 ? (0, _toolkit.i10n)('budget.ageOfMoneyDays.one', 'day') : (0, _toolkit.i10n)('budget.ageOfMoneyDays.other', 'days');

    dobEl.children[0].textContent = daysOfBuffering + ' ' + dayText;
    dobEl.children[0].title = (0, _toolkit.i10n)('budget.dob.outflow', 'Total outflow') + ': ' + format(totalOutflow) + '\n' + (0, _toolkit.i10n)('budget.dob.days', 'Total days of budgeting') + ': ' + totalDays + '\n' + (0, _toolkit.i10n)('budget.dob.avgOutflow', 'Average daily outflow') + ': ~' + format(avgDailyOutflow) + '\n' + (0, _toolkit.i10n)('budget.dob.avgTransactions', 'Average daily transactions') + ': ' + avgDailyTransactions.toFixed(1);
  } else {
    dobEl.children[0].textContent = (0, _toolkit.i10n)('budget.ageOfMoneyNotAvailable', '???');
    dobEl.children[0].title = (0, _toolkit.i10n)('budget.dob.noHistory', 'Your budget history is less than 15 days. Go on with YNAB a while.');
  }
};

var shouldRender = function shouldRender(lastRenderTime) {
  var debounce = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1000;

  var timeHasCome = Date.now() - lastRenderTime >= debounce;
  var headerVisible = document.getElementsByClassName('budget-header').length > 0;

  return timeHasCome && headerVisible;
};

exports.render = render;
exports.shouldRender = shouldRender;

/***/ }),
/* 438 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(439);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 439 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".budget-header-days.days-of-buffering {\n  display: block;\n  border-left: 1px solid #0e414c;\n}\n\n.days-of-buffering .budget-header-days-age {\n  white-space: nowrap;\n  color: #23b2ce;\n}\n", ""]);

// exports


/***/ }),
/* 440 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DisplayTargetGoalAmount = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ember = __webpack_require__(13);

var _currency = __webpack_require__(136);

var _ynab = __webpack_require__(6);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var DisplayTargetGoalAmount = exports.DisplayTargetGoalAmount = function (_Feature) {
  _inherits(DisplayTargetGoalAmount, _Feature);

  function DisplayTargetGoalAmount() {
    _classCallCheck(this, DisplayTargetGoalAmount);

    return _possibleConstructorReturn(this, (DisplayTargetGoalAmount.__proto__ || Object.getPrototypeOf(DisplayTargetGoalAmount)).apply(this, arguments));
  }

  _createClass(DisplayTargetGoalAmount, [{
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('budget') !== -1 && this.settings.enabled !== '0';
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      var _this2 = this;

      $('.budget-table-header .budget-table-cell-name').css('position', 'relative');
      $('.budget-table-row.is-sub-category li.budget-table-cell-name').css('position', 'relative');

      $('.budget-table-header .budget-table-cell-name').append($('<div>', { class: 'budget-table-cell-goal' }).css({ position: 'absolute', right: 0, top: '6px' }).append('GOAL'));

      $('.budget-table-row.is-sub-category li.budget-table-cell-name').append($('<div>', { class: 'budget-table-cell-goal currency' }).css({
        background: '-webkit-linear-gradient(left, rgba(255,255,255,0) 0%,rgba(255,255,255,1) 10%,rgba(255,255,255,1) 100%)', position: 'absolute', 'font-size': '80%', 'padding-left': '.75em', 'padding-right': '1px', 'line-height': '2.55em'
      }));

      $('.budget-table-row.is-sub-category').each(function (index, element) {
        var emberId = element.id;
        var viewData = (0, _ember.getEmberView)(emberId).data;
        var subCategory = viewData.subCategory;
        var monthlySubCategoryBudget = viewData.monthlySubCategoryBudget;
        var monthlySubCategoryBudgetCalculation = viewData.monthlySubCategoryBudgetCalculation;

        var goalType = subCategory.get('goalType');
        var monthlyFunding = subCategory.get('monthlyFunding');
        var targetBalance = subCategory.get('targetBalance');
        var targetBalanceDate = monthlySubCategoryBudgetCalculation.get('goalTarget');
        var budgetedAmount = monthlySubCategoryBudget.get('budgeted');
        if (goalType === 'MF') {
          $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').text((0, _currency.formatCurrency)(monthlyFunding));
          if (budgetedAmount > monthlyFunding && _this2.settings.enabled === '1') {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#ff4545' });
          } else if (budgetedAmount >= monthlyFunding) {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#00b300' });
          }
        } else if (goalType === 'TB') {
          $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').text((0, _currency.formatCurrency)(targetBalance));
          if (budgetedAmount > targetBalance && _this2.settings.enabled === '1') {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#ff4545' });
          } else if (budgetedAmount >= targetBalance) {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#00b300' });
          }
        } else if (goalType === 'TBD') {
          $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').text((0, _currency.formatCurrency)(targetBalanceDate));
          if (budgetedAmount > targetBalanceDate && _this2.settings.enabled === '1') {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#ff4545' });
          } else if (budgetedAmount >= targetBalanceDate) {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#00b300' });
          }
        }
      });
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (!this.shouldInvoke()) return;
      if (changedNodes.has('budget-table-cell-budgeted')) {
        $('.budget-table-cell-goal').remove();
        this.invoke();
      }
      if (changedNodes.has('ynab-checkbox-button is-checked') || !changedNodes.has('ynab-checkbox-button is-checked')) {
        $('.budget-table-row.is-sub-category li.budget-table-cell-name .budget-table-cell-goal').css({ background: '-webkit-linear-gradient(left, rgba(255,255,255,0) 0%,rgba(255,255,255,1) 10%,rgba(255,255,255,1) 100%)' });
        $('.budget-table-row.is-checked li.budget-table-cell-name .budget-table-cell-goal').css({ background: '#005a6e' });
      }
    }
  }, {
    key: 'onRouteChanged',
    value: function onRouteChanged() {
      if (!this.shouldInvoke()) return;
      this.invoke();
    }
  }]);

  return DisplayTargetGoalAmount;
}(_feature.Feature);

/***/ }),
/* 441 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EnlargeCategoriesDropdown = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var DEFAULT_ADDITIONAL_HEIGHT = 100; // 4 pixels of padding
var BOTTOM_OF_PAGE_PADDING = 4;

var EnlargeCategoriesDropdown = exports.EnlargeCategoriesDropdown = function (_Feature) {
  _inherits(EnlargeCategoriesDropdown, _Feature);

  function EnlargeCategoriesDropdown() {
    _classCallCheck(this, EnlargeCategoriesDropdown);

    return _possibleConstructorReturn(this, (EnlargeCategoriesDropdown.__proto__ || Object.getPrototypeOf(EnlargeCategoriesDropdown)).apply(this, arguments));
  }

  _createClass(EnlargeCategoriesDropdown, [{
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('budget') > -1;
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      var modal = $('.categories-dropdown-container .dropdown-modal');
      if (modal.length) {
        var totalAdditionalHeight = DEFAULT_ADDITIONAL_HEIGHT + BOTTOM_OF_PAGE_PADDING;
        var currentTop = parseInt(modal.css('top'));
        var spaceAvailableAboveModal = $(window).height() - (modal.offset().top - modal.outerHeight());
        var spaceAvailableBelowModal = $(window).height() - (modal.offset().top + modal.outerHeight());

        // modal is shown above autocomplete
        if (currentTop < 0) {
          if (spaceAvailableAboveModal < totalAdditionalHeight) {
            // pad the bottom of the screen with 4 pixels here.
            modal.css({
              height: '+=' + (spaceAvailableAboveModal - BOTTOM_OF_PAGE_PADDING),
              top: '-=' + (spaceAvailableAboveModal - BOTTOM_OF_PAGE_PADDING)
            });
          } else if (spaceAvailableAboveModal >= totalAdditionalHeight) {
            modal.css({
              height: '+=' + DEFAULT_ADDITIONAL_HEIGHT,
              top: '-=' + DEFAULT_ADDITIONAL_HEIGHT
            });
          }
        } else if (spaceAvailableBelowModal < totalAdditionalHeight) {
          modal.css({ height: '+=' + (spaceAvailableBelowModal - BOTTOM_OF_PAGE_PADDING) });
        } else if (spaceAvailableBelowModal >= totalAdditionalHeight) {
          modal.css({ height: '+=' + DEFAULT_ADDITIONAL_HEIGHT });
        }
      }
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (!this.shouldInvoke()) {
        return;
      }

      if (changedNodes.has('dropdown-container categories-dropdown-container')) {
        this.invoke();
      }
    }
  }]);

  return EnlargeCategoriesDropdown;
}(_feature.Feature);

/***/ }),
/* 442 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EnterToMove = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var MOVE_POPUP = 'ynab-u modal-popup modal-budget modal-budget-move-money ember-view modal-overlay active';
var CATEGORY_DROPDOWN = 'dropdown-container categories-dropdown-container';
var BUTTON_PRIMARY = 'button button-primary ';
var BUTTON_CANCEL = 'button button-cancel';
var MODAL_CONTENT = 'modal-content';

var EnterToMove = exports.EnterToMove = function (_Feature) {
  _inherits(EnterToMove, _Feature);

  function EnterToMove() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, EnterToMove);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = EnterToMove.__proto__ || Object.getPrototypeOf(EnterToMove)).call.apply(_ref, [this].concat(args))), _this), _this.modalIsOpen = false, _this.onKeyDown = function (e) {
      var keycode = e.keycode || e.which;
      if (keycode === 13) {
        var OK = $('.modal-budget-move-money .modal-actions button:first-child');
        OK.click();
      }
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(EnterToMove, [{
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('budget') !== -1;
    }
  }, {
    key: 'invoke',
    value: function invoke() {}
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (!this.shouldInvoke()) return;

      if (changedNodes.has(MOVE_POPUP)) {
        this.modalIsOpen = true;
      }

      if (this.modalIsOpen && changedNodes.has(CATEGORY_DROPDOWN) && changedNodes.has(BUTTON_PRIMARY)) {
        // Ready to click button
        document.addEventListener('keydown', this.onKeyDown, false);
      }

      if (this.modalIsOpen && changedNodes.has(BUTTON_PRIMARY) && changedNodes.has(BUTTON_CANCEL) && changedNodes.has(MODAL_CONTENT)) {
        // Modal has closed
        this.modalIsOpen = false;
        document.removeEventListener('keydown', this.onKeyDown, false);
      }
    }
  }]);

  return EnterToMove;
}(_feature.Feature);

/***/ }),
/* 443 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.GoalWarningColor = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var GoalWarningColor = exports.GoalWarningColor = function (_Feature) {
  _inherits(GoalWarningColor, _Feature);

  function GoalWarningColor() {
    _classCallCheck(this, GoalWarningColor);

    return _possibleConstructorReturn(this, (GoalWarningColor.__proto__ || Object.getPrototypeOf(GoalWarningColor)).apply(this, arguments));
  }

  _createClass(GoalWarningColor, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(444);
    }
  }]);

  return GoalWarningColor;
}(_feature.Feature);

/***/ }),
/* 444 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(445);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 445 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, "/* row */\n.budget-table-row.toolkit-row-goal.toolkit-row-availablepositive:not(.toolkit-row-upcoming) .budget-table-cell-available .cautious,\n.budget-table-row.toolkit-row-goal.toolkit-row-availablezero:not(.toolkit-row-upcoming) .budget-table-cell-available .cautious {\n\tbackground-color: #009cc2;\n}\n.budget-table-row.toolkit-row-goal.toolkit-row-availablepositive:not(.toolkit-row-upcoming) .budget-table-cell-available .cautious:hover,\n.budget-table-row.toolkit-row-goal.toolkit-row-availablezero:not(.toolkit-row-upcoming) .budget-table-cell-available .cautious:hover {\n\tbackground-color: #1f8ca7;\n}\n\n/* inspector */\n.budget-inspector-category-overview .toolkit-row-goal.toolkit-row-availablepositive:not(.toolkit-row-upcoming) dt.cautious,\n.budget-inspector-category-overview .toolkit-row-goal.toolkit-row-availablezero:not(.toolkit-row-upcoming) dt.cautious {\n\tcolor: #009cc2;\n}\n.budget-inspector-category-overview .toolkit-row-goal.toolkit-row-availablepositive:not(.toolkit-row-upcoming) dd .cautious,\n.budget-inspector-category-overview .toolkit-row-goal.toolkit-row-availablezero:not(.toolkit-row-upcoming) dd .cautious {\n\tbackground: #009cc2;\n}\n\n/* goal */\n.goal-warning .inner-circle {\n\tstroke: #43aecb;\t\n}\n.goal-warning .outer-circle {\n\tfill: #1f8ca7;\n}\n", ""]);

// exports


/***/ }),
/* 446 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.HideAgeOfMoney = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var HideAgeOfMoney = exports.HideAgeOfMoney = function (_Feature) {
  _inherits(HideAgeOfMoney, _Feature);

  function HideAgeOfMoney() {
    _classCallCheck(this, HideAgeOfMoney);

    return _possibleConstructorReturn(this, (HideAgeOfMoney.__proto__ || Object.getPrototypeOf(HideAgeOfMoney)).apply(this, arguments));
  }

  _createClass(HideAgeOfMoney, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(447);
    }
  }]);

  return HideAgeOfMoney;
}(_feature.Feature);

/***/ }),
/* 447 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(448);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 448 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".budget-header-days {\n\tdisplay: none;\n\tborder-left: none;\n}\n", ""]);

// exports


/***/ }),
/* 449 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CurrentMonthIndicator = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var CurrentMonthIndicator = exports.CurrentMonthIndicator = function (_Feature) {
  _inherits(CurrentMonthIndicator, _Feature);

  function CurrentMonthIndicator() {
    _classCallCheck(this, CurrentMonthIndicator);

    return _possibleConstructorReturn(this, (CurrentMonthIndicator.__proto__ || Object.getPrototypeOf(CurrentMonthIndicator)).apply(this, arguments));
  }

  _createClass(CurrentMonthIndicator, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(450);
    }
  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('budget') !== -1;
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      if (this.inCurrentMonth()) {
        $('.budget-header .budget-header-calendar').addClass('toolkit-highlight-current-month');
      } else {
        $('.budget-header .budget-header-calendar').removeClass('toolkit-highlight-current-month');
      }
    }
  }, {
    key: 'inCurrentMonth',
    value: function inCurrentMonth() {
      var today = new Date();
      var selectedMonth = ynabToolKit.shared.parseSelectedMonth();
      if (selectedMonth === null) return false;
      return selectedMonth.getMonth() === today.getMonth() && selectedMonth.getYear() === today.getYear();
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (!this.shouldInvoke()) return;

      if (changedNodes.has('budget-header-item budget-header-calendar') || changedNodes.has('budget-header-totals-cell-value user-data')) {
        this.invoke();
      }
    }
  }, {
    key: 'onRouteChanged',
    value: function onRouteChanged() {
      if (!this.shouldInvoke()) return;
      this.invoke();
    }
  }]);

  return CurrentMonthIndicator;
}(_feature.Feature);

/***/ }),
/* 450 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(451);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 451 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, "/* add transitions */\n.budget-header .budget-header-item {\n\tpadding: .7em .6em .6em;\n\t-moz-transition: background-color .3s linear;\n\t-webkit-transition: background-color .3s linear;\n\t-o-transition: background-color .3s linear;\n\ttransition: background-color .3s linear;\n}\n.budget-header .budget-header-item .budget-header-calendar-prev,\n.budget-header .budget-header-item .budget-header-calendar-next,\n.budget-header .budget-header-item .flaticon,\n.budget-header .budget-header-item .budget-header-calendar-note {\n\t-moz-transition: color .2s linear;\n\t-webkit-transition: color .2s linear;\n\t-o-transition: color .2s linear;\n\ttransition: color .2s linear;\n}\n\n/* current month styles */\n.toolkit-highlight-current-month {\n\tbackground: #00596f !important;\n}\n.budget-header .toolkit-highlight-current-month .budget-header-calendar-prev, \n.budget-header .toolkit-highlight-current-month .budget-header-calendar-next,\n.budget-header .toolkit-highlight-current-month .flaticon {\n\tcolor: #bee6ef;\n}\n.budget-header .toolkit-highlight-current-month:hover .flaticon:not(.disabled) {\n\tcolor: #fff;\n}\n.budget-header .toolkit-highlight-current-month .budget-header-calendar-note {\n\tcolor: rgba(255,255,255,0.4);\n}", ""]);

// exports


/***/ }),
/* 452 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.IncomeFromLastMonth = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var IncomeFromLastMonth = exports.IncomeFromLastMonth = function (_Feature) {
  _inherits(IncomeFromLastMonth, _Feature);

  function IncomeFromLastMonth() {
    _classCallCheck(this, IncomeFromLastMonth);

    return _possibleConstructorReturn(this, (IncomeFromLastMonth.__proto__ || Object.getPrototypeOf(IncomeFromLastMonth)).apply(this, arguments));
  }

  _createClass(IncomeFromLastMonth, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(453);
    }
  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('budget') !== -1;
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      // Do nothing if no header found.
      if ($('.budget-header-totals-details-values').length === 0) return;
      var selectedMonth = ynabToolKit.shared.parseSelectedMonth().getMonth();
      var previousMonth = selectedMonth - Number(this.settings.enabled);
      var previousYear = ynabToolKit.shared.parseSelectedMonth().getFullYear();
      if (previousMonth < 0) {
        previousMonth += 12;
        previousYear -= 1;
      }

      var previousMonthName = ynabToolKit.shared.monthsShort[previousMonth];

      var entityManager = ynab.YNABSharedLib.defaultInstance.entityManager;
      var transactions = entityManager.getAllTransactions();
      var income = transactions.filter(function (el) {
        return !el.isTombstone && el.transferAccountId === null && el.amount > 0 && el.date.getYear() === previousYear && el.date.getMonth() === previousMonth && el.getAccount().onBudget && el.getSubCategory() && el.getSubCategory().isIncomeCategory();
      });

      var total = Array.from(income, function (i) {
        return i.amount;
      }).reduce(function (a, b) {
        return a + b;
      }, 0);

      if ($('.income-from-last-month').length === 0) {
        // jscs:disable disallowMultipleLineStrings
        $('.budget-header-totals-details-values').prepend('\n        <div class="budget-header-totals-cell-value income-from-last-month user-data">\n          <span class="user-data currency positive"></span>\n        </div>');
        $('.budget-header-totals-details-names').prepend('<div class="budget-header-totals-cell-name income-from-last-month" style="padding-left: .3em; text-align:left"></div>');
      }

      $('.budget-header-totals-cell-value.income-from-last-month span').html((total < 0 ? '-' : '+') + ynabToolKit.shared.formatCurrency(total, true));
      $('.budget-header-totals-details-names>.income-from-last-month')[0].textContent = (ynabToolKit.l10nData && ynabToolKit.l10nData['toolkit.incomeFrom'] || 'Income from') + ' ' + previousMonthName;
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (!this.shouldInvoke()) return;

      // User has returned back to the budget screen
      // User switch budget month
      if (changedNodes.has('budget-header-flexbox') || changedNodes.has('budget-table') || changedNodes.has('layout user-logged-in')) {
        this.invoke();
      }
    }
  }]);

  return IncomeFromLastMonth;
}(_feature.Feature);

/***/ }),
/* 453 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(454);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 454 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".budget-header-item.budget-header-totals {\n\tpadding-top: 4px;\n\tpadding-bottom: 4px;\n}\n", ""]);

// exports


/***/ }),
/* 455 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.MonthlyNotesPopupWidth = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var MonthlyNotesPopupWidth = exports.MonthlyNotesPopupWidth = function (_Feature) {
  _inherits(MonthlyNotesPopupWidth, _Feature);

  function MonthlyNotesPopupWidth() {
    _classCallCheck(this, MonthlyNotesPopupWidth);

    return _possibleConstructorReturn(this, (MonthlyNotesPopupWidth.__proto__ || Object.getPrototypeOf(MonthlyNotesPopupWidth)).apply(this, arguments));
  }

  _createClass(MonthlyNotesPopupWidth, [{
    key: 'injectCSS',
    value: function injectCSS() {
      if (this.settings.enabled === '1') {
        return __webpack_require__(456);
      } else if (this.settings.enabled === '2') {
        return __webpack_require__(458);
      }
    }
  }]);

  return MonthlyNotesPopupWidth;
}(_feature.Feature);

/***/ }),
/* 456 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(457);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 457 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, "body .modal-budget-note .modal {\n\twidth: 24em !important;\n}", ""]);

// exports


/***/ }),
/* 458 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(459);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 459 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, "body .modal-budget-note .modal {\n\twidth: 34em !important;\n}", ""]);

// exports


/***/ }),
/* 460 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.QuickBudgetWarning = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var QuickBudgetWarning = exports.QuickBudgetWarning = function (_Feature) {
  _inherits(QuickBudgetWarning, _Feature);

  function QuickBudgetWarning() {
    _classCallCheck(this, QuickBudgetWarning);

    return _possibleConstructorReturn(this, (QuickBudgetWarning.__proto__ || Object.getPrototypeOf(QuickBudgetWarning)).apply(this, arguments));
  }

  _createClass(QuickBudgetWarning, [{
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('budget') > -1;
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      // target only buttons so other elements with same class can be added without forcing
      // confirmation, which can break the quick budget functionality for quick budget
      // items added by the Toolkit
      $('button.budget-inspector-button').off('click', this.confirmClick);
      $('button.budget-inspector-button').on('click', this.confirmClick);
    }
  }, {
    key: 'confirmClick',
    value: function confirmClick(event) {
      // if nothing is budgeted, skip the confirmation
      var allZero = true;
      $('div.budget-table ul.budget-table-row.is-checked li.budget-table-cell-budgeted .currency').each(function () {
        if (!$(this).hasClass('zero')) {
          allZero = false;
        }
      });
      if (allZero === true) {
        return;
      }

      if (!window.confirm('Are you sure you want to budget this amount?')) {
        // eslint-disable-line no-alert
        event.preventDefault();
        event.stopPropagation();
      }
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (changedNodes.has('navlink-budget active') || changedNodes.has('budget-inspector') || changedNodes.has('inspector-quick-budget')) {
        this.invoke();
      }
    }
  }]);

  return QuickBudgetWarning;
}(_feature.Feature);

/***/ }),
/* 461 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.RemovePositiveHighlight = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var RemovePositiveHighlight = exports.RemovePositiveHighlight = function (_Feature) {
  _inherits(RemovePositiveHighlight, _Feature);

  function RemovePositiveHighlight() {
    _classCallCheck(this, RemovePositiveHighlight);

    return _possibleConstructorReturn(this, (RemovePositiveHighlight.__proto__ || Object.getPrototypeOf(RemovePositiveHighlight)).apply(this, arguments));
  }

  _createClass(RemovePositiveHighlight, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(462);
    }
  }]);

  return RemovePositiveHighlight;
}(_feature.Feature);

/***/ }),
/* 462 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(463);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 463 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".budget-table-row.is-sub-category > .budget-table-cell-available .positive,\n.budget-table-row.is-sub-category.is-checked.goal-progress > .budget-table-cell-available .positive {\n\tbackground-color: transparent;\n\tcolor: #16a336;\n\tfont-weight: bold;\n}\n\n.budget-table-row.is-sub-category > .budget-table-cell-available .positive:hover,\n.inspector-overview-available .positive {\n\tbackground-color: transparent;\n\tcolor: #138b2e;\n}\n\n.budget-table-row.is-sub-category > .budget-table-cell-available .zero {\n\tbackground-color: transparent;\n\tcolor: #cfd5d8;\n\tfont-weight: normal;\n}\n\n.budget-table-row.is-sub-category.is-checked.goal-progress > .budget-table-cell-available .positive\n{\n\tcolor: #16a336;\n\tfont-weight: bold;\n}\n\n.budget-table-row.is-sub-category.is-checked > .budget-table-cell-available .positive,\n.budget-table-row.is-sub-category.is-checked > .budget-table-cell-available .zero {\n\tcolor: #fff;\n}\n\n\n", ""]);

// exports


/***/ }),
/* 464 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.RemoveZeroCategories = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var RemoveZeroCategories = exports.RemoveZeroCategories = function (_Feature) {
  _inherits(RemoveZeroCategories, _Feature);

  function RemoveZeroCategories() {
    _classCallCheck(this, RemoveZeroCategories);

    return _possibleConstructorReturn(this, (RemoveZeroCategories.__proto__ || Object.getPrototypeOf(RemoveZeroCategories)).apply(this, arguments));
  }

  _createClass(RemoveZeroCategories, [{
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('budget') > -1;
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      var coverOverbudgetingCategories = $('.modal-budget-overspending .dropdown-list > li');
      coverOverbudgetingCategories.each(function () {
        var t = $(this).find('.category-available').text(); // Category balance text.
        var categoryBalance = parseInt(t.replace(/[^\d-]/g, ''));
        if (categoryBalance <= 0) {
          $(this).remove();
        }
      });

      coverOverbudgetingCategories = $('.modal-budget-overspending .dropdown-list > li');

      // Remove empty sections.
      for (var i = 0; i < coverOverbudgetingCategories.length - 1; i++) {
        if ($(coverOverbudgetingCategories[i]).hasClass('section-item') && $(coverOverbudgetingCategories[i + 1]).hasClass('section-item')) {
          $(coverOverbudgetingCategories[i]).remove();
        }
      }

      // Remove last section empty.
      if (coverOverbudgetingCategories.last().hasClass('section-item')) {
        coverOverbudgetingCategories.last().remove();
      }
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (!this.shouldInvoke()) {
        return;
      }

      if (changedNodes.has('dropdown-container categories-dropdown-container')) {
        this.invoke();
      }
    }
  }]);

  return RemoveZeroCategories;
}(_feature.Feature);

/***/ }),
/* 465 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ResizeInspector = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _toolkit = __webpack_require__(48);

var _ynab = __webpack_require__(6);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var HIDEIMAGE = 'toolkit-modal-item-hide-image';
var BUTTONDISABLED = 'button-disabled';
var IMAGECLASSES = 'ember-view toolkit-menu-item toolkit-modal-item-hide-image flaticon stroke checkmark-1';

var ResizeInspector = exports.ResizeInspector = function (_Feature) {
  _inherits(ResizeInspector, _Feature);

  function ResizeInspector() {
    _classCallCheck(this, ResizeInspector);

    return _possibleConstructorReturn(this, (ResizeInspector.__proto__ || Object.getPrototypeOf(ResizeInspector)).apply(this, arguments));
  }

  _createClass(ResizeInspector, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(466);
    }
  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().includes('budget');
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      var width = (0, _toolkit.getToolkitStorageKey)('inspector-width', 'number');
      if (typeof width === 'undefined' || width === null) {
        width = 0;
      }

      this.setProperties(width);
      this.addResizeButton();
    }
  }, {
    key: 'addResizeButton',
    value: function addResizeButton() {
      var _this3 = this;

      if (!$('#toolkitResizeInspector').length) {
        var buttonText = ynabToolKit.l10nData && ynabToolKit.l10nData['toolkit.InspectorWidth'] || 'Inspector Width';
        $('<button>', { id: 'toolkitResizeInspector', class: 'ember-view button', style: 'float: right' }).append($('<i>', { class: 'ember-view flaticon stroke gear-1' })).append(' ' + buttonText).click(function () {
          _this3.showResizeModal();
        }).insertAfter('.undo-redo-container');
      }
    }
  }, {
    key: 'showResizeModal',
    value: function showResizeModal() {
      var _this = this;
      var btnLeft = $('.budget-toolbar').outerWidth() + $('#toolkitResizeInspector').outerWidth() + 29;
      var btnTop = $('.budget-toolbar').outerHeight() + $('.budget-header-flexbox').outerHeight() + 8;
      var $modal = $('<div>', { id: 'toolkitInspectorODiv', class: 'ember-view' }).append($('<div>', { id: 'toolkitInspectorModal', class: 'ynab-u modal-popup modal-resize-inspector ember-view modal-overlay active' }).append($('<div>', { id: 'toolkitInspectorIDiv', class: 'modal', style: 'left:' + btnLeft + 'px; top: ' + btnTop + 'px;' }).append($('<ul>', { class: 'modal-list' }).append($('<li>').append($('<button>', { 'data-inspector-size': '0', class: 'button-list' }).click(function () {
        _this.setProperties($(this).data('inspector-size'));
      }).append($('<i>', { class: IMAGECLASSES })).append('Default '))).append($('<li>').append($('<button>', { 'data-inspector-size': '1', class: 'button-list' }).click(function () {
        _this.setProperties($(this).data('inspector-size'));
      }).append($('<i>', { class: IMAGECLASSES })).append('25% '))).append($('<li>').append($('<button>', { 'data-inspector-size': '2', class: 'button-list' }).click(function () {
        _this.setProperties($(this).data('inspector-size'));
      }).append($('<i>', { class: IMAGECLASSES })).append('20% '))).append($('<li>').append($('<button>', { 'data-inspector-size': '3', class: 'button-list' }).click(function () {
        _this.setProperties($(this).data('inspector-size'));
      }).append($('<i>', { class: IMAGECLASSES })).append('15% ')))).append($('<div>', { class: 'modal-arrow', style: 'position:absolute;width: 0;height: 0;bottom: 100%;left: 37px;border: solid transparent;border-color: transparent;border-width: 15px;border-bottom-color: #fff' }))));

      // Handle dismissal of modal via the ESC key
      $(document).one('keydown', function (e) {
        if (e.keyCode === 27) {
          // ESC key?
          $(document).off('click.toolkitResizeInspector');
          $('#toolkitInspectorODiv').remove();
        }
      });

      // Handle mouse clicks outside the drop-down modal. Namespace the
      // click event so we can remove our specific instance.
      $(document).on('click.toolkitResizeInspector', function (e) {
        if (e.target.id === 'toolkitInspectorModal') {
          $(document).off('click.toolkitResizeInspector');
          $('#toolkitInspectorODiv').remove();
        }
      });

      var width = (0, _toolkit.getToolkitStorageKey)('inspector-width', 'number');
      var btn = $modal.find('button[data-inspector-size="' + width + '"]');
      btn.prop('disabled', true);
      btn.addClass(BUTTONDISABLED);
      var img = $modal.find('button[data-inspector-size="' + width + '"] > i');
      img.removeClass(HIDEIMAGE);

      // Don't append until all the menu items have been set.
      $('.layout').append($modal);
    }
  }, {
    key: 'setProperties',
    value: function setProperties(width) {
      var ele = '.budget-content';

      if (YNABFEATURES.get('categories-new-style') === undefined || YNABFEATURES.get('categories-new-style') === true) {
        ele = '.budget-table-container';
      }

      if ($(ele).length) {
        var contentWidth = '67%';
        var inspectorWidth = '33%';

        if (width === 1) {
          contentWidth = '75%';
          inspectorWidth = '25%';
        } else if (width === 2) {
          contentWidth = '80%';
          inspectorWidth = '20%';
        } else if (width === 3) {
          contentWidth = '85%';
          inspectorWidth = '15%';
        }

        $(ele)[0].style.setProperty('--toolkit-content-width', contentWidth);
        $('.budget-inspector')[0].style.setProperty('--toolkit-inspector-width', inspectorWidth);

        // Save the users current selection for future page loads.
        (0, _toolkit.setToolkitStorageKey)('inspector-width', width);

        // Remove our click event handler and the modal div.
        $(document).off('click.toolkitInspector');
        $('#toolkitInspectorODiv').remove();
      }
    }
  }, {
    key: 'onBudgetChanged',
    value: function onBudgetChanged() {
      if (!this.shouldInvoke()) return;
      this.invoke();
    }
  }, {
    key: 'onRouteChanged',
    value: function onRouteChanged() {
      if (!this.shouldInvoke()) return;
      this.invoke();
    }
  }]);

  return ResizeInspector;
}(_feature.Feature);

/***/ }),
/* 466 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(467);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 467 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".budget-content {\n  width: var(--toolkit-content-width, 75%) !important; /* default to our widest width */\n}\n\n/* new categories style element name - not all users have the new categories at the time this was added! */\nsection.budget-table-container {\n  width: var(--toolkit-content-width, 75%) !important; /* default to our widest width */\n}\n\n.budget-inspector {\n  min-width: var(--toolkit-inspector-minwidth, inherit) !important;\n  width: var(--toolkit-inspector-width, 25%) !important; /* default to our widest width */\n}\n\n.toolkit-modal-item-hide-image {\n  visibility: hidden;\n}\n\n.modal-resize-inspector {\n  background-color: transparent;\n}\n\n.modal-resize-inspector .modal {\n  padding: .3em 0;\n  width: 7em;\n  font-size: .9em;\n}\n", ""]);

// exports


/***/ }),
/* 468 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.RowsHeight = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var RowsHeight = exports.RowsHeight = function (_Feature) {
  _inherits(RowsHeight, _Feature);

  function RowsHeight() {
    _classCallCheck(this, RowsHeight);

    return _possibleConstructorReturn(this, (RowsHeight.__proto__ || Object.getPrototypeOf(RowsHeight)).apply(this, arguments));
  }

  _createClass(RowsHeight, [{
    key: 'injectCSS',
    value: function injectCSS() {
      if (this.settings.enabled === '1') {
        return __webpack_require__(469);
      } else if (this.settings.enabled === '2') {
        return __webpack_require__(471);
      } else if (this.settings.enabled === '3') {
        return __webpack_require__(473);
      }
    }
  }]);

  return RowsHeight;
}(_feature.Feature);

/***/ }),
/* 469 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(470);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 470 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".budget-content ul.budget-table-header {\n  height: 1.6em !important;\n}\n\n.budget-table-row.is-master-category {\n  margin-top: 0px;\n  height: 2em !important;\n}\n\n.budget-content ul, .budget-table-row.is-dragging {\n  height: 2em;\n}\n\n.budget-table-row.is-master-category .budget-table-cell-add-category .flaticon {\n  top: 0.25em;\n}\n\n.budget-table-row.is-master-category .budget-table-cell-name {\n  line-height: 2em !important;\n  padding-top: 0 !important;\n  font-size: 1.05em !important;\n  align-items: center !important;\n}\n\n.budget-table-row.is-sub-category {\n  height: 1.8em !important;\n}\n\n.budget-table-row.is-sub-category > .budget-table-cell-available .positive, .budget-table-row.is-sub-category > .budget-table-cell-available .negative, .budget-table-row.is-sub-category > .budget-table-cell-available .cautious, .budget-table-row.is-sub-category > .budget-table-cell-available .zero {\n  top: 0 !important;\n  padding: 0.1em 0.3em;\n}\n\n.budget-table-row.is-sub-category .budget-table-cell-activity {\n  top: 0 !important;\n}\n\n.budget-table-cell-budgeted .js-edit-currency-input {\n  padding: 0 !important;\n}\n\n.budget-table-cell-budgeted .currency-input span {\n  height: 1.8em;\n}\n\n.budget-table .is-debt-payment-category .budget-table-cell-available {\n  flex-direction: row;\n  align-items: center;\n  justify-content: flex-end;\n}\n\n.budget-table .is-debt-payment-category .budget-table-cell-available .budget-table-cell-available-payment {\n  margin-right: 0.25em;\n}\n\n.toolkit-goalindicator {\n  line-height: 1.8em !important;\n}\n", ""]);

// exports


/***/ }),
/* 471 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(472);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 472 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".budget-content ul, .budget-table-row.is-dragging {\n  height: 1.8em;\n}\n\n.budget-table-row.is-master-category {\n  margin-top: 0px;\n  height: 1.8em !important;\n}\n\n.budget-table-row.is-master-category .budget-table-cell-name {\n  line-height: 1.8em !important;\n  padding-top: 0 !important;\n  font-size: 1em !important;\n  align-items: center !important;\n}\n\n.budget-table-row.is-master-category .budget-table-cell-add-category .flaticon {\n  top: 0.2em;\n}\n\n.budget-table-row.is-sub-category {\n  height: 1.6em !important;\n}\n\n.budget-table-row.is-sub-category > .budget-table-cell-available .positive, .budget-table-row.is-sub-category > .budget-table-cell-available .negative, .budget-table-row.is-sub-category > .budget-table-cell-available .cautious, .budget-table-row.is-sub-category > .budget-table-cell-available .zero {\n  top: 0 !important;\n  padding: 0em 0.4em !important;\n  font-size: 1em !important;\n}\n\n.budget-table-row.is-sub-category .budget-table-cell-activity {\n  top: 0 !important;\n}\n\n.budget-table-cell-budgeted .currency-input span {\n  height: 1.45em;\n  padding: 0.05em;\n  border-width: 1px !important;\n}\n\n.budget-table-cell-budgeted .js-edit-currency-input {\n  padding: 0 !important;\n}\n\n.budget-table-cell-budgeted .currency-input input {\n  height: 1.45em !important;\n}\n\n.budget-table .is-debt-payment-category .budget-table-cell-available {\n  flex-direction: row;\n  align-items: center;\n  justify-content: flex-end;\n}\n\n.budget-table .is-debt-payment-category .budget-table-cell-available .budget-table-cell-available-payment {\n  margin-right: 0.25em;\n}\n\n.icon-calculator {\n  max-width: 1em;\n  max-height: 1em;\n}\n\n.toolkit-goalindicator {\n  line-height: 1.8em !important;\n}\n", ""]);

// exports


/***/ }),
/* 473 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(474);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 474 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".budget-content ul, .budget-table-row.is-dragging {\n  height: 1.8em;\n}\n\n.budget-table-row.is-master-category {\n  margin-top: 0px;\n  height: 1.8em !important;\n}\n\n.budget-table-row.is-master-category .budget-table-cell-name {\n  line-height: 1.8em !important;\n  padding-top: 0 !important;\n  font-size: 1em !important;\n  align-items: center !important;\n}\n\n.budget-table-row.is-master-category .budget-table-cell-add-category .flaticon {\n  top: 0.2em;\n}\n\n.budget-table-row.is-sub-category {\n  height: 1.6em !important;\n  font-size: 0.78em;\n}\n\n.budget-table-row.is-sub-category > .budget-table-cell-available .positive, .budget-table-row.is-sub-category > .budget-table-cell-available .negative, .budget-table-row.is-sub-category > .budget-table-cell-available .cautious, .budget-table-row.is-sub-category > .budget-table-cell-available .zero {\n  top: 0 !important;\n  padding: 0em 0.4em !important;\n  font-size: 1em !important;\n}\n\n.budget-table-row.is-sub-category .budget-table-cell-activity {\n  top: 0 !important;\n}\n\n.budget-table-cell-budgeted .currency-input span {\n  height: 1.45em;\n  padding: 0.05em;\n  border-width: 1px !important;\n}\n\n.budget-table-cell-budgeted .js-edit-currency-input {\n  padding: 0 !important;\n}\n\n.budget-table-cell-budgeted .currency-input input {\n  height: 1.45em !important;\n}\n\n.budget-table .is-debt-payment-category .budget-table-cell-available {\n  flex-direction: row;\n  align-items: center;\n  justify-content: flex-end;\n}\n\n.budget-table .is-debt-payment-category .budget-table-cell-available .budget-table-cell-available-payment {\n  margin-right: 0.25em;\n}\n\n.icon-calculator {\n  max-width: 1em;\n  max-height: 1em;\n}\n\n.toolkit-goalindicator {\n  line-height: 1.8em !important;\n}\n", ""]);

// exports


/***/ }),
/* 475 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SeamlessBudgetHeader = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var SeamlessBudgetHeader = exports.SeamlessBudgetHeader = function (_Feature) {
  _inherits(SeamlessBudgetHeader, _Feature);

  function SeamlessBudgetHeader() {
    _classCallCheck(this, SeamlessBudgetHeader);

    return _possibleConstructorReturn(this, (SeamlessBudgetHeader.__proto__ || Object.getPrototypeOf(SeamlessBudgetHeader)).apply(this, arguments));
  }

  _createClass(SeamlessBudgetHeader, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(476);
    }
  }]);

  return SeamlessBudgetHeader;
}(_feature.Feature);

/***/ }),
/* 476 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(477);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 477 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".budget-header .budget-header-item {\n\tborder-left: 0px;\n}\n", ""]);

// exports


/***/ }),
/* 478 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.StealingFromFuture = undefined;

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

var _ember = __webpack_require__(13);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

// TODO: move income-from-last-month to the new framework and just export this
// variable from that feature
var INCOME_FROM_LAST_MONTH_CLASSNAME = 'income-from-last-month';

var StealingFromFuture = exports.StealingFromFuture = function (_Feature) {
  _inherits(StealingFromFuture, _Feature);

  function StealingFromFuture() {
    _classCallCheck(this, StealingFromFuture);

    return _possibleConstructorReturn(this, (StealingFromFuture.__proto__ || Object.getPrototypeOf(StealingFromFuture)).apply(this, arguments));
  }

  _createClass(StealingFromFuture, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(479);
    }
  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('budget') !== -1;
    }
  }, {
    key: 'isMonthABeforeB',
    value: function isMonthABeforeB(a, b) {
      if (b === null) return true;

      var _a$split$map = a.split('-').map(function (val) {
        return parseInt(val);
      }),
          _a$split$map2 = _slicedToArray(_a$split$map, 2),
          yearA = _a$split$map2[0],
          monthA = _a$split$map2[1];

      var _b$split$map = b.split('-').map(function (val) {
        return parseInt(val);
      }),
          _b$split$map2 = _slicedToArray(_b$split$map, 2),
          yearB = _b$split$map2[0],
          monthB = _b$split$map2[1];

      if (yearA >= yearB && monthA >= monthB) {
        return false;
      }

      return true;
    }
  }, {
    key: 'onAvailableToBudgetChange',
    value: function onAvailableToBudgetChange(budgetViewModel) {
      var _this2 = this;

      var earliestEntityDate = null;
      var earliestNegativeMonth = null;
      var earliestNegativeMonthCalculation = null;
      budgetViewModel.get('allBudgetMonthsViewModel.monthlyBudgetCalculationsCollection').forEach(function (monthCalculation) {
        if (_this2.isMonthEntityIdFuture(monthCalculation.get('entityId'))) {
          var entityDate = monthCalculation.get('entityId').match(/mbc\/(.*)\/.*/)[1];
          var entityMonth = entityDate.split('-').map(function (val) {
            return parseInt(val);
          })[1];

          if (monthCalculation.get('availableToBudget') < 0 && _this2.isMonthABeforeB(entityDate, earliestEntityDate)) {
            earliestEntityDate = entityDate;
            earliestNegativeMonth = entityMonth;
            earliestNegativeMonthCalculation = monthCalculation;
          }
        }
      });

      // there's no easy class name on the thing we want to highlight so
      // we have to just select the specific row. if the user has the income
      // from last month feature on and it has already invoked, then the row
      // we want is number 4, else 3.
      var futureBudgetRow = 3;
      if (ynabToolKit.options.incomeFromLastMonth !== '0') {
        if ($('.budget-header-totals-details-values .' + INCOME_FROM_LAST_MONTH_CLASSNAME).length) {
          futureBudgetRow = 4;
        }
      }

      var value = $('.budget-header-totals-details-values .budget-header-totals-cell-value').eq(futureBudgetRow);
      var name = $('.budget-header-totals-details-names .budget-header-totals-cell-name').eq(futureBudgetRow);

      // no negative months! good job team!
      if (earliestNegativeMonth === null) {
        value.removeClass('ynabtk-stealing-from-next-month');
        name.removeClass('ynabtk-stealing-from-next-month');
        $('#ynabtk-stealing-amount', name).remove();
        return;
      }

      value.addClass('ynabtk-stealing-from-next-month');
      name.addClass('ynabtk-stealing-from-next-month');

      var availableToBudget = earliestNegativeMonthCalculation.getAvailableToBudget();
      $('#ynabtk-stealing-amount', name).remove();
      name.append('<span id="ynabtk-stealing-amount"> (' + '<strong>' + (ynab.formatCurrency(availableToBudget) + ' in ') + ('<a class="ynabtk-month-link">' + ynabToolKit.shared.monthsFull[earliestNegativeMonth - 1] + '</a>') + '</strong>' + ')</span>');

      $('.ynabtk-month-link', name).click(function (event) {
        event.preventDefault();
        var applicationController = (0, _ember.controllerLookup)('application');
        var budgetVersionId = applicationController.get('budgetVersionId');
        (0, _ynab.transitionTo)('budget.select', budgetVersionId, earliestEntityDate.replace('-', ''));
      });
    }
  }, {
    key: 'isMonthEntityIdFuture',
    value: function isMonthEntityIdFuture(entityId) {
      var currentYear = parseInt(moment().format('YYYY'));
      var currentMonth = parseInt(moment().format('MM'));
      var entityDate = entityId.match(/mbc\/(.*)\/.*/)[1];

      var _entityDate$split$map = entityDate.split('-').map(function (val) {
        return parseInt(val);
      }),
          _entityDate$split$map2 = _slicedToArray(_entityDate$split$map, 2),
          entityYear = _entityDate$split$map2[0],
          entityMonth = _entityDate$split$map2[1];

      var isNextYear = entityYear > currentYear;
      var isCurrentYearFutureMonth = entityYear === currentYear && entityMonth > currentMonth;
      if (isNextYear || isCurrentYearFutureMonth) {
        return true;
      }

      return false;
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      var _this3 = this;

      var budgetController = ynabToolKit.shared.containerLookup('controller:budget');
      var budgetViewModel = budgetController.get('budgetViewModel');
      if (budgetViewModel) {
        budgetViewModel.get('allBudgetMonthsViewModel.monthlyBudgetCalculationsCollection').forEach(function (month) {
          month.addObserver('availableToBudget', _this3.onAvailableToBudgetChange.bind(_this3, budgetViewModel));
        });

        this.onAvailableToBudgetChange(budgetViewModel);
      }
    }
  }, {
    key: 'onRouteChanged',
    value: function onRouteChanged() {
      if (!this.shouldInvoke()) return;
      this.invoke();
    }
  }]);

  return StealingFromFuture;
}(_feature.Feature);

/***/ }),
/* 479 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(480);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 480 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".ynabtk-stealing-from-next-month {\n\tcolor: red;\n}\n\n.ynabtk-month-link {\n\tcursor: pointer;\n\ttext-decoration: underline;\n}\n", ""]);

// exports


/***/ }),
/* 481 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.TargetBalanceWarning = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

var _ember = __webpack_require__(13);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var TargetBalanceWarning = exports.TargetBalanceWarning = function (_Feature) {
  _inherits(TargetBalanceWarning, _Feature);

  function TargetBalanceWarning() {
    _classCallCheck(this, TargetBalanceWarning);

    return _possibleConstructorReturn(this, (TargetBalanceWarning.__proto__ || Object.getPrototypeOf(TargetBalanceWarning)).call(this));
  }

  _createClass(TargetBalanceWarning, [{
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('budget') !== -1;
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      $('.budget-table-row.is-sub-category').each(function (index, element) {
        var emberId = element.id;
        var viewData = (0, _ember.getEmberView)(emberId).data;
        var subCategory = viewData.subCategory;


        if (subCategory.get('goalType') === ynab.constants.SubCategoryGoalType.TargetBalance) {
          var available = viewData.get('available');
          var targetBalance = subCategory.get('targetBalance');
          var currencyElement = $('.budget-table-cell-available .user-data.currency', element);

          if (available < targetBalance && !currencyElement.hasClass('cautious')) {
            if (currencyElement.hasClass('positive')) {
              currencyElement.removeClass('positive');
            }

            currencyElement.addClass('cautious');
          }
        }
      });
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (!this.shouldInvoke()) return;

      if (changedNodes.has('budget-table-cell-available-div user-data')) {
        this.invoke();
      }
    }
  }, {
    key: 'onRouteChanged',
    value: function onRouteChanged() {
      if (!this.shouldInvoke()) return;
      this.invoke();
    }
  }]);

  return TargetBalanceWarning;
}(_feature.Feature);

/***/ }),
/* 482 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ToBeBudgetedWarning = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var ToBeBudgetedWarning = exports.ToBeBudgetedWarning = function (_Feature) {
  _inherits(ToBeBudgetedWarning, _Feature);

  function ToBeBudgetedWarning() {
    _classCallCheck(this, ToBeBudgetedWarning);

    return _possibleConstructorReturn(this, (ToBeBudgetedWarning.__proto__ || Object.getPrototypeOf(ToBeBudgetedWarning)).apply(this, arguments));
  }

  _createClass(ToBeBudgetedWarning, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(483);
    }
  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('budget') !== -1;
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      // check if TBB > zero, if so, change background color
      if ($('.budget-header-totals-amount-value .currency').hasClass('positive')) {
        $('.budget-header-totals-amount').addClass('toolkit-cautious');
        $('.budget-header-totals-amount-arrow').addClass('toolkit-cautious');
      } else {
        $('.budget-header-totals-amount').removeClass('toolkit-cautious');
        $('.budget-header-totals-amount-arrow').removeClass('toolkit-cautious');
      }
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (!this.shouldInvoke()) return;

      if (changedNodes.has('budget-header-item budget-header-calendar') || changedNodes.has('budget-header-totals-cell-value user-data')) {
        this.invoke();
      }
    }
  }, {
    key: 'onRouteChanged',
    value: function onRouteChanged() {
      if (!this.shouldInvoke()) return;
      this.invoke();
    }
  }]);

  return ToBeBudgetedWarning;
}(_feature.Feature);

/***/ }),
/* 483 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(484);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 484 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, "body .budget-header-totals-amount.toolkit-cautious {\n\tbackground-color: #e59100;\n}\nbody .budget-header-totals-amount-arrow.toolkit-cautious .arrow {\n\tborder-left: 1em solid #e59100;\n}", ""]);

// exports


/***/ }),
/* 485 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ToggleMasterCategories = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var ToggleMasterCategories = exports.ToggleMasterCategories = function (_Feature) {
  _inherits(ToggleMasterCategories, _Feature);

  function ToggleMasterCategories() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, ToggleMasterCategories);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = ToggleMasterCategories.__proto__ || Object.getPrototypeOf(ToggleMasterCategories)).call.apply(_ref, [this].concat(args))), _this), _this.toggleMasterCategories = function (event) {
      var container = $('.undo-redo-container');
      var min = container.offset().left + container.outerWidth() - 2;
      var max = min + 28;

      if (event.pageX >= min && event.pageX <= max) {
        // if some sections are already hidden, expand all
        if ($('.is-master-category .budget-table-cell-name-static-width button.right').length) {
          $('.is-master-category .budget-table-cell-name-static-width button.right').click();
        } else {
          $('.is-master-category .budget-table-cell-name-static-width button.down').click();
        }
      }
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(ToggleMasterCategories, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(486);
    }
  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      // since we are adding the listener to the entire document,
      // we should invoke on page load.
      return true;
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      $(document).on('click.toolkit-toggle-master-cats', '.undo-redo-container', this.toggleMasterCategories);
    }
  }]);

  return ToggleMasterCategories;
}(_feature.Feature);

/***/ }),
/* 486 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(487);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 487 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".budget-toolbar > .undo-redo-container::after {\n  content: '\\E592';\n  font-family: 'Flaticons Stroke';\n  -webkit-font-smoothing: antialiased;\n  font-size: 1.125em;\n  color: #009cc2;\n  padding: .4em .5em;\n  position: absolute;\n  cursor: pointer;\n}\n", ""]);

// exports


/***/ }),
/* 488 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.AccountsDisplayDensity = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var AccountsDisplayDensity = exports.AccountsDisplayDensity = function (_Feature) {
  _inherits(AccountsDisplayDensity, _Feature);

  function AccountsDisplayDensity() {
    _classCallCheck(this, AccountsDisplayDensity);

    return _possibleConstructorReturn(this, (AccountsDisplayDensity.__proto__ || Object.getPrototypeOf(AccountsDisplayDensity)).apply(this, arguments));
  }

  _createClass(AccountsDisplayDensity, [{
    key: 'injectCSS',
    value: function injectCSS() {
      if (this.settings.enabled === '1') {
        return __webpack_require__(489);
      } else if (this.settings.enabled === '2') {
        return __webpack_require__(491);
      }
    }
  }]);

  return AccountsDisplayDensity;
}(_feature.Feature);

/***/ }),
/* 489 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(490);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 490 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".nav-accounts .nav-account-row {\n     line-height: normal;\n     padding: 0.025em 0;\n}\n\n.nav-accounts .nav-account-row .nav-account-value {\n\tposition: relative;\n\ttop: -2px;\n}\n\n.nav-accounts .nav-account-row .negative {\n\tposition: relative;\n\ttop: 2px;\n}", ""]);

// exports


/***/ }),
/* 491 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(492);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 492 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".nav-accounts .nav-account-row {\n     line-height: normal;\n     padding: 0.01em 0;\n     font-size: .85em;\n}\n\n.nav-accounts .nav-account-row .nav-account-name {\n\tposition: relative;\n\ttop: 2px;\n}\n\n.nav-accounts .nav-account-row .negative {\n\tposition: relative;\n\ttop: 1px;\n}\n", ""]);

// exports


/***/ }),
/* 493 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.BetterScrollbars = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var BetterScrollbars = exports.BetterScrollbars = function (_Feature) {
  _inherits(BetterScrollbars, _Feature);

  function BetterScrollbars() {
    _classCallCheck(this, BetterScrollbars);

    return _possibleConstructorReturn(this, (BetterScrollbars.__proto__ || Object.getPrototypeOf(BetterScrollbars)).apply(this, arguments));
  }

  _createClass(BetterScrollbars, [{
    key: 'injectCSS',
    value: function injectCSS() {
      if (this.settings.enabled === '1') {
        return __webpack_require__(494);
      } else if (this.settings.enabled === '2') {
        return __webpack_require__(496);
      } else if (this.settings.enabled === '3') {
        return __webpack_require__(498);
      }
    }
  }]);

  return BetterScrollbars;
}(_feature.Feature);

/***/ }),
/* 494 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(495);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 495 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, "::-webkit-scrollbar {\n   width: 6px;\n}\n\n::-webkit-scrollbar-thumb {\n   border-radius: 3px;\n   background: rgba(0,89,111,0.6);\n}\n", ""]);

// exports


/***/ }),
/* 496 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(497);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 497 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, "::-webkit-scrollbar {\n   width: 2px;\n}\n\n::-webkit-scrollbar-thumb {\n   border-radius: 1px;\n   background: rgba(0,89,111,0.6);\n}\n", ""]);

// exports


/***/ }),
/* 498 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(499);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 499 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, "::-webkit-scrollbar {\n   width: 0px;\n}\n", ""]);

// exports


/***/ }),
/* 500 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.BudgetQuickSwitch = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ember = __webpack_require__(13);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var BudgetQuickSwitch = exports.BudgetQuickSwitch = function (_Feature) {
  _inherits(BudgetQuickSwitch, _Feature);

  function BudgetQuickSwitch() {
    _classCallCheck(this, BudgetQuickSwitch);

    return _possibleConstructorReturn(this, (BudgetQuickSwitch.__proto__ || Object.getPrototypeOf(BudgetQuickSwitch)).apply(this, arguments));
  }

  _createClass(BudgetQuickSwitch, [{
    key: 'populateBudgetList',
    value: function populateBudgetList() {
      var applicationController = (0, _ember.controllerLookup)('application');
      var currentBudgetId = applicationController.get('activeBudgetVersion').get('entityId');
      var $openBudgetListItem = $('.modal-select-budget').find('.modal-select-budget-open').parent();

      ynab.YNABSharedLib.getCatalogViewModel_UserViewModel().then(function (_ref) {
        var userBudgetDisplayItems = _ref.userBudgetDisplayItems;

        userBudgetDisplayItems.filter(function (budget) {
          return !budget.get('isTombstone');
        }).forEach(function (budget) {
          var budgetVersionId = budget.get('budgetVersionId');
          var budgetVersionName = budget.get('budgetVersionName');

          if (budgetVersionId === currentBudgetId) return;

          var budgetListItem = $('<li>').append($('<button>', { text: budgetVersionName }).prepend($('<i>', {
            class: 'flaticon stroke mail-1'
          }))).click(function () {
            var router = (0, _ember.getRouter)();
            router.send('openBudget', budgetVersionId, budgetVersionName);
          });

          $openBudgetListItem.after(budgetListItem);
        });
      });
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (changedNodes.has('ynab-u modal-popup modal-select-budget ember-view modal-overlay active')) {
        this.populateBudgetList();
      }
    }
  }]);

  return BudgetQuickSwitch;
}(_feature.Feature);

/***/ }),
/* 501 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CollapseSideMenu = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _toolkit = __webpack_require__(48);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var CollapseSideMenu = exports.CollapseSideMenu = function (_Feature) {
  _inherits(CollapseSideMenu, _Feature);

  function CollapseSideMenu() {
    var _ref;

    var _temp, _this2, _ret;

    _classCallCheck(this, CollapseSideMenu);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this2 = _possibleConstructorReturn(this, (_ref = CollapseSideMenu.__proto__ || Object.getPrototypeOf(CollapseSideMenu)).call.apply(_ref, [this].concat(args))), _this2), _this2.collapseBtn = '', _this2.originalButtons = {}, _this2.originalSizes = {
      sidebarWidth: 0,
      contentLeft: 0,
      headerLeft: 0,
      contentWidth: 0,
      inspectorWidth: 0
    }, _temp), _possibleConstructorReturn(_this2, _ret);
  }

  _createClass(CollapseSideMenu, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(502);
    }
  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return true;
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      this.collapseBtn = $('<li>', { class: 'ember-view ynabtk-navlink-collapse' }).append($('<a>', { class: 'ynabtk-collapse-link' }).append($('<span>', { class: 'ember-view flaticon stroke left-circle-4' })).append((0, _toolkit.i10n)('toolkit.collapse', 'Collapse')));

      this.setupBtns();
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (changedNodes.has('layout user-logged-in')) {
        if ($('.nav-main').length) {
          this.setupBtns();
        }
      }

      if (changedNodes.has('nav-main')) {
        var numNavLinks = $('.nav-main').children().length;
        var collapseIndex = $('.nav-main').children().index($('.ynabtk-navlink-collapse'));
        var numCollapsedLinks = $('.collapsed-buttons').children().length;

        if (numNavLinks > collapseIndex + 1 || numNavLinks > numCollapsedLinks) {
          $('.ynabtk-navlink-collapse').remove();

          this.setUpCollapseBtn();
          this.setUpCollapsedButtons();
        }
      }
    }
  }, {
    key: 'setOriginalSizes',
    value: function setOriginalSizes() {
      this.originalSizes = {
        sidebarWidth: $('.sidebar').width(),
        contentLeft: $('.content').css('left'),
        headerLeft: $('.budget-header, .accounts-header').css('left'),
        contentWidth: $('.budget-content').outerWidth(),
        inspectorWidth: $('.budget-inspector').outerWidth()
      };
    }

    // Add buttons and handlers to screen

  }, {
    key: 'setupBtns',
    value: function setupBtns() {
      // Don't proceed if buttons already exist
      if ($('.ynabtk-navlink-collapse').is(':visible') || $('.navbar-expand').is(':visible')) {
        return;
      }

      this.setUpCollapseBtn();
      this.setUpCollapsedButtons();
    }
  }, {
    key: 'setUpCollapseBtn',
    value: function setUpCollapseBtn() {
      var _this = this;
      $('.nav-main').append(this.collapseBtn);
      $('body').on('click', '.ynabtk-navlink-collapse', _this, this.collapseMenu);
    }
  }, {
    key: 'setUpCollapsedButtons',
    value: function setUpCollapsedButtons() {
      var expandBtns = this.getUnCollapseBtnGroup();

      $('.sidebar').prepend(expandBtns);

      if ($('.sidebar-contents').is(':visible')) {
        $('.collapsed-buttons').hide();
      }
    }
  }, {
    key: 'getUnCollapseBtnGroup',
    value: function getUnCollapseBtnGroup() {
      var navChildren = $('.nav-main').children();
      var navChildrenLength = navChildren.length;
      var collapsedBtnContainer = $('.collapsed-buttons');

      if (collapsedBtnContainer.length) {
        collapsedBtnContainer.children().remove();
        collapsedBtnContainer.hide();
      } else {
        collapsedBtnContainer = $('<div>', { class: 'collapsed-buttons', style: 'display: none' });
      }

      var clickFunction = function clickFunction(event) {
        var _this = event.data; // the feature
        var linkClass = this.className.replace(' active', '').trim();

        $(_this.originalButtons[linkClass]).click();
        _this.deactivateCollapsedActive();
        $(this).addClass('active');
      };

      for (var i = 0; i < navChildrenLength; i++) {
        var child = navChildren[i];
        var span = $(child).find('span')[0];

        // If this is the collapse button, skip
        if (span && !child.className.includes('ynabtk-navlink-collapse')) {
          var btnClasses = span.className;
          var button = $('<button>');
          button.addClass(btnClasses);
          button.addClass('button button-prefs');

          var listItem = $(child).find('li')[0] || child;
          var linkClass = listItem.className.replace(' active', '').trim();

          var link = $('<a>');
          link.attr('href', '#');
          link.addClass(linkClass);
          link.html(button);
          link.click(this, clickFunction);

          this.originalButtons[linkClass] = 'ul.nav-main li.' + linkClass + ' a';

          // Set proper class so the active styling can be applied
          if (btnClasses.indexOf('mail-1') > -1) {
            button.addClass('collapsed-budget');
          } else if (btnClasses.indexOf('graph-1') > -1) {
            button.addClass('collapsed-reports');
          } else if (btnClasses.indexOf('government-1') > -1) {
            button.addClass('collapsed-account');
          } else {
            // Fallback if we don't know what the button is.
            button.addClass('collapsed');
          }

          collapsedBtnContainer.append(link);
        }
      }

      // Add uncollapse button
      var collapseBtn = $('<button>', { class: 'button button-prefs flaticon stroke right-circle-4 navbar-expand' });

      collapsedBtnContainer.append(collapseBtn);

      $('body').on('click', '.navbar-expand', this, this.expandMenu);

      return collapsedBtnContainer;
    }

    // Handle clicking expand button. Puts things back to original sizes

  }, {
    key: 'expandMenu',
    value: function expandMenu(event) {
      var originalSizes = event.data.originalSizes;

      $('.collapsed-buttons').hide();
      $('.sidebar > .ember-view').fadeIn();
      $('.ynabtk-navlink-collapse').show();

      $('.sidebar').animate({ width: originalSizes.sidebarWidth });
      $('.content').animate({ left: originalSizes.contentLeft }, function () {
        $('.layout').removeClass('collapsed');
      });

      $('.budget-header').animate({ left: originalSizes.headerLeft });
      if ($('.budget-content').is(':visible')) {
        if (ynabToolKit.options.InspectorWidth !== '0') {
          $('.budget-inspector')[0].style.setProperty('--toolkit-inspector-minwidth', 'inherit');
        }
      }
    }

    // Handle clicking the collapse button

  }, {
    key: 'collapseMenu',
    value: function collapseMenu(event) {
      var _this = event.data;
      // resize-inspector feature could have changed these so fetch current sizes.
      _this.setOriginalSizes();
      _this.setActiveButton($('.nav-main li.active').attr('class'));
      $('.ynabtk-navlink-collapse').hide();
      $('.sidebar > .ember-view').hide();
      $('.collapsed-buttons').fadeIn();

      $('.sidebar').animate({ width: '40px' });
      $('.content').animate({ left: '40px' }, 400, 'swing', function () {
        // Need to remove width after animation completion
        $('.ynab-grid-header').removeAttr('style');

        // We don't use these in our CSS, it's mostly so other features can observe
        // for collapse/expand and update sizes / do whatever. E.g. reports needs
        // to resize its canvas when this happens.
        $('.ynabtk-navlink-collapse').removeClass('expanded').addClass('collapsed');
        $('.layout').addClass('collapsed');
      });

      $('.budget-header').animate({ left: '40px' });
      if ($('.budget-content').is(':visible')) {
        if (ynabToolKit.options.InspectorWidth !== '0') {
          $('.budget-inspector')[0].style.setProperty('--toolkit-inspector-minwidth', '276 px');
        }
      }
    }

    // Add the active style to correct button

  }, {
    key: 'setActiveButton',
    value: function setActiveButton(button) {
      if (typeof button !== 'undefined') {
        this.deactivateCollapsedActive();
        button = button.replace('active', '').replace('ember-view', '').trim();
        $('.collapsed-buttons a.' + button).addClass('active');
      } else {
        $('.collapsed-buttons a').removeClass('active');
      }
    }

    // Deactivate collapsed buttons

  }, {
    key: 'deactivateCollapsedActive',
    value: function deactivateCollapsedActive() {
      $('.collapsed-buttons a').removeClass('active');
    }
  }]);

  return CollapseSideMenu;
}(_feature.Feature);

/***/ }),
/* 502 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(503);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 503 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".ynabtk-navlink-collapse {\n  cursor: pointer;\n}\n\n.layout.collapsed .content,\n.layout.collapsed .budget-header {\n\tleft: 40px;\n}\n\n.layout.collapsed .content .scroll-wrap {\n\twidth: inherit;\n\tmin-width: 838px;\n}\n\n.collapsed-buttons .active button {\n\tbackground-color: #194853;\n\tcolor: #fff;\n}\n\n.collapsed-buttons .active .collapsed-budget {\n\tcolor: #ceec00;\n}\n\n.collapsed-buttons .active .collapsed-reports {\n\tcolor: #fed168;\n}\n\n.collapsed-buttons .active .collapsed-account {\n\tcolor: #32dcff;\n}\n", ""]);

// exports


/***/ }),
/* 504 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ColourBlindMode = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var ColourBlindMode = exports.ColourBlindMode = function (_Feature) {
  _inherits(ColourBlindMode, _Feature);

  function ColourBlindMode() {
    _classCallCheck(this, ColourBlindMode);

    return _possibleConstructorReturn(this, (ColourBlindMode.__proto__ || Object.getPrototypeOf(ColourBlindMode)).apply(this, arguments));
  }

  _createClass(ColourBlindMode, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(505);
    }
  }]);

  return ColourBlindMode;
}(_feature.Feature);

/***/ }),
/* 505 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(506);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 506 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, "/* ======== General colours / shapes ======== */\n.inspector dt {\n\tcolor: black !important;\n}\n\n/* ======== Cautious colours / shapes ======== */\n.budget-table-row.is-sub-category > .budget-table-cell-available .cautious {\n    background-color: #19a3c5 !important;\n}\n\n.inspector-overview-available .currency.cautious {\n    background-color: #19a3c5 !important;;\n}\n\n.budget-table-row.is-sub-category > .budget-table-cell-available .cautious:hover {\n    background-color: #14839e !important;\n}\n\n/* ======== Goal-related colours / shapes ======== */\n.toolkit-row-goal.toolkit-row-availablepositive .budget-table-cell-available .cautious, \n.toolkit-row-goal.toolkit-row-availablezero .budget-table-cell-available .cautious {\n\tbackground: #1282a0 !important;\n}\n.toolkit-row-goal.toolkit-row-availablepositive .budget-table-cell-available .cautious:hover, \n.toolkit-row-goal.toolkit-row-availablezero .budget-table-cell-available .cautious:hover {\n\tbackground: #0e6c85 !important;\n}\n\n.toolkit-row-goal.toolkit-row-availablepositive dd .cautious, \n.toolkit-row-goal.toolkit-row-availablezero dd .cautious {\n\tbackground: #1282a0 !important;\n}\n.toolkit-row-goal.toolkit-row-availablepositive dd .cautious:hover, \n.toolkit-row-goal.toolkit-row-availablezero dd .cautious:hover {\n\tbackground: #0e6c85 !important;\n}\n\n/* ======== Negative colours / shapes ======== */\nul.is-sub-category > li.budget-table-cell-available > div.budget-table-cell-available-div > span.negative {\n    border-radius: 0em !important;\n    -webkit-border-radius: 0em !important;\n    background-color: #d55e00 !important;\n}\n\n.inspector-overview-available .currency.negative {\n    border-radius: 0em !important;\n    -webkit-border-radius: 0em !important;\n    background-color: #d55e00 !important;\n}\n\n.left-to-budget-is-negative .budget-header-totals-amount {\n    border-radius: 0em;\n    -webkit-border-radius: 0em;\n    background-color: #d55e00 !important;\n}\n\n.left-to-budget-is-negative .budget-header-totals-amount-arrow .arrow {\n    border-left-color: #d55e00 !important;\n}\n\n/* ======== Positive colours / shapes ======== */\nul.is-sub-category > li.budget-table-cell-available > div.budget-table-cell-available > span.positive {\n    background-color: #009e73 !important;\n    color: #fff !important;\n    font-weight: normal !important;\n}\n\n.inspector-overview-available .currency.positive {\n    background-color: #009e73 !important;;\n    color: #fff !important;\n    font-weight: normal !important;\n}\n", ""]);

// exports


/***/ }),
/* 507 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EditAccountButton = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var EditAccountButton = exports.EditAccountButton = function (_Feature) {
  _inherits(EditAccountButton, _Feature);

  function EditAccountButton() {
    _classCallCheck(this, EditAccountButton);

    return _possibleConstructorReturn(this, (EditAccountButton.__proto__ || Object.getPrototypeOf(EditAccountButton)).apply(this, arguments));
  }

  _createClass(EditAccountButton, [{
    key: 'injectCSS',
    value: function injectCSS() {
      if (this.settings.enabled === '1' && !YNABFEATURES['edit-account-icon']) {
        return __webpack_require__(508);
      } else if (this.settings.enabled === '2') {
        return __webpack_require__(510);
      }
    }
  }]);

  return EditAccountButton;
}(_feature.Feature);

/***/ }),
/* 508 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(509);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 509 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".nav-account-row .nav-account-name i {\n  padding-top: 2px;\n  padding-right: 4px;\n  float:left;\n  transition: opacity .25s ease-in-out;\n}\n", ""]);

// exports


/***/ }),
/* 510 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(511);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 511 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".nav-account-row:hover .nav-account-name .edit-account-icon {\n\tdisplay: none;\n}\n\n.nav-account-row:hover .nav-account-notification .edit-account-icon {\n\tdisplay: none;\n}\n\n.nav-account-row .nav-account-name:hover button {\n\tmax-width: 100%;\n}\n", ""]);

// exports


/***/ }),
/* 512 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.GoogleFontsSelector = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var GoogleFontsSelector = exports.GoogleFontsSelector = function (_Feature) {
  _inherits(GoogleFontsSelector, _Feature);

  function GoogleFontsSelector() {
    _classCallCheck(this, GoogleFontsSelector);

    return _possibleConstructorReturn(this, (GoogleFontsSelector.__proto__ || Object.getPrototypeOf(GoogleFontsSelector)).apply(this, arguments));
  }

  _createClass(GoogleFontsSelector, [{
    key: 'injectCSS',
    value: function injectCSS() {
      if (this.settings.enabled === '1') {
        return __webpack_require__(513);
      } else if (this.settings.enabled === '2') {
        return __webpack_require__(515);
      } else if (this.settings.enabled === '3') {
        return __webpack_require__(517);
      } else if (this.settings.enabled === '4') {
        return __webpack_require__(519);
      }
    }
  }]);

  return GoogleFontsSelector;
}(_feature.Feature);

/***/ }),
/* 513 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(514);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 514 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports
exports.push([module.i, "@import url(https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,700);", ""]);
exports.i(__webpack_require__(71), "");

// module
exports.push([module.i, ".ember-view {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.nav-account-block .nav-account-name-button {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.budget-header-calendar .budget-header-calendar-date-button {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.budget-inspector-button {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.budget-inspector-goals .link-button {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.inspector-category-edit {\n    font-family: 'Open Sans', sans-serif;\n    top: 3px;\n    font-size: 1em;\n}\n\n.nav-account-block .nav-account-name-button {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.budget-content ul, .budget-table-row.is-dragging {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.modal-popup .modal-actions .button {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.modal-generic .modal-actions .button {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.modal-generic .modal-header {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.modal-popup .modal-content {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.modal-account-filters .modal-header {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.modal-account-filters .date-range-dates li.active button, .modal-account-filters .date-range-dates li:hover button {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.modal-popup ul.modal-list button {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.modal-account-approve-reject.modal-account-dropdown .modal, .modal-account-match-transaction.modal-account-dropdown .modal {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.edit-direct-connect-toggle {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.account-modal .modal-content dt, .account-modal .modal-content dd {\n    font-family: 'Open Sans', sans-serif;\n}\n\n/* if reports stuff is enabled */\n.reports-inspector-detail {\n    font-family: 'Open Sans', sans-serif;\n}\n\n#reports-header {\n    font-family: 'Open Sans', sans-serif !important;\n}\n", ""]);

// exports


/***/ }),
/* 515 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(516);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 516 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports
exports.push([module.i, "@import url(https://fonts.googleapis.com/css?family=Roboto:400,700,400italic);", ""]);
exports.i(__webpack_require__(71), "");

// module
exports.push([module.i, ".ember-view {\n    font-family: 'Roboto', sans-serif;\n}\n\n.nav-account-block .nav-account-name-button {\n    font-family: 'Roboto', sans-serif;\n}\n\n.budget-header-calendar .budget-header-calendar-date-button {\n    font-family: 'Roboto', sans-serif;\n}\n\n.budget-inspector-button {\n    font-family: 'Roboto', sans-serif;\n}\n\n.budget-inspector-goals .link-button {\n    font-family: 'Roboto', sans-serif;\n}\n\n.inspector-category-edit {\n    font-family: 'Roboto', sans-serif;\n    top: 3px;\n    font-size: 1em;\n}\n\n.nav-account-block .nav-account-name-button {\n    font-family: 'Roboto', sans-serif;\n}\n\n.budget-content ul, .budget-table-row.is-dragging {\n    font-family: 'Roboto', sans-serif;\n}\n\n.modal-popup .modal-actions .button {\n    font-family: 'Roboto', sans-serif;\n}\n\n.modal-generic .modal-actions .button {\n    font-family: 'Roboto', sans-serif;\n}\n\n.modal-generic .modal-header {\n    font-family: 'Roboto', sans-serif;\n}\n\n.modal-popup .modal-content {\n    font-family: 'Roboto', sans-serif;\n}\n\n.modal-account-filters .modal-header {\n    font-family: 'Roboto', sans-serif;\n}\n\n.modal-account-filters .date-range-dates li.active button, .modal-account-filters .date-range-dates li:hover button {\n    font-family: 'Roboto', sans-serif;\n}\n\n.modal-popup ul.modal-list button {\n    font-family: 'Roboto', sans-serif;\n}\n\n.modal-account-approve-reject.modal-account-dropdown .modal, .modal-account-match-transaction.modal-account-dropdown .modal {\n    font-family: 'Roboto', sans-serif;\n}\n\n.edit-direct-connect-toggle {\n    font-family: 'Roboto', sans-serif;\n}\n\n.account-modal .modal-content dt, .account-modal .modal-content dd {\n    font-family: 'Roboto', sans-serif;\n}\n\n/* if reports stuff is enabled */\n.reports-inspector-detail {\n    font-family: 'Roboto', sans-serif;\n}\n\n#reports-header {\n    font-family: 'Roboto', sans-serif !important;\n}\n", ""]);

// exports


/***/ }),
/* 517 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(518);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 518 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports
exports.push([module.i, "@import url(https://fonts.googleapis.com/css?family=Roboto Condensed+Condensed:400,700,400italic);", ""]);
exports.i(__webpack_require__(71), "");

// module
exports.push([module.i, ".ember-view {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.nav-account-block .nav-account-name-button {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.budget-header-calendar .budget-header-calendar-date-button {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.budget-inspector-button {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.budget-inspector-goals .link-button {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.inspector-category-edit {\n    font-family: 'Roboto Condensed', sans-serif;\n    top: 3px;\n    font-size: 1em;\n}\n\n.nav-account-block .nav-account-name-button {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.budget-content ul, .budget-table-row.is-dragging {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.modal-popup .modal-actions .button {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.modal-generic .modal-actions .button {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.modal-generic .modal-header {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.modal-popup .modal-content {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.modal-account-filters .modal-header {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.modal-account-filters .date-range-dates li.active button, .modal-account-filters .date-range-dates li:hover button {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.modal-popup ul.modal-list button {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.modal-account-approve-reject.modal-account-dropdown .modal, .modal-account-match-transaction.modal-account-dropdown .modal {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.edit-direct-connect-toggle {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.account-modal .modal-content dt, .account-modal .modal-content dd {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n/* if reports stuff is enabled */\n.reports-inspector-detail {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n#reports-header {\n    font-family: 'Roboto Condensed', sans-serif !important;\n}\n", ""]);

// exports


/***/ }),
/* 519 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(520);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 520 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports
exports.push([module.i, "@import url(https://fonts.googleapis.com/css?family=Droid+Sans:400,700);", ""]);
exports.i(__webpack_require__(71), "");

// module
exports.push([module.i, ".ember-view {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.nav-account-block .nav-account-name-button {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.budget-header-calendar .budget-header-calendar-date-button {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.budget-inspector-button {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.budget-inspector-goals .link-button {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.inspector-category-edit {\n    font-family: 'Droid Sans', sans-serif;\n    top: 3px;\n    font-size: 1em;\n}\n\n.nav-account-block .nav-account-name-button {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.budget-content ul, .budget-table-row.is-dragging {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.modal-popup .modal-actions .button {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.modal-generic .modal-actions .button {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.modal-generic .modal-header {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.modal-popup .modal-content {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.modal-account-filters .modal-header {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.modal-account-filters .date-range-dates li.active button, .modal-account-filters .date-range-dates li:hover button {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.modal-popup ul.modal-list button {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.modal-account-approve-reject.modal-account-dropdown .modal, .modal-account-match-transaction.modal-account-dropdown .modal {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.edit-direct-connect-toggle {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.account-modal .modal-content dt, .account-modal .modal-content dd {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n/* if reports stuff is enabled */\n.reports-inspector-detail {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n#reports-header {\n    font-family: 'Droid Sans', sans-serif !important;\n}\n", ""]);

// exports


/***/ }),
/* 521 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.HideAccountBalancesType = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var HideAccountBalancesType = exports.HideAccountBalancesType = function (_Feature) {
  _inherits(HideAccountBalancesType, _Feature);

  function HideAccountBalancesType() {
    _classCallCheck(this, HideAccountBalancesType);

    return _possibleConstructorReturn(this, (HideAccountBalancesType.__proto__ || Object.getPrototypeOf(HideAccountBalancesType)).apply(this, arguments));
  }

  _createClass(HideAccountBalancesType, [{
    key: 'injectCSS',
    value: function injectCSS() {
      if (this.settings.enabled === '1') {
        return __webpack_require__(137) + __webpack_require__(138);
      } else if (this.settings.enabled === '2') {
        return __webpack_require__(138);
      } else if (this.settings.enabled === '3') {
        return __webpack_require__(137);
      }
    }
  }]);

  return HideAccountBalancesType;
}(_feature.Feature);

/***/ }),
/* 522 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".nav-account-row .nav-account-value {\n    visibility: hidden;\n    width: 0px;\n}\n\n.nav-account-row .nav-account-spacer {\n    width: 0px;\n}\n\n.nav-account-row .nav-account-name {\n    overflow: inherit;\n    width: 210px\n}", ""]);

// exports


/***/ }),
/* 523 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".nav-account-block .nav-account-value {\n    visibility: hidden;\n    width: 0px;\n}", ""]);

// exports


/***/ }),
/* 524 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.HideHelp = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _toolkit = __webpack_require__(48);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var HideHelp = exports.HideHelp = function (_Feature) {
  _inherits(HideHelp, _Feature);

  function HideHelp() {
    _classCallCheck(this, HideHelp);

    return _possibleConstructorReturn(this, (HideHelp.__proto__ || Object.getPrototypeOf(HideHelp)).apply(this, arguments));
  }

  _createClass(HideHelp, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(525);
    }
  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return true;
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (changedNodes.has('ynab-u modal-popup modal-user-prefs ember-view modal-overlay active')) {
        this.invoke();
      }
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      var hide = (0, _toolkit.getToolkitStorageKey)('hide-help');

      if (hide === null) {
        (0, _toolkit.setToolkitStorageKey)('hide-help', 'true');
        hide = 'true';
      }

      if (hide === 'true') {
        $('body').addClass('toolkit-hide-help');
      }

      this.updatePopupButton();
    }
  }, {
    key: 'updatePopupButton',
    value: function updatePopupButton() {
      var $modal = $('.modal-user-prefs .modal');
      var $modalList = $('.modal-user-prefs .modal-list');

      if ($('.ynab-toolkit-hide-help', $modalList).length) return;

      var $label = 'Show';
      if ($('#hs-beacon').is(':visible')) {
        $label = 'Hide';
      }

      $('<li class="ynab-toolkit-hide-help">\n      <button>\n        <i class="flaticon stroke help-2"></i>\n        ' + $label + ' Help Button\n      </button>\n     </li>\n    ').click(function () {
        var hide = !(0, _toolkit.getToolkitStorageKey)('hide-help', 'boolean');
        (0, _toolkit.setToolkitStorageKey)('hide-help', hide);
        $('body').toggleClass('toolkit-hide-help');
        var accountController = ynabToolKit.shared.containerLookup('controller:accounts');
        accountController.send('closeModal');
      }).appendTo($modalList);

      $modal.css({ height: '+=12px' });
    }
  }]);

  return HideHelp;
}(_feature.Feature);

/***/ }),
/* 525 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(526);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 526 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".toolkit-hide-help #hs-beacon {\n\tdisplay: none;\n}", ""]);

// exports


/***/ }),
/* 527 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.HideReferralBanner = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var HideReferralBanner = exports.HideReferralBanner = function (_Feature) {
  _inherits(HideReferralBanner, _Feature);

  function HideReferralBanner() {
    _classCallCheck(this, HideReferralBanner);

    return _possibleConstructorReturn(this, (HideReferralBanner.__proto__ || Object.getPrototypeOf(HideReferralBanner)).apply(this, arguments));
  }

  _createClass(HideReferralBanner, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(528);
    }
  }]);

  return HideReferralBanner;
}(_feature.Feature);

/***/ }),
/* 528 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(529);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 529 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, "div.referral-program {\n  display: none !important;\n}\n", ""]);

// exports


/***/ }),
/* 530 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ImportNotification = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var ImportNotification = exports.ImportNotification = function (_Feature) {
  _inherits(ImportNotification, _Feature);

  _createClass(ImportNotification, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(531);
    }
  }]);

  function ImportNotification() {
    _classCallCheck(this, ImportNotification);

    var _this = _possibleConstructorReturn(this, (ImportNotification.__proto__ || Object.getPrototypeOf(ImportNotification)).call(this));

    _this.isActive = false;
    _this.importClass = 'import-notification';
    _this.invoke = _this.invoke.bind(_this);
    return _this;
  }

  _createClass(ImportNotification, [{
    key: 'willInvoke',
    value: function willInvoke() {
      if (this.settings.enabled !== '0') {
        if (this.settings.enabled === '2') {
          this.importClass += '-red';
        }

        // Hook transaction imports so that we can run our stuff when things change. The idea is for our code to
        // run when new imports show up while the user isn't doing anything in the app. The down side is the
        // handler being called when the user does something like "approve a transaction". That's why this feature
        // has a blocking mechanism (the isActive flag).
        ynab.YNABSharedLib.defaultInstance.entityManager._transactionEntityPropertyChanged.addHandler(this.invoke);
      }
    }
  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return !this.isActive;
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      this.checkImportTransactions();
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (!this.shouldInvoke()) return;
      // To minimize checking for imported transactions, only do it if the changed nodes includes ynab-grid-body
      // if we're not already actively check.
      if (changedNodes.has('ynab-grid-body') && !this.shouldInvoke()) {
        this.invoke();
      }
    }
  }, {
    key: 'onRouteChanged',
    value: function onRouteChanged() {
      if (this.shouldInvoke()) {
        this.invoke();
      }
    }
  }, {
    key: 'checkImportTransactions',
    value: function checkImportTransactions() {
      var _this2 = this;

      this.isActive = true;

      $('.' + this.importClass).remove();
      $('.nav-account-row').each(function (index, row) {
        var account = ynabToolKit.shared.getEmberView($(row).attr('id')).get('data');

        // Check for both functions should be temporary until all users have been switched to new bank data
        // provider but of course we have no good way of knowing when that has occurred.
        if (typeof account.getDirectConnectEnabled === 'function' && account.getDirectConnectEnabled() || typeof account.getIsDirectImportActive === 'function' && account.getIsDirectImportActive()) {
          var t = new ynab.managers.DirectImportManager(ynab.YNABSharedLib.defaultInstance.entityManager, account);
          var transactions = t.getImportTransactionsForAccount(account);

          if (transactions.length >= 1) {
            $(row).find('.nav-account-notification').append('<a class="notification ' + _this2.importClass + '">' + transactions.length + '</a>');
          }
        }
      });
      this.isActive = false;
    }
  }]);

  return ImportNotification;
}(_feature.Feature);

/***/ }),
/* 531 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(532);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 532 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".import-notification {\n  background-color: #227e99;\n}\n\n.import-notification-red {\n  background-color: #FF0000;\n}\n", ""]);

// exports


/***/ }),
/* 533 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.NavDisplayDensity = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var NavDisplayDensity = exports.NavDisplayDensity = function (_Feature) {
  _inherits(NavDisplayDensity, _Feature);

  function NavDisplayDensity() {
    _classCallCheck(this, NavDisplayDensity);

    return _possibleConstructorReturn(this, (NavDisplayDensity.__proto__ || Object.getPrototypeOf(NavDisplayDensity)).apply(this, arguments));
  }

  _createClass(NavDisplayDensity, [{
    key: 'injectCSS',
    value: function injectCSS() {
      if (this.settings.enabled === '1') {
        return __webpack_require__(534);
      } else if (this.settings.enabled === '2') {
        return __webpack_require__(536);
      }
    }
  }]);

  return NavDisplayDensity;
}(_feature.Feature);

/***/ }),
/* 534 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(535);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 535 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".nav-main {\n     padding-bottom: .95em !important;\n}\n.nav-main a {\n     padding: 0 !important;\n     font-size: 1em !important;\n}", ""]);

// exports


/***/ }),
/* 536 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(537);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 537 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".nav-main {\n     padding-bottom: .5em !important;\n}\n.nav-main a {\n     padding: 0 !important;\n     font-size: .85em !important;\n}", ""]);

// exports


/***/ }),
/* 538 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PrintingImprovements = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var PrintingImprovements = exports.PrintingImprovements = function (_Feature) {
  _inherits(PrintingImprovements, _Feature);

  function PrintingImprovements() {
    _classCallCheck(this, PrintingImprovements);

    return _possibleConstructorReturn(this, (PrintingImprovements.__proto__ || Object.getPrototypeOf(PrintingImprovements)).apply(this, arguments));
  }

  _createClass(PrintingImprovements, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(539);
    }
  }]);

  return PrintingImprovements;
}(_feature.Feature);

/***/ }),
/* 539 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(540);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 540 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, "/* ======== Budget Printing Improvements ======== */\n@media print {\n\n\t/* hide unneeded areas */\n\tbody nav.sidebar,\n\tbody aside.budget-inspector,\n\tbody .inspector-resize-handle,\n\tbody .budget-table-row .budget-table-cell-budgeted .goal-indicator {\n\t\tdisplay: none;\n\t}\n\n\n\t/* hide header, yet ensure that month is still visible */\n\tbody .budget-header-item,\n\tbody .budget-header-days.days-of-buffering,\n\tbody .budget-header-item button,\n\tbody .budget-header-calendar .budget-header-calendar-note,\n\tbody .budget-header-calendar .budget-header-calendar-date-button i,\n\tbody .budget-toolbar {\n\t\tdisplay: none;\n\t}\n\tbody .budget-header-days.days-of-buffering {\n\t\tdisplay: none !important;\n\t}\n\tbody .budget-header,\n\tbody .accounts-header {\n\t\tleft: 0;\n\t\tposition: relative;\n\t}\n\tbody .budget-header .budget-header-item,\n\tbody .toolkit-highlight-current-month {\n\t\tbackground: transparent !important;\n\t\tpadding-left: .8em;\n\t}\n\tbody .budget-header-calendar,\n\tbody .budget-header-calendar .budget-header-calendar-date-button {\n\t\tdisplay: block;\n\t\tcolor: #000;\n\t\ttext-align: left;\n\t}\n\n\t/* primarily layout adjustments */\n\t@page { margin: 1cm; }\n\n\t* {\n\t\tflex: none !important;\n\t}\n\tbody .ynab-u {\n\t\tdisplay: block;\n\t}\n\tbody .resize-inspector {\n\t\tdisplay: block !important;\n\t}\n\thtml, body {\n\t\theight: auto;\n\t\toverflow-y: visible !important;\n\t\toverflow-x: hidden !important;\n\t\twidth: 100%;\n\t\tmin-height: 100%;\n\t}\n\tbody div.content,\n\tbody section.budget-content {\n\t\tposition: relative !important;\n\t\twidth: 100%;\n\t\tmin-height: 100%;\n\t\tmin-width: 0;\n\t\ttop: auto;\n\t\tright: auto;\n\t\tbottom: auto;\n\t\tleft: auto;\n\t\toverflow-x: hidden !important;\n\t\tfont-size: 1em;\n\t\tpadding-top: 0;\n\t\tflex: none;\n\t}\n\tbody ul.budget-table-header {\n\t\tposition: relative !important;\n\t\tborder-bottom: 0;\n\t\tmin-width: 0;\n\t\tfont-weight: bold;\n\t}\n\tbody div.budget-table {\n\t\tposition: relative !important;\n\t\ttop: 0;\n\t\tmin-width: 0;\n\t\theight: auto;\n\t\tmin-height: 100%;\n\t\tpadding-bottom: 50px;\n\t}\n\tbody .budget-table-row {\n\t\tpage-break-inside: avoid;\n\t}\n\n\tbody .budget-table-header .budget-table-cell-checkbox,\n\tbody .budget-table-row .budget-table-cell-checkbox,\n\tbody .budget-table-header .budget-table-cell-status,\n\tbody .budget-table-row .budget-table-cell-status {\n\t\tdisplay: none;\n\t}\n\n\tbody .budget-table-header .budget-table-cell-name,\n\tbody .budget-table-row .budget-table-cell-name\n\t{\n\t\twidth: 42% !important;\n\t}\n\t.budget-table-header .budget-table-cell-budgeted,\n\t.budget-table-row .budget-table-cell-budgeted,\n\t.budget-table-header .budget-table-cell-activity,\n\t.budget-table-row .budget-table-cell-activity,\n\t.budget-table-header .budget-table-cell-available,\n\t.budget-table-row .budget-table-cell-available,\n\t.budget-table-header .budget-table-cell-pacing {\n\t\twidth: 12% !important;\n\t\tfont-size: 8pt !important;\n\t}\n\n\tbody .budget-table-row.is-master-category {\n\t\tborder-top: 2px solid #ccc;\n\t\tbackground: transparent;\n\t\tmargin-top: 20px;\n\t\theight: 2.1em;\n\t}\n\tbody .budget-table-row.is-master-category .budget-table-cell-name .budget-table-cell-name-row-label-item {\n\t    padding-top: .3em;\n\t}\n\tbody .budget-table-row.is-master-category:first-child {\n\t\tmargin-top: 0;\n\t}\n\n\tbody .budget-table-row.is-sub-category {\n\t\theight: 1.8em;\n\t}\n\tbody .budget-table-header .budget-table-cell-budgeted,\n\tbody .budget-table-header .budget-table-cell-activity,\n\tbody .budget-table-header .budget-table-cell-available,\n\tbody .budget-table-header .budget-table-cell-pacing {\n\t\tpadding-right: 0 !important;\n\t}\n\n\n\t/* primarily font styling */\n\tbody .budget-table-row.is-master-category .budget-table-cell-name {\n\t\tfont-weight: bold;\n\t}\n\t.budget-table-cell-name-static-width {\n\t\twidth: 18px;\n\t}\n\tbody .budget-table-row.is-master-category .budget-table-cell-name button {\n\t\tfont-weight: bold;\n\t\tposition: relative;\n\t\ttop: 2px !important;\n\t}\n\tbody .button, body .button-red, body .button-disabled {\n\t\tfont-size: 9pt !important;\n\t}\n\tbody .budget-table-row.is-master-category .positive,\n\tbody .budget-table-row.is-master-category .negative,\n\tbody .budget-table-row.is-master-category .cautious,\n\tbody .budget-table-row.is-master-category .zero {\n\t\tfont-weight: bold;\n\t\tcolor: #000;\n\t\tpadding-right: 2px;\n\t\tfont-size: 9pt !important;\n\t}\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .positive,\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .negative,\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .cautious,\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .zero {\n\t\tbackground-color: transparent;\n\t\tpadding: 0 2px 0 0 !important;\n\t\tfont-size: 9pt !important;\n\t}\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .positive {\n\t\tcolor: #16a336;\n\t}\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .cautious {\n\t\tcolor: #e59100;\n\t}\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .negative {\n\t\tcolor: #d33c2d;\n\t}\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .zero {\n\t\tcolor: #000000;\n\t}\n\n}\n\n\n/* ======== Account Printing Improvements ======== */\n@media print {\n\n\t/* header layout adjustments */\n\t.accounts-toolbar,\n\t.accounts-header .accounts-header-total-inner .arrow,\n\t.accounts-header-reconcile {\n\t\tdisplay: none;\n\t}\n\t.accounts-header {\n\t\theight: auto;\n\t\tbackground: transparent;\n\t}\n\t.accounts-header .accounts-header-total-inner {\n\t\tpadding-left: 0;\n\t\tpadding-right: 60px;\n\t\tbackground: transparent;\n\t}\n\t.accounts-header .accounts-header-total-inner .accounts-header-total-inner-label,\n\t.accounts-header .accounts-header-balances-label {\n\t\tcolor: #000;\n\t\tline-height: 1.5em;\n\t    font-weight: 400;\n\t}\n\n\t/* transactions adjustments */\n\t.ynab-grid {\n\t\tposition: relative !important;\n\t\theight: auto !important;\n\t\tfont-size: 11pt !important;\n\t}\n\t.ynab-grid-container {\n\t\theight: auto !important;\n\t}\n\t.ynab-grid-header,\n\t.ynab-grid-cell-checkbox {\n\t\tdisplay: none;\n\t}\n\n\t.ynab-grid-body-row,\n\t.ynab-grid-body-row-top,\n\t.ynab-grid-body-row-bottom {\n\t\theight: 26px !important;\n\t\tpage-break-inside: avoid;\n\t}\n\t.ynab-grid-cell {\n\t    padding: .2em 0;\n\t}\n\t.ynab-grid-body-row.is-scheduled {\n\t\tdisplay: none;\n\t}\n\n}", ""]);

// exports


/***/ }),
/* 541 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PrivacyMode = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var PrivacyMode = exports.PrivacyMode = function (_Feature) {
  _inherits(PrivacyMode, _Feature);

  function PrivacyMode() {
    _classCallCheck(this, PrivacyMode);

    return _possibleConstructorReturn(this, (PrivacyMode.__proto__ || Object.getPrototypeOf(PrivacyMode)).apply(this, arguments));
  }

  _createClass(PrivacyMode, [{
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return true;
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      var toggle = ynabToolKit.shared.getToolkitStorageKey('privacy-mode', 'boolean');
      if (typeof toggle === 'undefined') {
        ynabToolKit.shared.setToolkitStorageKey('privacy-mode', false);
      }

      if (ynabToolKit.options.PrivacyMode === '2') {
        if (!$('#toolkit-togglePrivacy').length) {
          $('nav.sidebar.logged-in .sidebar-contents').after('<button id="toolkit-togglePrivacy"><i class="ember-view flaticon stroke lock-1"></i></button>');

          var parent = this;
          $('body').on('click', 'button#toolkit-togglePrivacy', function () {
            parent.togglePrivacyMode();
          });
        }
      } else if (ynabToolKit.options.PrivacyMode === '1') {
        ynabToolKit.shared.setToolkitStorageKey('privacy-mode', true);
      }

      this.updatePrivacyMode();
    }
  }, {
    key: 'injectCSS',
    value: function injectCSS() {
      var css = __webpack_require__(542);

      if (this.settings.enabled === '2') {
        css += __webpack_require__(544);
      }

      return css;
    }
  }, {
    key: 'togglePrivacyMode',
    value: function togglePrivacyMode() {
      $('button#toolkit-togglePrivacy').toggleClass('active');

      var toggle = ynabToolKit.shared.getToolkitStorageKey('privacy-mode', 'boolean');
      ynabToolKit.shared.setToolkitStorageKey('privacy-mode', !toggle);
      this.updatePrivacyMode();
    }
  }, {
    key: 'updatePrivacyMode',
    value: function updatePrivacyMode() {
      var toggle = ynabToolKit.shared.getToolkitStorageKey('privacy-mode', 'boolean');

      if (toggle) {
        $('body').addClass('toolkit-privacyMode');
        $('#toolkit-togglePrivacy i').removeClass('unlock-1').addClass('lock-1');
      } else {
        $('body').removeClass('toolkit-privacyMode');
        $('#toolkit-togglePrivacy i').removeClass('lock-1').addClass('unlock-1');
      }
    }
  }]);

  return PrivacyMode;
}(_feature.Feature);

/***/ }),
/* 542 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(543);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 543 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".toolkit-privacyMode .currency,\n.toolkit-privacyMode .button-prefs-user,\n\n.toolkit-privacyMode .reports-inspector .currency,\n\n.toolkit-privacyMode .ynabtk-category-entry-amount,\n.toolkit-privacyMode .ynabtk-payee-entry-amount,\n.toolkit-privacyMode .ynabtk-tbody .col-data,\n.toolkit-privacyMode .net-income .ynabtk-header-row .col-data,\n.toolkit-privacyMode .ynabtk-footer-row .col-data {\n  filter: url('data:image/svg+xml;charset=utf-8,<svg xmlns=\"http://www.w3.org/2000/svg\"><filter id=\"filter\"><feGaussianBlur stdDeviation=\"3\" /></filter></svg>#filter');\n  -webkit-filter: blur(10px);\n  filter: blur(10px);\n}\n\n.toolkit-privacyMode .button-prefs-user:hover,\n.toolkit-privacyMode *:hover > .currency,\n.toolkit-privacyMode *:hover > * > .currency,\n.toolkit-privacyMode .currency:hover,\n\n.toolkit-privacyMode .c3-tooltip-container .currency,\n\n.toolkit-privacyMode .ynabtk-category-entry:hover .ynabtk-category-entry-amount,\n.toolkit-privacyMode .ynabtk-payee-entry:hover .ynabtk-payee-entry-amount,\n.toolkit-privacyMode .ynabtk-tbody .col-data:hover,\n.toolkit-privacyMode .net-income .ynabtk-header-row .col-data:hover,\n.toolkit-privacyMode .ynabtk-footer-row .col-data:hover {\n  -webkit-filter: initial;\n  filter: initial;\n}\n\n/* YNAB Reports: Spending */\n.toolkit-privacyMode .c3-chart-arcs .c3-chart-arcs-title tspan:last-child,\n.toolkit-privacyMode .c3-axis-y text tspan {\n    fill: #ffffff !important;\n    color: #ffffff !important;\n}\n.toolkit-privacyMode .c3-chart-arcs .c3-chart-arcs-title:hover tspan:last-child,\n.toolkit-privacyMode .c3-axis-y:hover text tspan {\n    color: #0d233a !important;\n    fill: #0d233a !important;\n}\n\n/* Toolkit Reports: Net Worth */\n.toolkit-privacyMode .highcharts-yaxis-labels text tspan {\n    fill: #ffffff !important;\n    color: #ffffff !important;\n}\n.toolkit-privacyMode .highcharts-yaxis-labels:hover text tspan {\n    fill: #606060 !important;\n    color: #606060 !important;\n}\n\n/* Toolkit Reports: Spending by category, payee */\n.toolkit-privacyMode .highcharts-title tspan:last-child,\n.toolkit-privacyMode .highcharts-data-labels text tspan:last-child {\n    fill: #ffffff !important;\n    color: #ffffff !important;\n}\n\n.toolkit-privacyMode .highcharts-title:hover tspan:last-child,\n.toolkit-privacyMode .highcharts-data-labels text:hover tspan:last-child {\n    color: #0d233a !important;\n    fill: #0d233a !important;\n}", ""]);

// exports


/***/ }),
/* 544 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(545);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 545 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".collapsed-buttons {\n\tmargin-top: 42px;\n}\n\n#toolkit-togglePrivacy {\n    color: #bee6ef;\n    top: 2px;\n    right: 2px;\n    position: absolute;\n    padding: 10px;\n}\n\n#toolkit-togglePrivacy.active {\n\tcolor: #fff;\n}", ""]);

// exports


/***/ }),
/* 546 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ShowIntercom = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ember = __webpack_require__(13);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var ShowIntercom = exports.ShowIntercom = function (_Feature) {
  _inherits(ShowIntercom, _Feature);

  function ShowIntercom() {
    _classCallCheck(this, ShowIntercom);

    return _possibleConstructorReturn(this, (ShowIntercom.__proto__ || Object.getPrototypeOf(ShowIntercom)).apply(this, arguments));
  }

  _createClass(ShowIntercom, [{
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      // should only invoke when the user settings modal is open which isn't
      // going to be the case when this lifecycle method is called.
      return false;
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      var $modal = $('.modal-user-prefs .modal');
      var $modalList = $('.modal-user-prefs .modal-list');

      if ($('.ynab-toolkit-show-intercom', $modalList).length) return;

      $('<li class="ynab-toolkit-show-intercom">\n        <button>\n          <i class="flaticon stroke warning-2"></i>\n          Show Intercom\n        </button>\n      </li>\n    ').click(function () {
        var accountController = (0, _ember.controllerLookup)('accounts');
        window.Intercom('show'); // eslint-disable-line new-cap
        accountController.send('closeModal');
      }).appendTo($modalList);

      $modal.css({ height: '+=12px' });
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (changedNodes.has('ynab-u modal-popup modal-user-prefs ember-view modal-overlay active')) {
        this.invoke();
      }
    }
  }]);

  return ShowIntercom;
}(_feature.Feature);

/***/ }),
/* 547 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SquareNegativeMode = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var SquareNegativeMode = exports.SquareNegativeMode = function (_Feature) {
  _inherits(SquareNegativeMode, _Feature);

  function SquareNegativeMode() {
    _classCallCheck(this, SquareNegativeMode);

    return _possibleConstructorReturn(this, (SquareNegativeMode.__proto__ || Object.getPrototypeOf(SquareNegativeMode)).apply(this, arguments));
  }

  _createClass(SquareNegativeMode, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(548);
    }
  }]);

  return SquareNegativeMode;
}(_feature.Feature);

/***/ }),
/* 548 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(549);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 549 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, "/* Sidebar Numbers */\n.nav-accounts .negative {\n    border-radius: 0em !important;\n    -webkit-border-radius: 0em !important;\n}\n\n/* Accounts Header */\n.accounts-header .accounts-header-total-inner.negative-working-balance {\n    border-radius: 0em !important;\n    -webkit-border-radius: 0em !important;\n}\n\n/* Bugdet Header */\n.left-to-budget-is-negative .budget-header-totals-amount {\n    border-radius: 0em !important;\n    -webkit-border-radius: 0em !important;\n}\n\n/* Budget Numbers, pacing */\nli.budget-table-cell-available > div.budget-table-cell-available-div > span.negative,\nli.toolkit-row-availablenegative > budget-table-cell-available-div > span.cautious,\nli.budget-table-cell-pacing span.negative,\nli.budget-table-cell-pacing span.cautious {\n    border-radius: 0em !important;\n    -webkit-border-radius: 0em !important;\n}\n\n/* Budget Inspector */\n.inspector-overview-available .currency.negative,\n.toolkit-row-availablenegative .currency.cautious {\n    border-radius: 0em !important;\n    -webkit-border-radius: 0em !important;\n}\n\n", ""]);

// exports


/***/ }),
/* 550 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CompactIncomeVsExpense = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _feature = __webpack_require__(2);

var _ynab = __webpack_require__(6);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var CompactIncomeVsExpense = exports.CompactIncomeVsExpense = function (_Feature) {
  _inherits(CompactIncomeVsExpense, _Feature);

  function CompactIncomeVsExpense() {
    _classCallCheck(this, CompactIncomeVsExpense);

    return _possibleConstructorReturn(this, (CompactIncomeVsExpense.__proto__ || Object.getPrototypeOf(CompactIncomeVsExpense)).apply(this, arguments));
  }

  _createClass(CompactIncomeVsExpense, [{
    key: 'injectCSS',
    value: function injectCSS() {
      return __webpack_require__(551);
    }
  }, {
    key: 'shouldInvoke',
    value: function shouldInvoke() {
      return (0, _ynab.getCurrentRouteName)().indexOf('reports.income-expense') > -1;
    }
  }, {
    key: 'invoke',
    value: function invoke() {
      var viewWidth = $('.reports-content').width();
      var columnCount = $('.income-expense-column.income-expense-column-header').length;
      var tableWidth = columnCount * 115 + 200 + 32;
      var percentage = Math.ceil(tableWidth / viewWidth * 100);

      $('.income-expense-table').css({ width: percentage + '%' });
    }
  }, {
    key: 'observe',
    value: function observe(changedNodes) {
      if (!this.shouldInvoke()) return;

      if (changedNodes.has('income-expense-row') || changedNodes.has('income-expense-column income-expense-number')) {
        this.invoke();
      }
    }
  }, {
    key: 'onRouteChanged',
    value: function onRouteChanged() {
      if (this.shouldInvoke()) {
        this.invoke();
      }
    }
  }]);

  return CompactIncomeVsExpense;
}(_feature.Feature);

/***/ }),
/* 551 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(552);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 552 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".income-expense-column:first-child {\n\tmin-width: 200px;\n}\n\n.income-expense-column.income-expense-column-header,\n.income-expense-column.income-expense-number {\n\tmin-width: 115px;\n}\n\n.income-expense-column {\n\tpadding: 2px;\n}\n\n.income-expense-level2 .income-expense-column:first-child {\n\tfont-weight: 500\n}\n", ""]);

// exports


/***/ }),
/* 553 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.isFeatureEnabled = isFeatureEnabled;
function isFeatureEnabled(feature) {
  return typeof feature.settings.enabled === 'boolean' && feature.settings.enabled || typeof feature.settings.enabled === 'string' && feature.settings.enabled !== '0' // assumes '0' means disabled
  ;
}

/***/ }),
/* 554 */
/***/ (function(module, exports, __webpack_require__) {


        var result = __webpack_require__(555);

        if (typeof result === "string") {
            module.exports = result;
        } else {
            module.exports = result.toString();
        }
    

/***/ }),
/* 555 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)(undefined);
// imports


// module
exports.push([module.i, ".accounts-toolbar {\n  display: flex;\n  justify-content: space-between;\n  padding-top: 0;\n}\n\n.accounts-toolbar .accounts-toolbar-left,\n.accounts-toolbar .accounts-toolbar-right,\n.accounts-toolbar.buttons-can-overflow .accounts-toolbar-left {\n  align-items: center;\n  flex-shrink: 0;\n  height: auto;\n}\n\n.accounts-toolbar .accounts-toolbar-right {\n  display: flex;\n  flex-direction: row-reverse;\n}\n\n.accounts-toolbar .accounts-toolbar-right > .button {\n  position: static;\n}\n\n.accounts-toolbar .transaction-search {\n  height: auto;\n}\n\n.accounts-toolbar .transaction-search .transaction-search-input {\n  position: static;\n}\n", ""]);

// exports


/***/ })
/******/ ]);
//# sourceMappingURL=ynab-toolkit.js.map