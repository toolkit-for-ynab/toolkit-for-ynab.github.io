/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 139);
/******/ })
/************************************************************************/
/******/ ({

/***/ 139:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _background = __webpack_require__(140);

var background = new _background.Background();
background.initListeners();

/***/ }),

/***/ 140:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Background = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _webExtensions = __webpack_require__(15);

var _storage = __webpack_require__(32);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var TOOLKIT_DISABLED_FEATURE_SETTING = 'DisableToolkit';

var Background = exports.Background = function () {
  function Background() {
    var _this = this;

    _classCallCheck(this, Background);

    this._browser = (0, _webExtensions.getBrowser)();
    this._storage = new _storage.ToolkitStorage();

    this._handleMessage = function (message, sender, sendResponse) {
      switch (message.type) {
        case 'storage':
          _this._handleStorageMessage(message.content, sendResponse);
          break;
        default:
          console.log('unknown message', message);
      }
    };

    this._handleStorageMessage = function (request, callback) {
      switch (request.type) {
        case 'keys':
          callback(Object.keys(localStorage));
          break;
        case 'get':
          callback(localStorage.getItem(request.itemName));
          break;
        default:
          console.log('unknown storage request', request);
      }
    };

    this._updatePopupIcon = function (isToolkitDisabled) {
      var imagePath = 'assets/images/icons/button' + (isToolkitDisabled ? '-disabled' : '') + '.png';
      var imageURL = _this._browser.runtime.getURL(imagePath);
      _this._browser.browserAction.setIcon({ path: imageURL });
    };

    this._storage.getFeatureSetting(TOOLKIT_DISABLED_FEATURE_SETTING).then(this._updatePopupIcon);
  }

  _createClass(Background, [{
    key: 'initListeners',
    value: function initListeners() {
      this._browser.runtime.onMessage.addListener(this._handleMessage);
      this._storage.onFeatureSettingChanged('DisableToolkit', this._updatePopupIcon);
    }
  }]);

  return Background;
}();

/***/ }),

/***/ 15:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getBrowserName = getBrowserName;
var getBrowser = exports.getBrowser = function getBrowser() {
  if (typeof browser !== 'undefined') {
    return browser;
  } else if (typeof chrome !== 'undefined') {
    return chrome;
  }
};

function getBrowserName() {
  var _browser = getBrowser();
  var URL = _browser.runtime.getURL('');

  if (URL.startsWith('chrome-extension://')) {
    return 'chrome';
  } else if (URL.startsWith('moz-extension://')) {
    return 'firefox';
  } else if (URL.startsWith('ms-browser-extension://')) {
    return 'edge';
  }

  return '';
}

/***/ }),

/***/ 32:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ToolkitStorage = exports.featureSettingKey = undefined;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _webExtensions = __webpack_require__(15);

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var FEATURE_SETTING_PREFIX = 'toolkit-feature:';

var featureSettingKey = exports.featureSettingKey = function featureSettingKey(featureName) {
  return '' + FEATURE_SETTING_PREFIX + featureName;
};

var ToolkitStorage = exports.ToolkitStorage = function () {
  function ToolkitStorage() {
    var _this = this;

    _classCallCheck(this, ToolkitStorage);

    this._browser = (0, _webExtensions.getBrowser)();
    this._storageArea = 'local';
    this._storageListeners = new Map();

    this._listenForChanges = function (changes, areaName) {
      if (areaName !== _this._storageArea) return;

      var _loop = function _loop(key, value) {
        if (_this._storageListeners.has(key)) {
          var listeners = _this._storageListeners.get(key);
          listeners.forEach(function (listener) {
            listener(value.newValue);
          });
        }
      };

      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = Object.entries(changes)[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var _ref = _step.value;

          var _ref2 = _slicedToArray(_ref, 2);

          var key = _ref2[0];
          var value = _ref2[1];

          _loop(key, value);
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }
    };

    this._browser.storage.onChanged.addListener(this._listenForChanges);
  }

  // many features have been built with the assumption that settings come back
  // as strings and it's just easier to maintain that assumption rather than update
  // those features. so override options with parse: false when getting feature settings


  _createClass(ToolkitStorage, [{
    key: 'getFeatureSetting',
    value: function getFeatureSetting(settingName) {
      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      var getFeatureSettingOptions = _extends({
        parse: false
      }, options);

      return this.getStorageItem(featureSettingKey(settingName), getFeatureSettingOptions);
    }
  }, {
    key: 'getFeatureSettings',
    value: function getFeatureSettings(settingNames) {
      var _this2 = this;

      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      var getFeatureSettingOptions = _extends({
        parse: false
      }, options);

      return Promise.all(settingNames.map(function (settingName) {
        return _this2.getStorageItem(featureSettingKey(settingName), getFeatureSettingOptions);
      }));
    }
  }, {
    key: 'setFeatureSetting',
    value: function setFeatureSetting(settingName, value) {
      var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

      return this.setStorageItem(featureSettingKey(settingName), value, options);
    }
  }, {
    key: 'removeFeatureSetting',
    value: function removeFeatureSetting(settingName) {
      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      return this.removeStorageItem(featureSettingKey(settingName), options);
    }
  }, {
    key: 'getStorageItem',
    value: function getStorageItem(itemKey) {
      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      return this._get(itemKey, options).then(function (value) {
        if (typeof value === 'undefined' && typeof options.default !== 'undefined') {
          return options.default;
        }

        return value;
      });
    }
  }, {
    key: 'removeStorageItem',
    value: function removeStorageItem(itemKey) {
      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      return this._remove(itemKey, options);
    }
  }, {
    key: 'setStorageItem',
    value: function setStorageItem(itemKey, itemData) {
      var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

      return this._set(itemKey, itemData, options);
    }
  }, {
    key: 'getStoredFeatureSettings',
    value: function getStoredFeatureSettings() {
      var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      return this._get(null, options).then(function (allStorage) {
        var storedSettings = [];
        var _iteratorNormalCompletion2 = true;
        var _didIteratorError2 = false;
        var _iteratorError2 = undefined;

        try {
          for (var _iterator2 = Object.entries(allStorage)[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
            var _ref3 = _step2.value;

            var _ref4 = _slicedToArray(_ref3, 1);

            var key = _ref4[0];

            if (key.startsWith(FEATURE_SETTING_PREFIX)) {
              storedSettings.push(key.replace(FEATURE_SETTING_PREFIX, ''));
            }
          }
        } catch (err) {
          _didIteratorError2 = true;
          _iteratorError2 = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion2 && _iterator2.return) {
              _iterator2.return();
            }
          } finally {
            if (_didIteratorError2) {
              throw _iteratorError2;
            }
          }
        }

        return storedSettings;
      });
    }
  }, {
    key: 'onStorageItemChanged',
    value: function onStorageItemChanged(storageKey, callback) {
      if (this._storageListeners.has(storageKey)) {
        var listeners = this._storageListeners.get(storageKey);
        this._storageListeners.set(storageKey, [].concat(_toConsumableArray(listeners), [callback]));
      } else {
        this._storageListeners.set(storageKey, [callback]);
      }
    }
  }, {
    key: 'offStorageItemChanged',
    value: function offStorageItemChanged(storageKey, callback) {
      if (this._storageListeners.has(storageKey)) {
        var listeners = this._storageListeners.get(storageKey);
        this._storageListeners.set(storageKey, listeners.filter(function (listener) {
          return listener !== callback;
        }));
      }
    }
  }, {
    key: 'onFeatureSettingChanged',
    value: function onFeatureSettingChanged(settingName, callback) {
      this.onStorageItemChanged(featureSettingKey(settingName), callback);
    }
  }, {
    key: 'offFeatureSettingChanged',
    value: function offFeatureSettingChanged(settingName, callback) {
      this.offStorageItemChanged(featureSettingKey(settingName), callback);
    }
  }, {
    key: '_get',
    value: function _get(key, options) {
      var _this3 = this;

      var getOptions = _extends({
        parse: true,
        storageArea: this._storageArea
      }, options);

      return new Promise(function (resolve, reject) {
        try {
          _this3._browser.storage[getOptions.storageArea].get(key, function (data) {
            // if we're fetching everything -- don't try parsing it
            if (key === null) {
              return resolve(data);
            }

            try {
              if (getOptions.parse) {
                resolve(JSON.parse(data[key]));
              } else {
                resolve(data[key]);
              }
            } catch (_ignore) {
              resolve(data[key]);
            }
          });
        } catch (e) {
          reject(e);
        }
      });
    }
  }, {
    key: '_remove',
    value: function _remove(key, options) {
      var _this4 = this;

      var storageArea = options.storageArea || this._storageArea;

      return new Promise(function (resolve, reject) {
        try {
          _this4._browser.storage[storageArea].remove(key, resolve);
        } catch (e) {
          reject(e);
        }
      });
    }
  }, {
    key: '_set',
    value: function _set(key, value, options) {
      var _this5 = this;

      var storageArea = options.storageArea || this._storageArea;

      return new Promise(function (resolve, reject) {
        try {
          var update = _defineProperty({}, key, value);
          _this5._browser.storage[storageArea].set(update, resolve);
        } catch (e) {
          reject(e);
        }
      });
    }
  }]);

  return ToolkitStorage;
}();

/***/ })

/******/ });
//# sourceMappingURL=background.js.map