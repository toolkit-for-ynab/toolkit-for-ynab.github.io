/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 144);
/******/ })
/************************************************************************/
/******/ ({

/***/ 144:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _webExtensions = __webpack_require__(15);

var _storage = __webpack_require__(32);

var _settings = __webpack_require__(72);

var _domInjectors = __webpack_require__(145);

var storage = new _storage.ToolkitStorage();

function applySettingsToDom(userSettings) {
  _settings.allToolkitSettings.forEach(function (setting) {
    var userSettingValue = userSettings[setting.name];
    // Check for specific upgrade path where a boolean setting gets
    // changed to a select. Previous value will be 'true' but
    // that should map to '1' in select land.
    // eslint-disable-next-line eqeqeq
    if (setting.actions && userSettingValue === true && '1' in setting.actions && !('true' in setting.actions)) {
      userSettingValue = '1';
    }

    if (setting.actions && userSettingValue in setting.actions) {
      var selectedActions = setting.actions[userSettingValue.toString()];
      for (var i = 0; i < selectedActions.length; i += 2) {
        var action = selectedActions[i];
        var target = selectedActions[i + 1];

        if (action === 'injectCSS') {
          (0, _domInjectors.injectCSS)('web-accessibles/' + target);
        } else if (action === 'injectScript') {
          (0, _domInjectors.injectScript)('web-accessibles/' + target);
        } else {
          var error = 'Invalid Action: "' + action + '". Only injectCSS and injectScript are currently supported.';
          throw error;
        }
      }
    }
  });
}

function sendToolkitBootstrap(userSettings) {
  window.postMessage({
    type: 'ynab-toolkit-bootstrap',
    ynabToolKit: {
      assets: {
        logo: (0, _webExtensions.getBrowser)().runtime.getURL('assets/images/logos/toolkitforynab-logo-400.png')
      },
      version: (0, _webExtensions.getBrowser)().runtime.getManifest().version,
      options: userSettings
    }
  }, '*');
}

function messageHandler(event) {
  if (event.data !== 'ynab-toolkit-loaded') return;

  initializeYNABToolkit();
  window.removeEventListener('message', messageHandler);
}

function initializeYNABToolkit() {
  (0, _settings.getUserSettings)().then(function (userSettings) {
    sendToolkitBootstrap(userSettings);

    /* Load this to setup shared utility functions */
    (0, _domInjectors.injectScript)('web-accessibles/legacy/features/shared/main.js');

    /* Global toolkit css. */
    (0, _domInjectors.injectCSS)('web-accessibles/legacy/features/shared/main.css');

    /* This script to be built automatically by the python script */
    (0, _domInjectors.injectScript)('web-accessibles/legacy/features/act-on-change/feedChanges.js');

    /* Load this to setup behaviors when the DOM updates and shared functions */
    (0, _domInjectors.injectScript)('web-accessibles/legacy/features/act-on-change/main.js');

    applySettingsToDom(userSettings);
  });
}

storage.getFeatureSetting('DisableToolkit').then(function (isToolkitDisabled) {
  if (isToolkitDisabled) {
    console.log('Toolkit-for-YNAB is disabled!');
    return;
  }

  // Load the toolkit bundle onto the YNAB dom
  (0, _domInjectors.injectScript)('web-accessibles/ynab-toolkit.js');

  // wait for the bundle to tell us it's loaded
  window.addEventListener('message', messageHandler);
});

/***/ }),

/***/ 145:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.injectCSS = injectCSS;
exports.injectScript = injectScript;

var _webExtensions = __webpack_require__(15);

function injectCSS(path) {
  var link = document.createElement('link');
  link.setAttribute('rel', 'stylesheet');
  link.setAttribute('type', 'text/css');
  link.setAttribute('href', (0, _webExtensions.getBrowser)().runtime.getURL(path));

  document.getElementsByTagName('head')[0].appendChild(link);
}

function injectScript(path) {
  var script = document.createElement('script');
  script.setAttribute('type', 'text/javascript');
  script.setAttribute('src', (0, _webExtensions.getBrowser)().runtime.getURL(path));

  document.getElementsByTagName('head')[0].appendChild(script);
}

/***/ }),

/***/ 15:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getBrowserName = getBrowserName;
var getBrowser = exports.getBrowser = function getBrowser() {
  if (typeof browser !== 'undefined') {
    return browser;
  } else if (typeof chrome !== 'undefined') {
    return chrome;
  }
};

function getBrowserName() {
  var _browser = getBrowser();
  var URL = _browser.runtime.getURL('');

  if (URL.startsWith('chrome-extension://')) {
    return 'chrome';
  } else if (URL.startsWith('moz-extension://')) {
    return 'firefox';
  } else if (URL.startsWith('ms-browser-extension://')) {
    return 'edge';
  }

  return '';
}

/***/ }),

/***/ 32:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ToolkitStorage = exports.featureSettingKey = undefined;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _webExtensions = __webpack_require__(15);

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var FEATURE_SETTING_PREFIX = 'toolkit-feature:';

var featureSettingKey = exports.featureSettingKey = function featureSettingKey(featureName) {
  return '' + FEATURE_SETTING_PREFIX + featureName;
};

var ToolkitStorage = exports.ToolkitStorage = function () {
  function ToolkitStorage() {
    var _this = this;

    _classCallCheck(this, ToolkitStorage);

    this._browser = (0, _webExtensions.getBrowser)();
    this._storageArea = 'local';
    this._storageListeners = new Map();

    this._listenForChanges = function (changes, areaName) {
      if (areaName !== _this._storageArea) return;

      var _loop = function _loop(key, value) {
        if (_this._storageListeners.has(key)) {
          var listeners = _this._storageListeners.get(key);
          listeners.forEach(function (listener) {
            listener(value.newValue);
          });
        }
      };

      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = Object.entries(changes)[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var _ref = _step.value;

          var _ref2 = _slicedToArray(_ref, 2);

          var key = _ref2[0];
          var value = _ref2[1];

          _loop(key, value);
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }
    };

    this._browser.storage.onChanged.addListener(this._listenForChanges);
  }

  // many features have been built with the assumption that settings come back
  // as strings and it's just easier to maintain that assumption rather than update
  // those features. so override options with parse: false when getting feature settings


  _createClass(ToolkitStorage, [{
    key: 'getFeatureSetting',
    value: function getFeatureSetting(settingName) {
      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      var getFeatureSettingOptions = _extends({
        parse: false
      }, options);

      return this.getStorageItem(featureSettingKey(settingName), getFeatureSettingOptions);
    }
  }, {
    key: 'getFeatureSettings',
    value: function getFeatureSettings(settingNames) {
      var _this2 = this;

      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      var getFeatureSettingOptions = _extends({
        parse: false
      }, options);

      return Promise.all(settingNames.map(function (settingName) {
        return _this2.getStorageItem(featureSettingKey(settingName), getFeatureSettingOptions);
      }));
    }
  }, {
    key: 'setFeatureSetting',
    value: function setFeatureSetting(settingName, value) {
      var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

      return this.setStorageItem(featureSettingKey(settingName), value, options);
    }
  }, {
    key: 'removeFeatureSetting',
    value: function removeFeatureSetting(settingName) {
      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      return this.removeStorageItem(featureSettingKey(settingName), options);
    }
  }, {
    key: 'getStorageItem',
    value: function getStorageItem(itemKey) {
      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      return this._get(itemKey, options).then(function (value) {
        if (typeof value === 'undefined' && typeof options.default !== 'undefined') {
          return options.default;
        }

        return value;
      });
    }
  }, {
    key: 'removeStorageItem',
    value: function removeStorageItem(itemKey) {
      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      return this._remove(itemKey, options);
    }
  }, {
    key: 'setStorageItem',
    value: function setStorageItem(itemKey, itemData) {
      var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

      return this._set(itemKey, itemData, options);
    }
  }, {
    key: 'getStoredFeatureSettings',
    value: function getStoredFeatureSettings() {
      var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      return this._get(null, options).then(function (allStorage) {
        var storedSettings = [];
        var _iteratorNormalCompletion2 = true;
        var _didIteratorError2 = false;
        var _iteratorError2 = undefined;

        try {
          for (var _iterator2 = Object.entries(allStorage)[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
            var _ref3 = _step2.value;

            var _ref4 = _slicedToArray(_ref3, 1);

            var key = _ref4[0];

            if (key.startsWith(FEATURE_SETTING_PREFIX)) {
              storedSettings.push(key.replace(FEATURE_SETTING_PREFIX, ''));
            }
          }
        } catch (err) {
          _didIteratorError2 = true;
          _iteratorError2 = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion2 && _iterator2.return) {
              _iterator2.return();
            }
          } finally {
            if (_didIteratorError2) {
              throw _iteratorError2;
            }
          }
        }

        return storedSettings;
      });
    }
  }, {
    key: 'onStorageItemChanged',
    value: function onStorageItemChanged(storageKey, callback) {
      if (this._storageListeners.has(storageKey)) {
        var listeners = this._storageListeners.get(storageKey);
        this._storageListeners.set(storageKey, [].concat(_toConsumableArray(listeners), [callback]));
      } else {
        this._storageListeners.set(storageKey, [callback]);
      }
    }
  }, {
    key: 'offStorageItemChanged',
    value: function offStorageItemChanged(storageKey, callback) {
      if (this._storageListeners.has(storageKey)) {
        var listeners = this._storageListeners.get(storageKey);
        this._storageListeners.set(storageKey, listeners.filter(function (listener) {
          return listener !== callback;
        }));
      }
    }
  }, {
    key: 'onFeatureSettingChanged',
    value: function onFeatureSettingChanged(settingName, callback) {
      this.onStorageItemChanged(featureSettingKey(settingName), callback);
    }
  }, {
    key: 'offFeatureSettingChanged',
    value: function offFeatureSettingChanged(settingName, callback) {
      this.offStorageItemChanged(featureSettingKey(settingName), callback);
    }
  }, {
    key: '_get',
    value: function _get(key, options) {
      var _this3 = this;

      var getOptions = _extends({
        parse: true,
        storageArea: this._storageArea
      }, options);

      return new Promise(function (resolve, reject) {
        try {
          _this3._browser.storage[getOptions.storageArea].get(key, function (data) {
            // if we're fetching everything -- don't try parsing it
            if (key === null) {
              return resolve(data);
            }

            try {
              if (getOptions.parse) {
                resolve(JSON.parse(data[key]));
              } else {
                resolve(data[key]);
              }
            } catch (_ignore) {
              resolve(data[key]);
            }
          });
        } catch (e) {
          reject(e);
        }
      });
    }
  }, {
    key: '_remove',
    value: function _remove(key, options) {
      var _this4 = this;

      var storageArea = options.storageArea || this._storageArea;

      return new Promise(function (resolve, reject) {
        try {
          _this4._browser.storage[storageArea].remove(key, resolve);
        } catch (e) {
          reject(e);
        }
      });
    }
  }, {
    key: '_set',
    value: function _set(key, value, options) {
      var _this5 = this;

      var storageArea = options.storageArea || this._storageArea;

      return new Promise(function (resolve, reject) {
        try {
          var update = _defineProperty({}, key, value);
          _this5._browser.storage[storageArea].set(update, resolve);
        } catch (e) {
          reject(e);
        }
      });
    }
  }]);

  return ToolkitStorage;
}();

/***/ }),

/***/ 72:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

var _settings = __webpack_require__(73);

Object.keys(_settings).forEach(function (key) {
  if (key === "default" || key === "__esModule") return;
  Object.defineProperty(exports, key, {
    enumerable: true,
    get: function get() {
      return _settings[key];
    }
  });
});
exports.getUserSettings = getUserSettings;

var _webExtensions = __webpack_require__(15);

var _storage = __webpack_require__(32);

var storage = new _storage.ToolkitStorage();

function getKangoKeys() {
  return new Promise(function (resolve) {
    (0, _webExtensions.getBrowser)().runtime.sendMessage({ type: 'storage', content: { type: 'keys' } }, function (response) {
      resolve(response);
    });
  });
}

function persistKangoStorageSetting(setting, persistAs) {
  var settingName = persistAs || setting;

  return new Promise(function (resolve) {
    (0, _webExtensions.getBrowser)().runtime.sendMessage({ type: 'storage', content: { type: 'get', itemName: setting } }, function (response) {
      var validValue = response;
      if (response === 'true' || response === 'false') {
        validValue = JSON.parse(response);
      }

      storage.setFeatureSetting(settingName, validValue).then(resolve);
    });
  });
}

function updateLegacySetting(legacySetting, newSetting) {
  return storage.getFeatureSetting(legacySetting).then(function (legacyValue) {
    return storage.setFeatureSetting(newSetting, legacyValue);
  });
}

function ensureSettingIsValid(name, value) {
  var validValue = value;
  if (value === 'true' || value === 'false') {
    validValue = JSON.parse(value);
    return storage.setFeatureSetting(name, JSON.parse(value));
  }

  return validValue;
}

function getUserSettings() {
  return new Promise(function (resolve) {
    Promise.all([getKangoKeys(), storage.getStoredFeatureSettings()]).then(function (_ref) {
      var _ref2 = _slicedToArray(_ref, 2),
          kangoKeys = _ref2[0],
          storedFeatureSettings = _ref2[1];

      var settingPromises = _settings.allToolkitSettings.map(function (setting) {
        var legacySettingName = _settings.legacySettingMap[setting.name];
        var settingIsPersisted = storedFeatureSettings.includes(setting.name);
        var leagcySettingPersisted = storedFeatureSettings.includes(legacySettingName);

        // this should be the case for all users once they've loaded the toolkit post web-extensions
        if (settingIsPersisted) {
          return storage.getFeatureSetting(setting.name).then(function (persistedValue) {
            return ensureSettingIsValid(setting.name, persistedValue);
          });

          // this will be the case for any feature that has been migrated post web-extensions
        } else if (leagcySettingPersisted) {
          return updateLegacySetting(legacySettingName, setting.name).then(function () {
            return storage.getFeatureSetting(setting.name);
          }).then(function (persistedValue) {
            return ensureSettingIsValid(setting.name, persistedValue);
          });
        }

        // if we've not already returned then this is either the first-load of the extension post
        // web-extensions or this is an entirely new feature. check the former case first and then
        // assume the latter.

        // kango stored settings in localStorage of the background page so look there first
        var isInKangoStorage = kangoKeys.includes(setting.name);
        var isLegacySettingInKangoStorage = kangoKeys.includes(legacySettingName);

        // we have the setting so go ahead and persist it to storage and carry on
        if (isInKangoStorage) {
          return persistKangoStorageSetting(setting.name).then(function () {
            return storage.getFeatureSetting(setting.name);
          });

          // this is a migration feature -- need to persist the new setting name
        } else if (isLegacySettingInKangoStorage) {
          return persistKangoStorageSetting(legacySettingName, setting.name).then(function () {
            return storage.getFeatureSetting(setting.name);
          });
        }

        // if we're still here then all we have left is a new feature. persist the default.
        return storage.setFeatureSetting(setting.name, setting.default).then(function () {
          return storage.getFeatureSetting(setting.name);
        });
      });

      Promise.all(settingPromises).then(function (persistedSettings) {
        var userSettings = _settings.allToolkitSettings.reduce(function (allSettings, currentSetting, index) {
          allSettings[currentSetting.name] = persistedSettings[index];
          return allSettings;
        }, {});

        resolve(userSettings);
      });
    });
  });
}

/***/ }),

/***/ 73:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
/* eslint-disable */
/*
 ***********************************************************
 * Warning: This is a file generated by the build process. *
 *                                                         *
 * Any changes you make manually will be overwritten       *
 * the next time you run ./build or build.bat!             *
 ***********************************************************
*/

if (typeof window.ynabToolKit === 'undefined') {
  window.ynabToolKit = {};
}

var legacySettingMap = exports.legacySettingMap = { "AccountsDisplayDensity": "accountsDisplayDensity", "AutoCloseReconcile": "closeReconcileWindow", "BetterScrollbars": "betterScrollbars", "BudgetProgressBars": "budgetProgressBars", "BudgetQuickSwitch": "budgetQuickSwitch", "CategoryActivityPopupWidth": "categoryActivityPopupWidth", "ChangeEnterBehavior": "changeEnterBehavior", "CalendarFirstDay": "calendarFirstDay", "CheckCreditBalances": "checkCreditBalances", "CheckNumbers": "checkNumbers", "ClearSelection": "accountsClearSelection", "ColourBlindMode": "colourBlindMode", "CollapseSideMenu": "collapseSideMenu", "CurrentMonthIndicator": "currentMonthIndicator", "DaysOfBuffering": "daysOfBuffering", "DaysOfBufferingHistoryLookup": "daysOfBufferingHistoryLookup", "EditAccountButton": "editButtonPosition", "EnableRetroCalculator": "enableRetroCalculator", "EmphasizedOutflows": "accountsEmphasizedOutflows", "GoalWarningColor": "goalWarningColor", "GoogleFontsSelector": "googleFontsSelector", "HideAccountBalancesType": "hideAccountBalancesType", "HideAgeOfMoney": "hideAgeOfMoney", "HideHelp": "hideHelp", "ImportNotification": "importNotification", "LargerClickableIcons": "largerClickableIcons", "MonthlyNotesPopupWidth": "monthlyNotesPopupWidth", "NavDisplayDensity": "navDisplayDensity", "PrintingImprovements": "printingImprovements", "QuickBudgetWarning": "warnOnQuickBudget", "ReconciledTextColor": "reconciledTextColor", "RemovePositiveHighlight": "removePositiveHighlight", "ResizeInspector": "resizeInspector", "RowHeight": "accountsRowHeight", "RowsHeight": "budgetRowsHeight", "RunningBalance": "runningBalance", "SeamlessBudgetHeader": "seamlessBudgetHeader", "ShowIntercom": "showIntercom", "SplitKeyboardShortcut": "splitKeyboardShortcut", "SquareNegativeMode": "squareNegativeMode", "StealingFromFuture": "stealingFromNextMonth", "StripedRows": "accountsStripedRows", "ToBeBudgetedWarning": "toBeBudgetedWarning", "ToggleMasterCategories": "collapseExpandBudgetGroups", "ToggleSplits": "toggleSplits" };
var allToolkitSettings = exports.allToolkitSettings = [{ "name": "goalIndicator", "type": "checkbox", "default": false, "section": "budget", "title": "Add Goals Indication", "description": "Add indicators for subcategories with goals. Types: (M)onthly goal,  target by (D)ate goal, (T)arget without date, and (U)pcoming transactions.", "actions": { "true": ["injectCSS", "legacy/features/goal-indicator/main.css", "injectScript", "legacy/features/goal-indicator/main.js", "injectScript", "legacy/features/budget-category-info/main.js"] } }, { "name": "highlightNegativesNegative", "type": "checkbox", "default": false, "section": "budget", "title": "Highlight all Negative Category Balances Red", "description": "Ensure all negative balances are highlighted red instead of yellow, even with credit card spending.", "actions": { "true": ["injectCSS", "legacy/features/highlight-negatives-negative/main.css", "injectScript", "legacy/features/budget-category-info/main.js"] } }, { "name": "l10n", "title": "Localization of YNAB", "default": "0", "section": "general", "type": "select", "options": [{ "name": "Default", "value": "0" }, { "name": "Arabic (30%)", "value": "arabic" }, { "name": "Catalan (1%)", "value": "catalan" }, { "name": "Chinese Simplified (15%)", "value": "chinese simplified" }, { "name": "Chinese Traditional (43%)", "value": "chinese traditional" }, { "name": "Czech (73%)", "value": "czech" }, { "name": "Danish (52%)", "value": "danish" }, { "name": "Dutch (51%)", "value": "dutch" }, { "name": "Finnish (50%)", "value": "finnish" }, { "name": "French (53%)", "value": "french" }, { "name": "German (52%)", "value": "german" }, { "name": "Hungarian (45%)", "value": "hungarian" }, { "name": "Icelandic (5%)", "value": "icelandic" }, { "name": "Indonesian (100%)", "value": "indonesian" }, { "name": "Italian (16%)", "value": "italian" }, { "name": "Korean (1%)", "value": "korean" }, { "name": "Latvian (13%)", "value": "latvian" }, { "name": "Lithuanian (1%)", "value": "lithuanian" }, { "name": "Norwegian (52%)", "value": "norwegian" }, { "name": "Polish (100%)", "value": "polish" }, { "name": "Portuguese, Brazilian (52%)", "value": "portuguese, brazilian" }, { "name": "Portuguese (23%)", "value": "portuguese" }, { "name": "Romanian (2%)", "value": "romanian" }, { "name": "Russian (52%)", "value": "russian" }, { "name": "Slovenian (1%)", "value": "slovenian" }, { "name": "Spanish (98%)", "value": "spanish" }, { "name": "Swedish (36%)", "value": "swedish" }, { "name": "Tagalog (1%)", "value": "tagalog" }, { "name": "Turkish (100%)", "value": "turkish" }, { "name": "Ukrainian (5%)", "value": "ukrainian" }, { "name": "Vietnamese (13%)", "value": "vietnamese" }], "actions": { "portuguese": ["injectScript", "legacy/features/l10n/locales/Portuguese.json", "injectScript", "legacy/features/l10n/main.js"], "czech": ["injectScript", "legacy/features/l10n/locales/Czech.json", "injectScript", "legacy/features/l10n/main.js"], "spanish": ["injectScript", "legacy/features/l10n/locales/Spanish.json", "injectScript", "legacy/features/l10n/main.js"], "polish": ["injectScript", "legacy/features/l10n/locales/Polish.json", "injectScript", "legacy/features/l10n/main.js"], "arabic": ["injectScript", "legacy/features/l10n/locales/Arabic.json", "injectScript", "legacy/features/l10n/main.js"], "swedish": ["injectScript", "legacy/features/l10n/locales/Swedish.json", "injectScript", "legacy/features/l10n/main.js"], "icelandic": ["injectScript", "legacy/features/l10n/locales/Icelandic.json", "injectScript", "legacy/features/l10n/main.js"], "turkish": ["injectScript", "legacy/features/l10n/locales/Turkish.json", "injectScript", "legacy/features/l10n/main.js"], "romanian": ["injectScript", "legacy/features/l10n/locales/Romanian.json", "injectScript", "legacy/features/l10n/main.js"], "slovenian": ["injectScript", "legacy/features/l10n/locales/Slovenian.json", "injectScript", "legacy/features/l10n/main.js"], "german": ["injectScript", "legacy/features/l10n/locales/German.json", "injectScript", "legacy/features/l10n/main.js"], "dutch": ["injectScript", "legacy/features/l10n/locales/Dutch.json", "injectScript", "legacy/features/l10n/main.js"], "portuguese, brazilian": ["injectScript", "legacy/features/l10n/locales/Portuguese, Brazilian.json", "injectScript", "legacy/features/l10n/main.js"], "danish": ["injectScript", "legacy/features/l10n/locales/Danish.json", "injectScript", "legacy/features/l10n/main.js"], "indonesian": ["injectScript", "legacy/features/l10n/locales/Indonesian.json", "injectScript", "legacy/features/l10n/main.js"], "tagalog": ["injectScript", "legacy/features/l10n/locales/Tagalog.json", "injectScript", "legacy/features/l10n/main.js"], "hungarian": ["injectScript", "legacy/features/l10n/locales/Hungarian.json", "injectScript", "legacy/features/l10n/main.js"], "ukrainian": ["injectScript", "legacy/features/l10n/locales/Ukrainian.json", "injectScript", "legacy/features/l10n/main.js"], "lithuanian": ["injectScript", "legacy/features/l10n/locales/Lithuanian.json", "injectScript", "legacy/features/l10n/main.js"], "french": ["injectScript", "legacy/features/l10n/locales/French.json", "injectScript", "legacy/features/l10n/main.js"], "norwegian": ["injectScript", "legacy/features/l10n/locales/Norwegian.json", "injectScript", "legacy/features/l10n/main.js"], "russian": ["injectScript", "legacy/features/l10n/locales/Russian.json", "injectScript", "legacy/features/l10n/main.js"], "korean": ["injectScript", "legacy/features/l10n/locales/Korean.json", "injectScript", "legacy/features/l10n/main.js"], "finnish": ["injectScript", "legacy/features/l10n/locales/Finnish.json", "injectScript", "legacy/features/l10n/main.js"], "catalan": ["injectScript", "legacy/features/l10n/locales/Catalan.json", "injectScript", "legacy/features/l10n/main.js"], "chinese traditional": ["injectScript", "legacy/features/l10n/locales/Chinese Traditional.json", "injectScript", "legacy/features/l10n/main.js"], "vietnamese": ["injectScript", "legacy/features/l10n/locales/Vietnamese.json", "injectScript", "legacy/features/l10n/main.js"], "chinese simplified": ["injectScript", "legacy/features/l10n/locales/Chinese Simplified.json", "injectScript", "legacy/features/l10n/main.js"], "latvian": ["injectScript", "legacy/features/l10n/locales/Latvian.json", "injectScript", "legacy/features/l10n/main.js"], "italian": ["injectScript", "legacy/features/l10n/locales/Italian.json", "injectScript", "legacy/features/l10n/main.js"] }, "description": "Localization of interface." }, { "name": "pacing", "type": "select", "default": false, "section": "budget", "title": "Add Pacing to the Budget", "description": "Add a column for 'pacing' which shows you how much money you've spent based on how far you are through the month. Note that clicking on the pacing value will toggle emphasis, allowing you to selectively enable the feature per category.", "options": [{ "name": "Disabled", "value": "0" }, { "name": "Show Full Amount", "value": "1" }, { "name": "Show Simple Indicator", "value": "2" }, { "name": "Show Days Ahead/Behind Schedule", "value": "3" }], "actions": { "1": ["injectCSS", "legacy/features/pacing/main.css", "injectScript", "legacy/features/pacing/main.js"], "2": ["injectCSS", "legacy/features/pacing/main.css", "injectScript", "legacy/features/pacing/main.js"], "3": ["injectCSS", "legacy/features/pacing/main.css", "injectScript", "legacy/features/pacing/main.js"] } }, { "name": "popupCalculator", "type": "checkbox", "default": false, "section": "general", "title": "Popup Calculator", "description": "\nProvides the same calculator capability that YNAB4 had.\n* Account Screen - when adding or editing a transaction, a new button is added to the left of the 'Save and add another' or 'Save' buttons. Click the button to display the calculator.\n* Budget Screen - adds a new button to the right of the value in the BUDGETED column when the sub-category is selected. Click the button to display the calculator.\n", "actions": { "true": ["injectCSS", "legacy/features/popup-calculator/main.css", "injectScript", "legacy/features/popup-calculator/main.js", "injectScript", "legacy/features/popup-calculator/account/main.js", "injectCSS", "legacy/features/popup-calculator/account/account_calc.css", "injectCSS", "legacy/features/popup-calculator/budget/budget_calc.css", "injectScript", "legacy/features/popup-calculator/budget/main.js"] } }, { "name": "reports", "type": "checkbox", "default": true, "section": "general", "title": "Reports", "description": "Adds a button to the side bar to access reports. Net Worth, Spending By Category, and Income vs. Expense are all available reports.", "actions": { "true": ["injectScript", "legacy/features/lib/highcharts-6.0.4/highcharts.js", "injectCSS", "legacy/features/lib/noUiSlider.8.2.1/nouislider.min.css", "injectScript", "legacy/features/lib/noUiSlider.8.2.1/nouislider.min.js", "injectCSS", "legacy/features/toolkit-reports/main.css", "injectScript", "legacy/features/toolkit-reports/main.js", "injectScript", "legacy/features/toolkit-reports/netWorth/main.js", "injectCSS", "legacy/features/toolkit-reports/netWorth/main.css", "injectScript", "legacy/features/toolkit-reports/spendingByCategory/main.js", "injectCSS", "legacy/features/toolkit-reports/spendingByCategory/main.css", "injectScript", "legacy/features/toolkit-reports/spendingByPayee/main.js", "injectCSS", "legacy/features/toolkit-reports/spendingByPayee/main.css", "injectScript", "legacy/features/toolkit-reports/incomeVsExpense/main.js", "injectCSS", "legacy/features/toolkit-reports/incomeVsExpense/main.css"] } }, { "name": "AdjustableColumnWidths", "type": "checkbox", "default": false, "section": "accounts", "title": "Make Column Widths Adjustable", "description": "Allows you to drag the columns to make them different sizes." }, { "name": "AutoDistributeSplits", "type": "checkbox", "default": false, "section": "accounts", "title": "Add Auto-Distribute Button To Split Transactions", "description": "Allows you to distribute the remaining amount in a split transaction proportionally to sub-transactions" }, { "name": "CalendarFirstDay", "type": "select", "default": "0", "section": "accounts", "title": "First Day of the Week in Calendar", "description": "Change the first day of the week when viewing the calendar.", "options": [{ "name": "Default (Sunday)", "value": "0" }, { "name": "Monday", "value": "1" }, { "name": "Tuesday", "value": "2" }, { "name": "Wednesday", "value": "3" }, { "name": "Thursday", "value": "4" }, { "name": "Friday", "value": "5" }, { "name": "Saturday", "value": "6" }] }, { "name": "ChangeEnterBehavior", "type": "checkbox", "default": false, "section": "accounts", "title": "Change Behaviour of Enter Key When Adding Transactions", "description": "When you press enter while adding transactions, the default behaviour is 'Save and add another'. This option changes it to just 'Save'." }, { "name": "ClearSelection", "type": "checkbox", "default": false, "section": "accounts", "title": "Clear Selection", "description": "Adds an option to the transaction edit drop-down menu to clear the current selection." }, { "name": "CustomFlagNames", "type": "checkbox", "default": false, "section": "accounts", "title": "Set Custom Flag Names (with Tooltips)", "description": "Adds the ability to set custom flag names. Tooltip for the flag name will only be visible when the cursor is hovered over the flag. *__Note__: Custom flag names are stored locally in the browser in which they are set and will __not__ be carried over to other browsers/computers. Custom flag names will be lost if browser data is cleared.*" }, { "name": "EasyTransactionApproval", "type": "checkbox", "default": false, "section": "accounts", "title": "Easy Transaction Approval", "description": "Quickly approve scheduled or linked transactions by selecting the transaction(s) and pressing 'a' or 'enter' on your keyboard. Alternately, approve single scheduled or linked transactions by right clicking on the blue 'i' or link icon." }, { "name": "AccountsEmphasizedOutflows", "type": "checkbox", "default": false, "section": "accounts", "title": "Emphasize Outflows", "description": "Make values in the outflow column red and put them in parenthesis." }, { "name": "LargerClickableIcons", "type": "checkbox", "default": false, "section": "accounts", "title": "Larger Clickable Area for Icons", "description": "Makes the uncleared, cleared and reconciled icons easier to select." }, { "name": "RightClickToEdit", "type": "checkbox", "default": true, "section": "accounts", "title": "Show Menu When Right Clicking On Transaction", "description": "Right clicking on a transaction will show the contextual menu, allowing easy access to the Edit menu options." }, { "name": "RowHeight", "type": "select", "default": "0", "section": "accounts", "title": "Height of Rows in Account Register", "description": "Change the height of transaction rows so more of them are displayed on the screen.", "options": [{ "name": "Default", "value": "0" }, { "name": "Compact", "value": "1" }, { "name": "Slim", "value": "2" }] }, { "name": "ShowCategoryBalance", "type": "checkbox", "default": false, "section": "accounts", "title": "Show Available Category Balance on Hover", "description": "Adds the total available balance to the category tooltip on each row in the Accounts register." }, { "name": "SpareChange", "type": "checkbox", "default": false, "section": "accounts", "title": "Show Spare Change", "description": "\"Imagine if you paid for all purchases in whole dollars. Shows a total of the spare change you would accumulate for the selected outflow transactions." }, { "name": "SplitKeyboardShortcut", "type": "checkbox", "default": true, "section": "accounts", "title": "Add Split Transaction Keyboard Shortcut", "description": "Instead of clicking the Split button, type 'split' in the category input to automatically create a new split transaction." }, { "name": "SplitTransactionAutoAdjust", "type": "checkbox", "default": false, "section": "accounts", "title": "Auto Adjust Split Transactions", "description": "When entering split transactions, each additional split will be auto-filled with the current remaining amount." }, { "name": "AccountsStripedRows", "type": "checkbox", "default": false, "section": "accounts", "title": "Striped Transaction Rows", "description": "Shows a light gray background on every other transaction row." }, { "name": "SwapClearedFlagged", "type": "checkbox", "default": false, "section": "accounts", "title": "Swap cleared and flagged columns", "description": "Place the Cleared column on the left and the Flagged column on the right sides of an account screen." }, { "name": "ToggleSplits", "type": "checkbox", "default": false, "section": "accounts", "title": "Add a Toggle Splits Button to the Account(s) toolbar", "description": "Clicking the Toggle Splits button shows or hides all sub-transactions within all split transactions. *__Note__: you must toggle splits open before editing a split transaction!*" }, { "name": "ToggleTransactionFilters", "type": "select", "default": "0", "section": "accounts", "title": "Toggle Scheduled and Reconciled Transaction Buttons", "description": "Easily show and hide scheduled and reconciled transactions with one click.", "options": [{ "name": "Disabled", "value": "0" }, { "name": "Show Icons", "value": "1" }, { "name": "Show Icons and Text Labels", "value": "2" }] }, { "name": "CheckNumbers", "type": "checkbox", "default": false, "section": "accounts", "title": "Add Check Number Column", "description": "Adds the check number column to your account view.", "isSubFeature": true }, { "name": "ReconciledTextColor", "type": "select", "default": false, "section": "accounts", "title": "Reconciled Text Colour", "description": "Makes the text on reconciled transactions appear in a more obvious colour of your choosing.", "options": [{ "name": "Default", "value": "0" }, { "name": "Green", "value": "1" }, { "name": "Light gray", "value": "2" }, { "name": "Dark gray", "value": "3" }, { "name": "Dark gray with green background", "value": "4" }], "isSubFeature": true }, { "name": "RunningBalance", "type": "select", "default": "0", "section": "accounts", "title": "Show Running Balance", "description": "Adds a running balance column to the accounts page (does not appear on All Accounts View)", "options": [{ "name": "Off", "value": "0" }, { "name": "On: Style any negative running balances red", "value": "1" }, { "name": "On: Do not style negative running balances", "value": "2" }], "isSubFeature": true }, { "name": "TransactionGridFeatures", "section": "system", "default": true }, { "name": "DisableToolkit", "type": "checkbox", "default": false, "section": "advanced", "title": "Disable Toolkit for YNAB", "description": "Turn all features on and off with a single switch." }, { "name": "BudgetProgressBars", "type": "select", "default": false, "hidden": false, "section": "budget", "title": "Budget Rows Progress Bars", "description": "Add progress bars and a vertical bar that shows how far you are through the month to category rows.", "options": [{ "name": "Default", "value": "0" }, { "name": "Goals progress", "value": "goals" }, { "name": "Pacing progress", "value": "pacing" }, { "name": "Pacing on name column and goals on budgeted column", "value": "both" }] }, { "name": "CategoryActivityCopy", "type": "checkbox", "default": false, "section": "budget", "title": "Add Copy Transactions button to the Category Popup", "description": "Adds a button to the category activity popup to allow you to copy the transactions to the clipboard (able to be pasted into a spreadsheet app)." }, { "name": "CategoryActivityPopupWidth", "type": "select", "default": "0", "section": "budget", "title": "Width of Category Popup", "description": "Makes the screen that pops up when you click on activity from a budget category wider so you can see more details of the transactions listed.", "options": [{ "name": "Default", "value": "0" }, { "name": "Medium", "value": "1" }, { "name": "Large", "value": "2" }] }, { "name": "CheckCreditBalances", "type": "checkbox", "default": false, "section": "budget", "title": "Paid in Full Credit Card Assist", "description": "Highlights credit card category balances with a yellow warning if the balance of the category does not match the account balance. Adds a button to the Inspector to rectify the difference." }, { "name": "CreditCardEmoji", "type": "checkbox", "default": false, "section": "budget", "title": "Credit Card Emoji", "description": "Adds a credit card emoji 💳 to the \"Credit Card Payments\" category." }, { "name": "DaysOfBuffering", "type": "checkbox", "default": false, "section": "budget", "title": "Days of Buffering Metric", "description": "This calculation shows how long your money would likely last if you never earned another cent based on your average spending. We know that no month is 'average' but this should give you some idea of how much of a buffer you have. Equal to budget accounts total divided by the average daily outflow. That comes from sum of all outflow transactions from on budget accounts only divided by the age of budget in days. You can also change the number of days taken into account by this metric with the 'Days of Buffering History Lookup' setting." }, { "name": "DaysOfBufferingHistoryLookup", "type": "select", "default": "0", "section": "budget", "title": "Days of Buffering History Lookup", "description": "How old transactions should be used for average daily outflow calculation.", "options": [{ "name": "All", "value": "0" }, { "name": "1 year", "value": "12" }, { "name": "6 months", "value": "6" }, { "name": "3 months", "value": "3" }, { "name": "1 month", "value": "1" }] }, { "name": "DisplayTargetGoalAmount", "type": "select", "default": "0", "section": "budget", "title": "Display Target Goal Amount And Overbudget Warning", "description": "Adds a 'Goal' column which displays the target goal amount for every category with a goal, and a warning in red if you have budgeted beyond your goal.", "options": [{ "name": "Do not display goal amount (default)", "value": "0" }, { "name": "Display goal amount and warn of overbudget with red", "value": "1" }, { "name": "Display goal amount but show overbudget as green", "value": "2" }] }, { "name": "EnlargeCategoriesDropdown", "type": "checkbox", "default": true, "section": "budget", "title": "Make the Categories Dropdown Larger", "description": "The Categories Dropdown that shows in the move money modal is quite small. Show more categories if the page real estate allows for it." }, { "name": "EnterToMove", "type": "checkbox", "default": false, "section": "budget", "title": "Add \"Enter\" Shortcut to the Move Popup", "description": "Pressing Enter in the Move Popup acts like clicking the OK button, instead of losing focus or doing nothing." }, { "name": "GoalWarningColor", "type": "checkbox", "default": false, "section": "budget", "title": "Goal Indicator Warning Color", "description": "Change the orange goal underfunded warning to blue, to better differentiate it from credit card overspending." }, { "name": "HideAgeOfMoney", "type": "checkbox", "default": false, "section": "budget", "title": "Hide Age of Money Calculation", "description": "Hides the Age of Money calculation. Some users find it's not relevant or helpful for them, so they'd rather hide it. NOTE: YNAB will continue to run its Age of Money calculations, so the data will be up to date if you decide to show it again." }, { "name": "CurrentMonthIndicator", "type": "checkbox", "default": false, "section": "budget", "title": "Current Month Indicator", "description": "Changes the header bar's background color to a lighter blue when viewing the current month to better differentiate between months." }, { "name": "IncomeFromLastMonth", "type": "select", "default": "0", "section": "budget", "title": "Income From Last Month", "description": "Show total of incoming transactions for last month in the header.", "options": [{ "name": "Default", "value": "0" }, { "name": "Previous month (easy)", "value": "1" }, { "name": "The month before last (medium)", "value": "2" }, { "name": "2 months before last (hard)", "value": "3" }, { "name": "3 months before last (impossibru)", "value": "4" }] }, { "name": "MonthlyNotesPopupWidth", "type": "select", "default": "0", "section": "budget", "title": "Width of Monthly Notes Popup", "description": "Makes the screen that pops up when you click on 'Enter a note...' below the month name wider so you can add more text.", "options": [{ "name": "Default", "value": "0" }, { "name": "Medium", "value": "1" }, { "name": "Large", "value": "2" }] }, { "name": "QuickBudgetWarning", "type": "checkbox", "default": false, "section": "budget", "title": "Warn When Clicking a Quick Budget Option", "description": "When this feature is activated, there will be a warning if you have already budgeted something." }, { "name": "RemovePositiveHighlight", "type": "checkbox", "default": false, "section": "budget", "title": "Unhighlight all Positive Category Balances", "description": "Removes the highlight colour from positive (or zero) category balances and colours positive balances green instead." }, { "name": "RemoveZeroCategories", "type": "checkbox", "default": false, "section": "budget", "title": "Remove Zero and Negative Categories When Covering Over-Budgeting", "description": "\nDefault YNAB behaviour is to show these categories when covering overbudgeting, but since they've got no money in them they won't help you. Let's clean up the menu.\n" }, { "name": "ResizeInspector", "type": "checkbox", "default": false, "section": "budget", "title": "Allow Resizing of Inspector", "description": "Adds a button to the Budget Toolbar that allows resizing the Budget Inspector to predetermined widths of 33% (YNAB default), 25%, 20% or 15%. Note that smaller values maybe not be suitable on small screens." }, { "name": "RowsHeight", "type": "select", "default": "0", "section": "budget", "title": "Height of Budget Rows", "description": "Makes the budget rows skinnier than the default YNAB style so that you can fit more on the screen.", "options": [{ "name": "Default", "value": "0" }, { "name": "Compact", "value": "1" }, { "name": "Slim", "value": "2" }, { "name": "Slim with smaller font", "value": "3" }] }, { "name": "SeamlessBudgetHeader", "type": "checkbox", "default": false, "section": "budget", "title": "Seamless Budget Header", "description": "Remove the borders between selected month, funds and Age of Money in the budget header." }, { "name": "StealingFromFuture", "type": "checkbox", "default": false, "section": "budget", "title": "Stealing From Future Alert", "description": "Highlights \"Budget Next Month\" red you've gone negative as some point in the future" }, { "name": "TargetBalanceWarning", "type": "checkbox", "default": false, "section": "budget", "title": "Warn When Target Balance is Not Reached", "description": "Will highlight balances of categories with Target Balances that have not yet been met." }, { "name": "ToBeBudgetedWarning", "type": "checkbox", "default": false, "section": "budget", "title": "To Be Budgeted Warning", "description": "Changes the 'To Be Budgeted' background color to yellow if there is unallocated money left to be budgeted." }, { "name": "ToggleMasterCategories", "type": "checkbox", "default": false, "section": "budget", "title": "Toggle All Master Categories Open/Close", "description": "Adds a button to the Budget Toolbar to open or close all master categories at once." }, { "name": "AccountsDisplayDensity", "type": "select", "default": "0", "section": "general", "title": "Account Name Height", "description": "Makes the account names smaller so that you can see more of the account names and fit more on the screen.", "options": [{ "name": "Default", "value": "0" }, { "name": "Compact", "value": "1" }, { "name": "Slim", "value": "2" }] }, { "name": "BetterScrollbars", "type": "select", "default": "0", "section": "general", "title": "Better scrollbars", "description": "Provides smaller and cleaner scrollbars across the application.", "options": [{ "name": "Default", "value": "0" }, { "name": "Small", "value": "1" }, { "name": "Tiny", "value": "2" }, { "name": "Off", "value": "3" }] }, { "name": "BudgetQuickSwitch", "type": "checkbox", "default": false, "section": "general", "title": "Budget Quick Switch", "description": "Adds the list of budgets to the Open Budget dropdown so you don't have to navigate to the 'Open Budget' page to switch budgets." }, { "name": "CollapseSideMenu", "type": "checkbox", "default": false, "section": "general", "title": "Collapsable Side Menu", "description": "Adds a button that can collapse the menu on the left so you can see more of your accounts or budget data." }, { "name": "ColourBlindMode", "type": "checkbox", "default": false, "section": "general", "title": "Colour Blind Mode", "description": "Changes colours like red, yellow and green in the interface to colours and shapes that are more easily distinguishable by colourblind people." }, { "name": "EditAccountButton", "type": "select", "default": "0", "section": "general", "title": "Edit Account Button Position", "description": "Allows you to move or hide the edit account button to help prevent accidentally clicking on it.", "options": [{ "name": "Default", "value": "0" }, { "name": "Left of name", "value": "1" }, { "name": "Hidden (right-click to edit)", "value": "2" }] }, { "name": "GoogleFontsSelector", "type": "select", "default": "0", "section": "general", "title": "Interface Font", "description": "Select a font from the Google Fonts library.", "options": [{ "name": "Default", "value": "0" }, { "name": "Open Sans", "value": "1" }, { "name": "Roboto", "value": "2" }, { "name": "Roboto Condensed", "value": "3" }, { "name": "Droid Sans", "value": "4" }] }, { "name": "HideAccountBalancesType", "type": "select", "default": "0", "section": "general", "title": "Hide Account Balances", "description": "Allows you to hide account type totals and/or account balances.", "options": [{ "name": "Disabled", "value": "0" }, { "name": "Hide All", "value": "1" }, { "name": "Hide Account Type Totals", "value": "2" }, { "name": "Hide Account Balances", "value": "3" }] }, { "name": "HideHelp", "type": "checkbox", "default": false, "section": "general", "title": "Hide Help (?) Button", "description": "This feature hides the blue help (?) button in the bottom right corner of the screen. View the account-options popup (click your e-mail in the bottom left) to show or hide the help button." }, { "name": "HideReferralBanner", "type": "checkbox", "default": false, "section": "general", "title": "Hide Referral Banner", "description": "YNAB shows a \"Share YNAB, Get YNAB free\" banner. If you'd rather not see this banner, you can turn this feature on to hide it." }, { "name": "ImportNotification", "type": "select", "default": "0", "section": "general", "title": "Show Import Notifications in Sidebar", "description": "Display a notification in the sidebar when there are transactions to be imported.", "options": [{ "name": "Off", "value": "0" }, { "name": "On - Default Indicator Color", "value": "1", "style": "background-color: #227e99" }, { "name": "On - Red Indicator Color", "value": "2", "style": "background-color: #FF0000" }] }, { "name": "NavDisplayDensity", "type": "select", "default": "0", "section": "general", "title": "Navigation Tabs Height", "description": "Makes the navigation tabs (Budget, Reports, etc) smaller, and with less padding, so that you can see more of the sidebar on the screen.", "options": [{ "name": "Default", "value": "0" }, { "name": "Compact", "value": "1" }, { "name": "Slim", "value": "2" }] }, { "name": "PrintingImprovements", "type": "checkbox", "default": true, "section": "general", "title": "Printing Improvements", "description": "Changes print styles so budget and account sections can be easily printed. Due to the number of columns, the account section should be printed using landscape orientation." }, { "name": "PrivacyMode", "type": "select", "default": "0", "section": "general", "title": "Privacy Mode", "description": "Obscures dollar amounts everywhere until hovered. In toggle mode, a lock icon will appear to the right of your budget name in the top left corner of YNAB. Click to enable or disable privacy mode.", "options": [{ "name": "Disabled", "value": "0" }, { "name": "Always On", "value": "1" }, { "name": "Add Toggle Button", "value": "2" }] }, { "name": "ShowIntercom", "type": "checkbox", "default": true, "section": "general", "title": "Show Intercom", "description": "It's easy to just click 'X' on the intercom announcements when they show up and forget to read what was there. This feature add an option to the account-options popup (click your e-mail at the bottom left of the screen) to show the intercom again." }, { "name": "SquareNegativeMode", "type": "checkbox", "default": false, "section": "general", "title": "Square Negative Mode", "description": "Changes the round borders on all negative numbers to square. Helps them become more of an eyesore so you want to get rid of them!" }, { "name": "CompactIncomeVsExpense", "type": "checkbox", "default": false, "section": "reports", "title": "Compact Income vs. Expense", "description": "Modifies styling of the Income vs. Expense report so it doesn't use too much white space on the page." }];

// eslint-disable-next-line quotes, object-curly-spacing, quote-props
window.ynabToolKit.settings = allToolkitSettings;

// We don't update these from anywhere else, so go ahead and freeze / seal the object so nothing can be injected.
Object.freeze(window.ynabToolKit.settings);
Object.seal(window.ynabToolKit.settings);

/***/ })

/******/ });
//# sourceMappingURL=init.js.map